import React, { createContext, useContext, useState, useEffect } from 'react';
import {
  Organization,
  User,
  CertificateTemplate,
  CertificateRecord,
  CanvasElement,
  BulkBatch,
  AuditLogEntry,
  UserRole,
} from '../types';
import { INITIAL_TEMPLATES } from '../data/templates';
import { getOrgHue } from '../utils/proceduralLogo';

interface CertContextType {
  // Navigation
  activeTab: string;
  setActiveTab: (tab: string) => void;
  publicVerifyToken: string | null;
  setPublicVerifyToken: (token: string | null) => void;

  // Auth & Org
  currentUser: User;
  setCurrentUserRole: (role: UserRole) => void;
  organizations: Organization[];
  currentOrg: Organization;
  switchOrganization: (orgId: string) => void;
  toggle2FA: () => void;
  updateOrgSettings: (updates: Partial<Organization>) => void;

  // Templates
  templates: CertificateTemplate[];
  selectedTemplate: CertificateTemplate;
  setSelectedTemplate: (template: CertificateTemplate) => void;
  cloneTemplate: (template: CertificateTemplate) => CertificateTemplate;

  // Editor
  canvasElements: CanvasElement[];
  setCanvasElements: React.Dispatch<React.SetStateAction<CanvasElement[]>>;
  selectedElementId: string | null;
  setSelectedElementId: (id: string | null) => void;
  updateElement: (id: string, updates: Partial<CanvasElement>) => void;
  addElement: (type: CanvasElement['type'], extra?: Partial<CanvasElement>) => void;
  removeElement: (id: string) => void;
  duplicateElement: (id: string) => void;
  moveElementLayer: (id: string, direction: 'up' | 'down' | 'top' | 'bottom') => void;
  undo: () => void;
  redo: () => void;
  canUndo: boolean;
  canRedo: boolean;
  activeSampleRecipient: {
    name: string;
    course: string;
    date: string;
    certNo: string;
    grade?: string;
    skills?: string[];
  };
  setActiveSampleRecipient: (recipient: any) => void;

  // Certificates & Verification
  certificates: CertificateRecord[];
  issueCertificate: (record: Omit<CertificateRecord, 'id' | 'sha256Hash' | 'status' | 'issuerOrgId'>) => CertificateRecord;
  revokeCertificate: (id: string, reason: string) => void;
  getCertificateByTokenOrId: (query: string) => CertificateRecord | undefined;

  // Bulk
  bulkBatches: BulkBatch[];
  addBulkBatch: (batch: BulkBatch) => void;
  updateBulkBatch: (id: string, updates: Partial<BulkBatch>) => void;

  // Audit Logs
  auditLogs: AuditLogEntry[];
  addAuditLog: (action: string, resourceType: AuditLogEntry['resourceType'], resourceId: string, details: string) => void;

  // Global Theme
  isDarkMode: boolean;
  toggleDarkMode: () => void;
}

const INITIAL_ORGS: Organization[] = [
  {
    id: 'org-meta-edu',
    name: 'Global Tech & AI Academy',
    slug: 'global-tech-ai',
    hue: getOrgHue('org-meta-edu'),
    plan: 'ENTERPRISE',
    customDomain: 'credentials.globaltech.edu',
    whitelabel: true,
    countryPack: 'standard',
    accentColor: '#4F46E5',
    storageUsedMb: 142.5,
  },
  {
    id: 'org-skill-india',
    name: 'Skill India National Institute',
    slug: 'skill-india-inst',
    hue: getOrgHue('org-skill-india'),
    plan: 'PROFESSIONAL',
    customDomain: 'verify.skillindia.gov.in',
    whitelabel: true,
    countryPack: 'india_abc_nsdc',
    accentColor: '#EA580C',
    storageUsedMb: 520.1,
  },
  {
    id: 'org-health-ceu',
    name: 'American Institute of Clinical Excellence',
    slug: 'clinical-ceu-us',
    hue: getOrgHue('org-health-ceu'),
    plan: 'PROFESSIONAL',
    customDomain: 'ce.clinicalexcellence.org',
    whitelabel: false,
    countryPack: 'us_ceu',
    accentColor: '#D97706',
    storageUsedMb: 89.2,
  },
];

const INITIAL_CERTIFICATES: CertificateRecord[] = [
  {
    id: 'cert-884920',
    certNo: 'CV-AI-2026-884920',
    token: 'tok_live_7e8b91fa023a4b9c8d11',
    templateId: 'tmpl-ai-mastery',
    recipientName: 'Alexander Vance, M.Sc.',
    recipientEmail: 'alex.vance@stanford.alumni.edu',
    course: 'Large Language Models & Agentic Architecture',
    issueDate: '2026-10-09',
    grade: 'High Honors (98.6%)',
    skills: ['Transformers', 'PyTorch', 'Agent Workflows', 'RLHF', 'RAG Systems'],
    issuerName: 'Dr. Evelyn Zhang',
    issuerTitle: 'Director of AI Research',
    issuerOrg: 'Global Tech & AI Academy',
    issuerOrgId: 'org-meta-edu',
    sha256Hash: 'e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855',
    status: 'active',
    blockchainAnchor: {
      network: 'Polygon Mainnet (PoS)',
      txHash: '0x8f237190cbbd4218aef72991823901b0cf0449179921bcade9027419ef007621',
      blockNumber: 58921442,
      timestamp: '2026-10-09T01:12:00Z',
    },
    countryPack: 'standard',
  },
  {
    id: 'cert-772109',
    certNo: 'CV-CYBER-2026-772109',
    token: 'tok_live_1a980bcf221e4a6890d3',
    templateId: 'tmpl-cyber-sec',
    recipientName: 'Sarah Jenkins, CISSP',
    recipientEmail: 's.jenkins@sentinelshield.io',
    course: 'Advanced Penetration Testing & Threat Hunting',
    issueDate: '2026-10-02',
    grade: 'Distinction',
    skills: ['Red Teaming', 'Zero-Day Exploits', 'SIEM/SOAR', 'Memory Forensics'],
    issuerName: 'Viktor Romanov',
    issuerTitle: 'Head of Red Team Operations',
    issuerOrg: 'Global Tech & AI Academy',
    issuerOrgId: 'org-meta-edu',
    sha256Hash: 'a7c938162fbe41846c9e018d45f49efc991b107e324ef891bca76291a0293411',
    status: 'active',
    blockchainAnchor: {
      network: 'Polygon Mainnet (PoS)',
      txHash: '0x187c32bf90e4817a0029bcefa81023d881902bbfa219803120cfd72091e77902',
      blockNumber: 58890214,
      timestamp: '2026-10-02T14:40:00Z',
    },
    countryPack: 'standard',
  },
  {
    id: 'cert-661092',
    certNo: 'CV-NSDC-2026-661092',
    token: 'tok_live_99fba200c88123ae4910',
    templateId: 'tmpl-india-abc-nsdc',
    recipientName: 'Aarav Rajesh Sharma',
    recipientEmail: 'aarav.sharma@nasscom.ac.in',
    course: 'Artificial Intelligence & Data Engineering (NSQF Level 6)',
    issueDate: '2026-09-28',
    grade: 'A+ (Elite)',
    skills: ['Python', 'SQL', 'Predictive Modeling', 'Data Pipelines', 'ETL'],
    issuerName: 'Rajendra Prasad, IAS',
    issuerTitle: 'Mission Director, Skill India',
    issuerOrg: 'Skill India National Institute',
    issuerOrgId: 'org-skill-india',
    sha256Hash: 'c4ca4238a0b923820dcc509a6f75849b2938192a0149bb83204918e9029a8f21',
    status: 'active',
    countryPack: 'india_abc_nsdc',
    metadata: {
      apaarId: '8910-2345-6712',
      nsqfLevel: 6,
      academicCredits: 4,
    },
  },
  {
    id: 'cert-revoked-001',
    certNo: 'CV-TEST-2026-000001',
    token: 'tok_revoked_demo_sample99',
    templateId: 'tmpl-ai-mastery',
    recipientName: 'Marcus Bradley (Revoked Demo)',
    recipientEmail: 'm.bradley@suspicious.org',
    course: 'AI Ethics & Autonomous Vehicle Systems',
    issueDate: '2026-08-15',
    skills: ['Autonomous Navigation'],
    issuerName: 'Dr. Evelyn Zhang',
    issuerTitle: 'Director of AI Research',
    issuerOrg: 'Global Tech & AI Academy',
    issuerOrgId: 'org-meta-edu',
    sha256Hash: '98234190cbbd4218aef72991823901b0cf0449179921bcade9027419ef007621',
    status: 'revoked',
    revokedAt: '2026-09-01T10:00:00Z',
    revocationReason: 'Academic integrity breach: unauthorized LLM output plagiarism in capstone submission.',
  },
];

const INITIAL_SAMPLE_RECIPIENTS = [
  {
    name: 'Alexander Vance, M.Sc.',
    course: 'Large Language Models & Agentic Architecture',
    date: 'October 9, 2026',
    certNo: 'CV-AI-2026-884920',
    grade: 'High Distinction',
    skills: ['Transformers', 'PyTorch', 'Agent Workflows', 'RLHF'],
  },
  {
    name: 'Dr. Sophia Patel, MD, Ph.D.',
    course: 'Cardiovascular Intervention & Bio-Robotics',
    date: 'October 15, 2026',
    certNo: 'CV-MED-2026-440192',
    grade: 'Top 1% Percentile',
    skills: ['Angioplasty', 'Robotic Surgery', 'Clinical Protocols'],
  },
  {
    name: 'Mei-Ling Chen',
    course: 'Cloud Distributed Systems & Kubernetes Enterprise',
    date: 'September 28, 2026',
    certNo: 'CV-CLD-2026-102948',
    grade: 'Summa Cum Laude',
    skills: ['Kubernetes', 'Terraform', 'Observability', 'GitOps'],
  },
  {
    name: 'Aarav Rajesh Sharma',
    course: 'AI & Data Engineering (NSQF Level 6)',
    date: 'October 5, 2026',
    certNo: 'CV-NSDC-2026-661092',
    grade: 'Grade A+ Certified',
    skills: ['Python', 'SQL', 'Data Pipelines', 'ETL'],
  },
];

const CertContext = createContext<CertContextType | null>(null);

export const CertProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [activeTab, setActiveTab] = useState<string>('landing');
  const [publicVerifyToken, setPublicVerifyToken] = useState<string | null>(null);
  const [isDarkMode, setIsDarkMode] = useState<boolean>(true);

  // User & Organization state
  const [organizations, setOrganizations] = useState<Organization[]>(INITIAL_ORGS);
  const [currentOrg, setCurrentOrg] = useState<Organization>(INITIAL_ORGS[0]);
  const [currentUser, setCurrentUser] = useState<User>({
    id: 'usr-admin-01',
    name: 'Alex Sterling',
    email: 'alex.sterling@globaltech.edu',
    role: 'OWNER',
    orgId: INITIAL_ORGS[0].id,
    twoFactorEnabled: true,
  });

  // Templates & Editor
  const [templates, setTemplates] = useState<CertificateTemplate[]>(INITIAL_TEMPLATES);
  const [selectedTemplate, setSelectedTemplate] = useState<CertificateTemplate>(INITIAL_TEMPLATES[0]);
  const [canvasElements, setCanvasElements] = useState<CanvasElement[]>(INITIAL_TEMPLATES[0].elements);
  const [selectedElementId, setSelectedElementId] = useState<string | null>(null);

  // Undo/Redo history stack
  const [history, setHistory] = useState<CanvasElement[][]>([INITIAL_TEMPLATES[0].elements]);
  const [historyIndex, setHistoryIndex] = useState<number>(0);

  // Sample recipient for live preview
  const [activeSampleRecipient, setActiveSampleRecipient] = useState(INITIAL_SAMPLE_RECIPIENTS[0]);

  // Certificates collection
  const [certificates, setCertificates] = useState<CertificateRecord[]>(INITIAL_CERTIFICATES);

  // Bulk batches
  const [bulkBatches, setBulkBatches] = useState<BulkBatch[]>([
    {
      id: 'batch-2026-001',
      name: 'Autumn 2026 AI Fellows Cohort (420 students)',
      totalRows: 420,
      processedRows: 420,
      successCount: 420,
      failedCount: 0,
      status: 'completed',
      templateId: 'tmpl-ai-mastery',
      createdAt: '2026-10-08 14:22:00',
      downloadZipReady: true,
    },
    {
      id: 'batch-2026-002',
      name: 'Q3 Cyber Defense BootCamp Certified (150 students)',
      totalRows: 150,
      processedRows: 150,
      successCount: 148,
      failedCount: 2,
      status: 'completed',
      templateId: 'tmpl-cyber-sec',
      createdAt: '2026-10-05 09:15:00',
      downloadZipReady: true,
    },
  ]);

  // Audit Logs (WORM Log)
  const [auditLogs, setAuditLogs] = useState<AuditLogEntry[]>([
    {
      id: 'log-001',
      timestamp: '2026-10-09 01:12:00 UTC',
      actorEmail: 'alex.sterling@globaltech.edu',
      actorRole: 'OWNER',
      action: 'CERTIFICATE_ISSUED_CRYPTOGRAPHIC',
      resourceType: 'CERTIFICATE',
      resourceId: 'CV-AI-2026-884920',
      details: 'Issued to Alexander Vance with SHA-256 seal & Polygon block #58921442 anchor',
      immutableHash: '0x8f237190cbbd4218aef72991823901b0cf0449179921bcade9027419ef007621',
    },
    {
      id: 'log-002',
      timestamp: '2026-10-09 00:45:00 UTC',
      actorEmail: 'system-scheduler@certiverse.ai',
      actorRole: 'ADMIN',
      action: 'SECURITY_KEY_ROTATED',
      resourceType: 'AUTH',
      resourceId: 'ED25519_KEYPAIR_2026_Q4',
      details: 'Automated 7-day key rotation cycle succeeded with 0 downtime',
      immutableHash: '0x33b918a0239fbc810029bcefa81023d881902bbfa219803120cfd72091e77902',
    },
    {
      id: 'log-003',
      timestamp: '2026-10-08 14:22:15 UTC',
      actorEmail: 'alex.sterling@globaltech.edu',
      actorRole: 'OWNER',
      action: 'BULK_DISPATCH_COMPLETED',
      resourceType: 'BULK_BATCH',
      resourceId: 'batch-2026-001',
      details: '420 certificates rendered at 300 DPI and dispatched via AWS SES',
      immutableHash: '0xca7190b0cf0449179921bcade9027419ef0076218f237190cbbd4218aef72991',
    },
  ]);

  // Sync canvas elements when template changes
  useEffect(() => {
    setCanvasElements(selectedTemplate.elements);
    setHistory([selectedTemplate.elements]);
    setHistoryIndex(0);
    setSelectedElementId(null);
  }, [selectedTemplate]);

  // Push history on element changes
  const recordHistory = (newElements: CanvasElement[]) => {
    const updatedHistory = history.slice(0, historyIndex + 1);
    updatedHistory.push(newElements);
    setHistory(updatedHistory);
    setHistoryIndex(updatedHistory.length - 1);
  };

  const updateElement = (id: string, updates: Partial<CanvasElement>) => {
    setCanvasElements((prev) => {
      const next = prev.map((el) => (el.id === id ? { ...el, ...updates } : el));
      recordHistory(next);
      return next;
    });
  };

  const addElement = (type: CanvasElement['type'], extra: Partial<CanvasElement> = {}) => {
    const newId = `el-${Date.now().toString(36)}`;
    const baseElement: CanvasElement = {
      id: newId,
      type,
      x: 350,
      y: 250,
      width: type === 'seal' || type === 'qr' ? 100 : 300,
      height: type === 'seal' || type === 'qr' ? 100 : 50,
      zIndex: canvasElements.length + 1,
      color: '#FFFFFF',
      fontFamily: 'Inter',
      fontSize: 18,
      textAlign: 'center',
      ...extra,
    };

    if (type === 'token') {
      baseElement.content = '{{dynamic_token}}';
      baseElement.tokenName = extra.tokenName || '{{recipient_name}}';
    } else if (type === 'text') {
      baseElement.content = 'Double click to edit text';
    } else if (type === 'seal') {
      baseElement.sealVariant = 'gold-foil';
      baseElement.sealText = 'VERIFIED CREDENTIAL';
      baseElement.sealSubtext = 'AUTHENTIC';
    } else if (type === 'signature') {
      baseElement.signerName = 'Jane Doe, Ph.D.';
      baseElement.signerTitle = 'Chief Academic Dean';
      baseElement.signatureStyle = 'classic';
      baseElement.width = 220;
      baseElement.height = 80;
    }

    setCanvasElements((prev) => {
      const next = [...prev, baseElement];
      recordHistory(next);
      return next;
    });
    setSelectedElementId(newId);
  };

  const removeElement = (id: string) => {
    setCanvasElements((prev) => {
      const next = prev.filter((el) => el.id !== id);
      recordHistory(next);
      return next;
    });
    if (selectedElementId === id) setSelectedElementId(null);
  };

  const duplicateElement = (id: string) => {
    const target = canvasElements.find((el) => el.id === id);
    if (!target) return;
    const duplicated: CanvasElement = {
      ...target,
      id: `el-${Date.now().toString(36)}`,
      x: target.x + 25,
      y: target.y + 25,
      zIndex: canvasElements.length + 1,
    };
    setCanvasElements((prev) => {
      const next = [...prev, duplicated];
      recordHistory(next);
      return next;
    });
    setSelectedElementId(duplicated.id);
  };

  const moveElementLayer = (id: string, direction: 'up' | 'down' | 'top' | 'bottom') => {
    setCanvasElements((prev) => {
      const el = prev.find((item) => item.id === id);
      if (!el) return prev;
      let next = [...prev];
      const currentIndex = next.indexOf(el);

      if (direction === 'up' && currentIndex < next.length - 1) {
        const temp = next[currentIndex];
        next[currentIndex] = next[currentIndex + 1];
        next[currentIndex + 1] = temp;
      } else if (direction === 'down' && currentIndex > 0) {
        const temp = next[currentIndex];
        next[currentIndex] = next[currentIndex - 1];
        next[currentIndex - 1] = temp;
      } else if (direction === 'top') {
        next = next.filter((item) => item.id !== id);
        next.push(el);
      } else if (direction === 'bottom') {
        next = next.filter((item) => item.id !== id);
        next.unshift(el);
      }

      // Re-assign zIndexes
      next = next.map((item, idx) => ({ ...item, zIndex: idx + 1 }));
      recordHistory(next);
      return next;
    });
  };

  const undo = () => {
    if (historyIndex > 0) {
      const newIndex = historyIndex - 1;
      setHistoryIndex(newIndex);
      setCanvasElements(history[newIndex]);
    }
  };

  const redo = () => {
    if (historyIndex < history.length - 1) {
      const newIndex = historyIndex + 1;
      setHistoryIndex(newIndex);
      setCanvasElements(history[newIndex]);
    }
  };

  const cloneTemplate = (tmpl: CertificateTemplate) => {
    const cloned: CertificateTemplate = {
      ...tmpl,
      id: `tmpl-custom-${Date.now().toString(36)}`,
      title: `${tmpl.title} (Custom)`,
      elements: JSON.parse(JSON.stringify(tmpl.elements)),
    };
    setTemplates((prev) => [cloned, ...prev]);
    setSelectedTemplate(cloned);
    return cloned;
  };

  const switchOrganization = (orgId: string) => {
    const found = organizations.find((o) => o.id === orgId);
    if (found) {
      setCurrentOrg(found);
      setCurrentUser((prev) => ({ ...prev, orgId: found.id }));
      addAuditLog('ORGANIZATION_SWITCHED', 'ORGANIZATION', found.id, `Switched workspace to ${found.name}`);
    }
  };

  const setCurrentUserRole = (role: UserRole) => {
    setCurrentUser((prev) => ({ ...prev, role }));
    addAuditLog('USER_ROLE_UPDATED', 'AUTH', currentUser.id, `Switched RBAC simulation role to ${role}`);
  };

  const toggle2FA = () => {
    setCurrentUser((prev) => {
      const nextState = !prev.twoFactorEnabled;
      addAuditLog(
        nextState ? '2FA_ENABLED' : '2FA_DISABLED',
        'AUTH',
        prev.id,
        `Multi-Factor Authentication updated to ${nextState ? 'Enabled' : 'Disabled'}`
      );
      return { ...prev, twoFactorEnabled: nextState };
    });
  };

  const updateOrgSettings = (updates: Partial<Organization>) => {
    setCurrentOrg((prev) => {
      const updated = { ...prev, ...updates };
      setOrganizations((orgs) => orgs.map((o) => (o.id === prev.id ? updated : o)));
      addAuditLog('ORGANIZATION_SETTINGS_UPDATED', 'ORGANIZATION', prev.id, `Updated settings: ${Object.keys(updates).join(', ')}`);
      return updated;
    });
  };

  const issueCertificate = (record: Omit<CertificateRecord, 'id' | 'sha256Hash' | 'status' | 'issuerOrgId'>) => {
    // Generate deterministic sha256 simulation
    const simulatedSha256 = Array.from({ length: 64 }, () =>
      Math.floor(Math.random() * 16).toString(16)
    ).join('');

    const newRecord: CertificateRecord = {
      ...record,
      id: `cert-${Date.now().toString(36)}`,
      issuerOrgId: currentOrg.id,
      sha256Hash: simulatedSha256,
      status: 'active',
      blockchainAnchor: {
        network: 'Polygon Mainnet (PoS)',
        txHash: `0x${simulatedSha256.substring(0, 40)}`,
        blockNumber: 58920000 + Math.floor(Math.random() * 5000),
        timestamp: new Date().toISOString(),
      },
    };

    setCertificates((prev) => [newRecord, ...prev]);
    addAuditLog(
      'CERTIFICATE_ISSUED',
      'CERTIFICATE',
      newRecord.certNo,
      `Issued credential to ${newRecord.recipientName} for ${newRecord.course}`
    );
    return newRecord;
  };

  const revokeCertificate = (id: string, reason: string) => {
    setCertificates((prev) =>
      prev.map((c) =>
        c.id === id || c.certNo === id || c.token === id
          ? {
              ...c,
              status: 'revoked',
              revokedAt: new Date().toISOString(),
              revocationReason: reason,
            }
          : c
      )
    );
    addAuditLog('CERTIFICATE_REVOKED', 'CERTIFICATE', id, `Certificate revoked. Reason: ${reason}`);
  };

  const getCertificateByTokenOrId = (query: string): CertificateRecord | undefined => {
    const clean = query.trim().toLowerCase();
    return certificates.find(
      (c) =>
        c.token.toLowerCase() === clean ||
        c.certNo.toLowerCase() === clean ||
        c.id.toLowerCase() === clean
    );
  };

  const addBulkBatch = (batch: BulkBatch) => {
    setBulkBatches((prev) => [batch, ...prev]);
    addAuditLog('BULK_BATCH_CREATED', 'BULK_BATCH', batch.id, `Started bulk issuance batch: ${batch.name}`);
  };

  const updateBulkBatch = (id: string, updates: Partial<BulkBatch>) => {
    setBulkBatches((prev) => prev.map((b) => (b.id === id ? { ...b, ...updates } : b)));
  };

  const addAuditLog = (
    action: string,
    resourceType: AuditLogEntry['resourceType'],
    resourceId: string,
    details: string
  ) => {
    const simulatedHash = '0x' + Array.from({ length: 48 }, () => Math.floor(Math.random() * 16).toString(16)).join('');
    const newEntry: AuditLogEntry = {
      id: `log-${Date.now().toString(36)}`,
      timestamp: new Date().toISOString().replace('T', ' ').substring(0, 19) + ' UTC',
      actorEmail: currentUser.email,
      actorRole: currentUser.role,
      action,
      resourceType,
      resourceId,
      details,
      immutableHash: simulatedHash,
    };
    setAuditLogs((prev) => [newEntry, ...prev]);
  };

  const toggleDarkMode = () => setIsDarkMode((prev) => !prev);

  return (
    <CertContext.Provider
      value={{
        activeTab,
        setActiveTab,
        publicVerifyToken,
        setPublicVerifyToken,
        currentUser,
        setCurrentUserRole,
        organizations,
        currentOrg,
        switchOrganization,
        toggle2FA,
        updateOrgSettings,
        templates,
        selectedTemplate,
        setSelectedTemplate,
        cloneTemplate,
        canvasElements,
        setCanvasElements,
        selectedElementId,
        setSelectedElementId,
        updateElement,
        addElement,
        removeElement,
        duplicateElement,
        moveElementLayer,
        undo,
        redo,
        canUndo: historyIndex > 0,
        canRedo: historyIndex < history.length - 1,
        activeSampleRecipient,
        setActiveSampleRecipient,
        certificates,
        issueCertificate,
        revokeCertificate,
        getCertificateByTokenOrId,
        bulkBatches,
        addBulkBatch,
        updateBulkBatch,
        auditLogs,
        addAuditLog,
        isDarkMode,
        toggleDarkMode,
      }}
    >
      {children}
    </CertContext.Provider>
  );
};

export const useCert = () => {
  const context = useContext(CertContext);
  if (!context) throw new Error('useCert must be used within a CertProvider');
  return context;
};
