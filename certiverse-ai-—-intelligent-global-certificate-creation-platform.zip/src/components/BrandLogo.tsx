import React from 'react';

interface BrandLogoProps {
  size?: number;
  variant?: 'full' | 'icon' | 'dark' | 'light' | 'print';
  showSubtitle?: boolean;
  className?: string;
}

export const BrandLogo: React.FC<BrandLogoProps> = ({
  size = 36,
  variant = 'full',
  showSubtitle = true,
  className = '',
}) => {
  const isPrint = variant === 'print';
  const isLightOnly = variant === 'light';

  // SVG Master Logo: Certificate sheet + Verification checkmark + AI network nodes
  const iconSvg = (
    <svg
      width={size}
      height={size}
      viewBox="0 0 64 64"
      fill="none"
      xmlns="http://www.w3.org/2000/svg"
      className="shrink-0 transition-transform hover:scale-105"
    >
      <defs>
        <linearGradient id="sheetGrad" x1="8" y1="6" x2="56" y2="58" gradientUnits="userSpaceOnUse">
          <stop stopColor={isPrint ? '#000000' : '#4F46E5'} />
          <stop offset="1" stopColor={isPrint ? '#333333' : '#312E81'} />
        </linearGradient>
        <linearGradient id="aiNodesGrad" x1="0" y1="0" x2="64" y2="64" gradientUnits="userSpaceOnUse">
          <stop stopColor="#06B6D4" />
          <stop offset="1" stopColor="#38BDF8" />
        </linearGradient>
        <linearGradient id="goldSealGrad" x1="36" y1="32" x2="56" y2="52" gradientUnits="userSpaceOnUse">
          <stop stopColor="#F59E0B" />
          <stop offset="1" stopColor="#D97706" />
        </linearGradient>
      </defs>

      {/* Certificate Sheet Body */}
      <rect
        x="8"
        y="6"
        width="48"
        height="52"
        rx="8"
        fill="url(#sheetGrad)"
        stroke={isPrint ? '#000' : '#818CF8'}
        strokeWidth="1.5"
      />

      {/* Inner Document Border */}
      <rect
        x="13"
        y="11"
        width="38"
        height="42"
        rx="5"
        fill={isPrint ? '#FFFFFF' : '#0B0F1E'}
        stroke={isPrint ? '#888' : 'rgba(255,255,255,0.08)'}
        strokeWidth="1"
      />

      {/* Certificate Decorative Guilloche Text Lines */}
      <path
        d="M20 20H36M20 26H44M20 32H32"
        stroke={isPrint ? '#444' : '#06B6D4'}
        strokeWidth="2.5"
        strokeLinecap="round"
      />

      {/* AI Network Nodes & Neural Connections */}
      {!isPrint && (
        <g opacity="0.9">
          {/* Neural Links */}
          <line x1="38" y1="18" x2="48" y2="24" stroke="url(#aiNodesGrad)" strokeWidth="1.5" strokeDasharray="2 2" />
          <line x1="48" y1="24" x2="42" y2="34" stroke="url(#aiNodesGrad)" strokeWidth="1.2" />
          {/* AI Nodes */}
          <circle cx="38" cy="18" r="2.5" fill="#06B6D4" />
          <circle cx="48" cy="24" r="2" fill="#38BDF8" />
          <circle cx="42" cy="34" r="1.8" fill="#818CF8" />
        </g>
      )}

      {/* Official Gold Verification Seal with Checkmark */}
      <circle
        cx="46"
        cy="43"
        r="9.5"
        fill={isPrint ? '#222' : 'url(#goldSealGrad)'}
        stroke={isPrint ? '#000' : '#FDE68A'}
        strokeWidth="1.2"
      />
      {/* Verification Checkmark */}
      <path
        d="M41.5 43.2L44.5 46.2L50.5 40"
        stroke={isPrint ? '#FFF' : '#0B0F1E'}
        strokeWidth="2.4"
        strokeLinecap="round"
        strokeLinejoin="round"
      />
    </svg>
  );

  if (variant === 'icon') {
    return <div className={`inline-flex items-center ${className}`}>{iconSvg}</div>;
  }

  return (
    <div className={`inline-flex items-center gap-3 ${className}`}>
      {iconSvg}
      <div className="flex flex-col">
        <div className="flex items-center gap-1.5 leading-none">
          <span
            className={`font-sora font-extrabold tracking-tight text-xl ${
              isPrint
                ? 'text-black'
                : isLightOnly
                ? 'text-slate-900'
                : 'text-white'
            }`}
          >
            Certi<span className="text-cyan-400">Verse</span>
          </span>
          <span className="text-[10px] font-bold uppercase tracking-wider px-1.5 py-0.5 rounded bg-indigo-500/20 text-indigo-400 border border-indigo-500/30">
            AI
          </span>
        </div>
        {showSubtitle && (
          <span
            className={`text-[11px] font-medium tracking-wide mt-0.5 ${
              isPrint ? 'text-gray-600' : 'text-slate-400'
            }`}
          >
            Global Verification Platform
          </span>
        )}
      </div>
    </div>
  );
};
