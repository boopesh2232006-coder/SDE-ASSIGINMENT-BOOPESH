import React, { useState } from 'react';
import { useCert } from '../../context/CertContext';
import { CertificateRenderer } from '../editor/CertificateRenderer';
import { exportCertificatePdf, exportCertificatePng } from '../../utils/exportCert';
import { CanvasElement, CertificateTemplate } from '../../types';
import {
  Sparkles,
  Award,
  CheckCircle2,
  FileDown,
  Printer,
  Wand2,
  Sliders,
  User,
  Building,
  PenTool,
  ShieldCheck,
  ArrowRight,
  ExternalLink,
  Layers,
  Palette,
  Eye,
  RefreshCw,
} from 'lucide-react';
import confetti from 'canvas-confetti';

export const CreateCertificateSpace: React.FC = () => {
  const {
    currentOrg,
    issueCertificate,
    setActiveTab,
    setPublicVerifyToken,
    templates,
    setSelectedTemplate,
    setCanvasElements,
  } = useCert();

  // Form State for creating a certificate
  const [creationMode, setCreationMode] = useState<'guided' | 'ai_prompt'>('guided');
  const [recipientName, setRecipientName] = useState('Dr. Marcus Sterling, Ph.D.');
  const [recipientEmail, setRecipientEmail] = useState('marcus.sterling@cambridge.ac.uk');
  const [courseTitle, setCourseTitle] = useState('Quantum Computing & Quantum Information Theory');
  const [certTitle, setCertTitle] = useState('Certificate of High Distinction');
  const [grade, setGrade] = useState('Summa Cum Laude (Top 1%)');
  const [issueDate, setIssueDate] = useState('2026-10-09');
  const [expiryDate, setExpiryDate] = useState('');
  const [skills, setSkills] = useState('Qiskit, Quantum Circuits, Shor Algorithm, Error Mitigation');
  const [orgName, setOrgName] = useState(currentOrg.name);
  const [signer1Name, setSigner1Name] = useState('Dr. Evelyn Zhang');
  const [signer1Title, setSigner1Title] = useState('Chair of Quantum Physics');
  const [signer2Name, setSigner2Name] = useState('Prof. Arthur Pendelton');
  const [signer2Title, setSigner2Title] = useState('Dean of Physical Sciences');
  const [theme, setTheme] = useState<'dark-sapphire' | 'royal-gold' | 'cyber-slate' | 'classic-ivory' | 'emerald-crest' | 'minimal-frost'>('dark-sapphire');
  const [sealVariant, setSealVariant] = useState<'gold-foil' | 'cyan-crest' | 'indigo-shield' | 'royal-star'>('gold-foil');
  const [sealText, setSealText] = useState('OFFICIAL CREDENTIAL');
  const [sealSubtext, setSealSubtext] = useState('VERIFIED 2026');
  const [orientation, setOrientation] = useState<'landscape' | 'portrait'>('landscape');
  const [showGuilloche, setShowGuilloche] = useState(true);

  // AI Prompt Assistant state
  const [aiPrompt, setAiPrompt] = useState('');
  const [isAiGenerating, setIsAiGenerating] = useState(false);

  // Export & modal state
  const [isExporting, setIsExporting] = useState(false);
  const [issuedResult, setIssuedResult] = useState<any>(null);

  // Generate live elements for preview
  const previewElements: CanvasElement[] = [
    {
      id: 'prev-border',
      type: 'border',
      x: 20,
      y: 20,
      width: orientation === 'landscape' ? 960 : 667,
      height: orientation === 'landscape' ? 667 : 960,
      borderWidth: 3,
      borderColor: theme === 'classic-ivory' ? '#B45309' : theme === 'cyber-slate' ? '#10B981' : '#F59E0B',
      borderStyle: 'solid',
      zIndex: 1,
    },
    ...(showGuilloche
      ? [
          {
            id: 'prev-guilloche',
            type: 'guilloche' as const,
            x: 35,
            y: 35,
            width: orientation === 'landscape' ? 930 : 637,
            height: orientation === 'landscape' ? 637 : 930,
            opacity: 0.15,
            zIndex: 2,
          },
        ]
      : []),
    {
      id: 'prev-org',
      type: 'text',
      x: 100,
      y: 65,
      width: 800,
      height: 35,
      content: orgName.toUpperCase(),
      fontFamily: 'Sora',
      fontSize: 15,
      fontWeight: 700,
      letterSpacing: 4,
      color: theme === 'classic-ivory' ? '#78350F' : '#38BDF8',
      textAlign: 'center',
      zIndex: 10,
    },
    {
      id: 'prev-title',
      type: 'text',
      x: 100,
      y: 115,
      width: 800,
      height: 65,
      content: certTitle,
      fontFamily: 'Playfair Display',
      fontSize: 40,
      fontWeight: 700,
      color: theme === 'classic-ivory' ? '#1E293B' : '#F8FAFC',
      textAlign: 'center',
      zIndex: 10,
    },
    {
      id: 'prev-sub',
      type: 'text',
      x: 150,
      y: 190,
      width: 700,
      height: 30,
      content: 'THIS CREDENTIAL IS PROUDLY CONFERRED UPON',
      fontFamily: 'Inter',
      fontSize: 13,
      fontWeight: 600,
      letterSpacing: 3,
      color: theme === 'classic-ivory' ? '#64748B' : '#94A3B8',
      textAlign: 'center',
      zIndex: 10,
    },
    {
      id: 'prev-recip',
      type: 'token',
      tokenName: '{{recipient_name}}',
      x: 100,
      y: 235,
      width: 800,
      height: 55,
      content: recipientName,
      fontFamily: 'Cinzel',
      fontSize: 36,
      fontWeight: 700,
      color: '#F59E0B',
      textAlign: 'center',
      zIndex: 11,
    },
    {
      id: 'prev-desc',
      type: 'text',
      x: 120,
      y: 305,
      width: 760,
      height: 40,
      content: 'for demonstrated academic mastery, practical competence, and successful fulfillment in',
      fontFamily: 'Inter',
      fontSize: 15,
      color: theme === 'classic-ivory' ? '#475569' : '#CBD5E1',
      textAlign: 'center',
      zIndex: 10,
    },
    {
      id: 'prev-course',
      type: 'token',
      tokenName: '{{course}}',
      x: 100,
      y: 355,
      width: 800,
      height: 45,
      content: courseTitle,
      fontFamily: 'Sora',
      fontSize: 24,
      fontWeight: 700,
      color: theme === 'classic-ivory' ? '#1E3A8A' : '#06B6D4',
      textAlign: 'center',
      zIndex: 11,
    },
    {
      id: 'prev-grade',
      type: 'text',
      x: 150,
      y: 415,
      width: 700,
      height: 25,
      content: `Honors: ${grade} • Blockchain Verified`,
      fontFamily: 'Inter',
      fontSize: 12,
      color: theme === 'classic-ivory' ? '#64748B' : '#94A3B8',
      textAlign: 'center',
      zIndex: 10,
    },
    {
      id: 'prev-seal',
      type: 'seal',
      x: 440,
      y: 470,
      width: 120,
      height: 120,
      sealVariant: sealVariant,
      sealText: sealText,
      sealSubtext: sealSubtext,
      zIndex: 12,
    },
    {
      id: 'prev-sig1',
      type: 'signature',
      x: 120,
      y: 490,
      width: 220,
      height: 90,
      signerName: signer1Name,
      signerTitle: signer1Title,
      signatureStyle: 'classic',
      zIndex: 10,
    },
    {
      id: 'prev-sig2',
      type: 'signature',
      x: 660,
      y: 490,
      width: 220,
      height: 90,
      signerName: signer2Name,
      signerTitle: signer2Title,
      signatureStyle: 'formal',
      zIndex: 10,
    },
    {
      id: 'prev-qr',
      type: 'qr',
      tokenName: '{{qr}}',
      x: 60,
      y: 580,
      width: 75,
      height: 75,
      zIndex: 15,
    },
    {
      id: 'prev-certno',
      type: 'token',
      tokenName: '{{cert_no}}',
      x: 150,
      y: 630,
      width: 300,
      height: 25,
      content: 'ID: CV-LIVE-2026-990142',
      fontFamily: 'Fira Code',
      fontSize: 11,
      color: '#64748B',
      textAlign: 'left',
      zIndex: 10,
    },
    {
      id: 'prev-date',
      type: 'token',
      tokenName: '{{date}}',
      x: 650,
      y: 630,
      width: 280,
      height: 25,
      content: `Issued: ${issueDate}`,
      fontFamily: 'Inter',
      fontSize: 12,
      color: '#64748B',
      textAlign: 'right',
      zIndex: 10,
    },
  ];

  // Handle AI autofill
  const handleAiAutofill = () => {
    if (!aiPrompt) return;
    setIsAiGenerating(true);
    setTimeout(() => {
      const lower = aiPrompt.toLowerCase();
      if (lower.includes('doctor') || lower.includes('health') || lower.includes('medicine')) {
        setCertTitle('Board Certification in Clinical Medicine');
        setCourseTitle('Advanced Robotic Surgery & Minimally Invasive Intervention');
        setTheme('emerald-crest');
        setSealVariant('gold-foil');
        setSigner1Title('Chief Medical Officer');
        setSigner2Title('President of Medical Board');
      } else if (lower.includes('cyber') || lower.includes('security') || lower.includes('hack')) {
        setCertTitle('Certified Chief Information Security Officer');
        setCourseTitle('Zero-Trust Architecture & Offensive Threat Hunting');
        setTheme('cyber-slate');
        setSealVariant('indigo-shield');
        setSigner1Title('Director of Cyber Operations');
        setSigner2Title('CISO Board Chancellor');
      } else if (lower.includes('business') || lower.includes('mba') || lower.includes('lead')) {
        setCertTitle('Executive Leadership & Corporate Governance');
        setCourseTitle('Global Strategic Management & Market Expansion');
        setTheme('royal-gold');
        setSealVariant('gold-foil');
        setSigner1Title('Dean of Executive Education');
        setSigner2Title('Chancellor');
      } else {
        setCertTitle('Certificate of Professional Mastery');
        setCourseTitle(aiPrompt.length > 50 ? aiPrompt.substring(0, 48) + '...' : aiPrompt);
        setTheme('dark-sapphire');
        setSealVariant('cyan-crest');
      }
      setIsAiGenerating(false);
      confetti({ particleCount: 60, spread: 50 });
    }, 800);
  };

  // Handle issuance
  const handleIssueNow = () => {
    const token = `tok_live_${Math.random().toString(36).substring(2, 10)}${Math.random().toString(36).substring(2, 10)}`;
    const certNo = `CV-CERT-2026-${Math.floor(100000 + Math.random() * 900000)}`;

    const newRecord = issueCertificate({
      certNo,
      token,
      templateId: 'custom-created-space',
      recipientName,
      recipientEmail,
      course: courseTitle,
      issueDate,
      expiryDate: expiryDate || undefined,
      grade,
      skills: skills.split(',').map((s) => s.trim()).filter(Boolean),
      issuerName: signer1Name,
      issuerTitle: signer1Title,
      issuerOrg: orgName,
      countryPack: currentOrg.countryPack,
    });

    setIssuedResult(newRecord);
    confetti({
      particleCount: 120,
      spread: 80,
      origin: { y: 0.6 },
    });
  };

  // Open this design in the full visual canvas studio
  const handleOpenInCanvasStudio = () => {
    const customTmpl: CertificateTemplate = {
      id: `tmpl-user-created-${Date.now().toString(36)}`,
      title: certTitle,
      description: courseTitle,
      category: 'Education',
      industry: 'Global',
      language: 'English',
      orientation,
      paper: 'A4',
      width: 1000,
      height: 707,
      bgTheme: theme,
      elements: previewElements,
      thumbnailGradient: 'from-indigo-900 via-slate-900 to-cyan-950',
    };
    setSelectedTemplate(customTmpl);
    setCanvasElements(previewElements);
    setActiveTab('editor');
  };

  return (
    <div className="min-h-[calc(100vh-64px)] bg-[#0B0F1E] text-slate-100 p-4 sm:p-6 lg:p-8 space-y-8">
      {/* Space Header */}
      <div className="flex flex-col md:flex-row md:items-end justify-between gap-4 border-b border-slate-800 pb-6">
        <div>
          <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-cyan-500/10 border border-cyan-500/20 text-cyan-400 text-xs font-semibold mb-3">
            <Award className="w-3.5 h-3.5 text-cyan-400" />
            Dedicated Creation Workspace • Real-Time Dual Pane
          </div>
          <h1 className="text-3xl md:text-4xl font-sora font-extrabold tracking-tight text-white">
            Create <span className="text-cyan-400">Certification</span>
          </h1>
          <p className="text-slate-400 text-sm mt-1 max-w-2xl">
            A dedicated, distraction-free space to formulate, design, sign, and issue verified
            cryptographic credentials with live instant rendering.
          </p>
        </div>

        {/* Action CTAs */}
        <div className="flex items-center gap-3">
          <button
            onClick={handleOpenInCanvasStudio}
            className="px-4 py-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs font-semibold flex items-center gap-2 border border-slate-700 transition"
          >
            <Sliders className="w-3.5 h-3.5 text-cyan-400" />
            <span>Open in Freeform Canvas</span>
          </button>
          <button
            onClick={handleIssueNow}
            className="px-5 py-2 rounded-xl bg-gradient-to-r from-indigo-600 to-cyan-600 hover:from-indigo-500 hover:to-cyan-500 text-white font-bold text-xs shadow-lg shadow-indigo-600/30 flex items-center gap-2 transition active:scale-95"
          >
            <Sparkles className="w-4 h-4 text-yellow-300" />
            <span>Issue & Generate Now</span>
          </button>
        </div>
      </div>

      {/* Main Split-Pane Workspace */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start">
        {/* Left 5 Cols: Dedicated Configuration Workspace */}
        <div className="lg:col-span-5 space-y-6">
          {/* Mode Switcher */}
          <div className="bg-slate-900/90 rounded-2xl border border-slate-800 p-2 flex text-xs font-semibold">
            <button
              onClick={() => setCreationMode('guided')}
              className={`flex-1 py-2.5 rounded-xl flex items-center justify-center gap-2 transition ${
                creationMode === 'guided'
                  ? 'bg-indigo-600 text-white shadow'
                  : 'text-slate-400 hover:text-white'
              }`}
            >
              <User className="w-3.5 h-3.5" />
              <span>Step-by-Step Fields</span>
            </button>
            <button
              onClick={() => setCreationMode('ai_prompt')}
              className={`flex-1 py-2.5 rounded-xl flex items-center justify-center gap-2 transition ${
                creationMode === 'ai_prompt'
                  ? 'bg-cyan-600 text-white shadow'
                  : 'text-slate-400 hover:text-white'
              }`}
            >
              <Wand2 className="w-3.5 h-3.5 text-yellow-300" />
              <span>AI Smart Fill</span>
            </button>
          </div>

          {/* AI Prompt Assistant Banner */}
          {creationMode === 'ai_prompt' && (
            <div className="bg-slate-900/90 rounded-2xl border border-slate-800 p-5 space-y-3 animate-in fade-in">
              <div className="flex items-center gap-2 text-xs font-bold text-cyan-400">
                <Sparkles className="w-4 h-4" />
                <span>Describe your desired credential:</span>
              </div>
              <textarea
                value={aiPrompt}
                onChange={(e) => setAiPrompt(e.target.value)}
                placeholder="e.g. Executive MBA certificate in Artificial Intelligence & Quantitative Finance for Sarah Connor with summa cum laude distinction..."
                rows={3}
                className="w-full bg-slate-950 border border-slate-700 rounded-xl p-3 text-xs text-slate-100 placeholder:text-slate-500 focus:outline-none focus:border-cyan-400"
              />
              <button
                onClick={handleAiAutofill}
                disabled={isAiGenerating || !aiPrompt}
                className="w-full py-2.5 rounded-xl bg-cyan-600 hover:bg-cyan-500 disabled:opacity-50 text-white text-xs font-bold flex items-center justify-center gap-2"
              >
                {isAiGenerating ? (
                  <RefreshCw className="w-3.5 h-3.5 animate-spin" />
                ) : (
                  <Wand2 className="w-3.5 h-3.5" />
                )}
                <span>Autofill Form with AI</span>
              </button>
            </div>
          )}

          {/* Section 1: Recipient & Award */}
          <div className="bg-slate-900/90 rounded-2xl border border-slate-800 p-5 space-y-4">
            <div className="flex items-center gap-2 pb-2 border-b border-slate-800 text-sm font-bold text-white">
              <User className="w-4 h-4 text-cyan-400" />
              <span>1. Recipient & Award Details</span>
            </div>

            <div className="space-y-3 text-xs">
              <div>
                <label className="text-slate-300 font-semibold block mb-1">
                  Recipient Full Name & Honors
                </label>
                <input
                  type="text"
                  value={recipientName}
                  onChange={(e) => setRecipientName(e.target.value)}
                  className="w-full bg-slate-950 border border-slate-700 rounded-xl p-2.5 text-slate-100 focus:outline-none focus:border-cyan-400"
                />
              </div>

              <div>
                <label className="text-slate-300 font-semibold block mb-1">
                  Recipient Email (For Digital Wallet Delivery)
                </label>
                <input
                  type="email"
                  value={recipientEmail}
                  onChange={(e) => setRecipientEmail(e.target.value)}
                  className="w-full bg-slate-950 border border-slate-700 rounded-xl p-2.5 text-slate-100 focus:outline-none focus:border-cyan-400 font-mono"
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="text-slate-300 font-semibold block mb-1">
                    Certificate Header
                  </label>
                  <input
                    type="text"
                    value={certTitle}
                    onChange={(e) => setCertTitle(e.target.value)}
                    className="w-full bg-slate-950 border border-slate-700 rounded-xl p-2.5 text-slate-100 focus:outline-none focus:border-cyan-400"
                  />
                </div>
                <div>
                  <label className="text-slate-300 font-semibold block mb-1">
                    Graduation Honors / Grade
                  </label>
                  <input
                    type="text"
                    value={grade}
                    onChange={(e) => setGrade(e.target.value)}
                    className="w-full bg-slate-950 border border-slate-700 rounded-xl p-2.5 text-slate-100 focus:outline-none focus:border-cyan-400"
                  />
                </div>
              </div>

              <div>
                <label className="text-slate-300 font-semibold block mb-1">
                  Course or Specialization Program
                </label>
                <input
                  type="text"
                  value={courseTitle}
                  onChange={(e) => setCourseTitle(e.target.value)}
                  className="w-full bg-slate-950 border border-slate-700 rounded-xl p-2.5 text-slate-100 focus:outline-none focus:border-cyan-400"
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="text-slate-300 font-semibold block mb-1">Issue Date</label>
                  <input
                    type="date"
                    value={issueDate}
                    onChange={(e) => setIssueDate(e.target.value)}
                    className="w-full bg-slate-950 border border-slate-700 rounded-xl p-2.5 text-slate-100 font-mono"
                  />
                </div>
                <div>
                  <label className="text-slate-300 font-semibold block mb-1">
                    Expiration Date (Optional)
                  </label>
                  <input
                    type="date"
                    value={expiryDate}
                    onChange={(e) => setExpiryDate(e.target.value)}
                    className="w-full bg-slate-950 border border-slate-700 rounded-xl p-2.5 text-slate-100 font-mono"
                  />
                </div>
              </div>

              <div>
                <label className="text-slate-300 font-semibold block mb-1">
                  Competencies & Skills (comma separated)
                </label>
                <input
                  type="text"
                  value={skills}
                  onChange={(e) => setSkills(e.target.value)}
                  className="w-full bg-slate-950 border border-slate-700 rounded-xl p-2.5 text-slate-100 focus:outline-none focus:border-cyan-400"
                />
              </div>
            </div>
          </div>

          {/* Section 2: Issuing Authority & Signatures */}
          <div className="bg-slate-900/90 rounded-2xl border border-slate-800 p-5 space-y-4">
            <div className="flex items-center gap-2 pb-2 border-b border-slate-800 text-sm font-bold text-white">
              <Building className="w-4 h-4 text-indigo-400" />
              <span>2. Issuing Authority & Signatures</span>
            </div>

            <div className="space-y-3 text-xs">
              <div>
                <label className="text-slate-300 font-semibold block mb-1">
                  Issuing Organization / University
                </label>
                <input
                  type="text"
                  value={orgName}
                  onChange={(e) => setOrgName(e.target.value)}
                  className="w-full bg-slate-950 border border-slate-700 rounded-xl p-2.5 text-slate-100 focus:outline-none focus:border-cyan-400"
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="text-slate-300 font-semibold block mb-1">
                    Primary Signer Name
                  </label>
                  <input
                    type="text"
                    value={signer1Name}
                    onChange={(e) => setSigner1Name(e.target.value)}
                    className="w-full bg-slate-950 border border-slate-700 rounded-xl p-2 text-slate-100"
                  />
                  <input
                    type="text"
                    placeholder="Signer Title"
                    value={signer1Title}
                    onChange={(e) => setSigner1Title(e.target.value)}
                    className="w-full bg-slate-950 border border-slate-700 rounded-xl p-2 text-slate-400 mt-1.5"
                  />
                </div>

                <div>
                  <label className="text-slate-300 font-semibold block mb-1">
                    Secondary Signer Name
                  </label>
                  <input
                    type="text"
                    value={signer2Name}
                    onChange={(e) => setSigner2Name(e.target.value)}
                    className="w-full bg-slate-950 border border-slate-700 rounded-xl p-2 text-slate-100"
                  />
                  <input
                    type="text"
                    placeholder="Signer Title"
                    value={signer2Title}
                    onChange={(e) => setSigner2Title(e.target.value)}
                    className="w-full bg-slate-950 border border-slate-700 rounded-xl p-2 text-slate-400 mt-1.5"
                  />
                </div>
              </div>
            </div>
          </div>

          {/* Section 3: Visual Theme, Seal & Style */}
          <div className="bg-slate-900/90 rounded-2xl border border-slate-800 p-5 space-y-4">
            <div className="flex items-center gap-2 pb-2 border-b border-slate-800 text-sm font-bold text-white">
              <Palette className="w-4 h-4 text-amber-400" />
              <span>3. Visual Theme & Official Seal</span>
            </div>

            <div className="space-y-3 text-xs">
              <div>
                <label className="text-slate-300 font-semibold block mb-1.5">
                  Background Style
                </label>
                <div className="grid grid-cols-3 gap-2">
                  {[
                    { id: 'dark-sapphire', label: 'Dark Sapphire' },
                    { id: 'royal-gold', label: 'Royal Gold' },
                    { id: 'cyber-slate', label: 'Cyber Slate' },
                    { id: 'classic-ivory', label: 'Classic Ivory' },
                    { id: 'emerald-crest', label: 'Emerald Crest' },
                    { id: 'minimal-frost', label: 'Minimal Frost' },
                  ].map((t) => (
                    <button
                      key={t.id}
                      onClick={() => setTheme(t.id as any)}
                      className={`py-2 px-2.5 rounded-xl border text-center transition ${
                        theme === t.id
                          ? 'bg-slate-800 border-cyan-400 text-white font-bold'
                          : 'bg-slate-950 border-slate-800 text-slate-400 hover:border-slate-700'
                      }`}
                    >
                      {t.label}
                    </button>
                  ))}
                </div>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="text-slate-300 font-semibold block mb-1">
                    Seal Badge Style
                  </label>
                  <select
                    value={sealVariant}
                    onChange={(e) => setSealVariant(e.target.value as any)}
                    className="w-full bg-slate-950 border border-slate-700 rounded-xl p-2 text-slate-200"
                  >
                    <option value="gold-foil">Gold Foil Embossed</option>
                    <option value="cyan-crest">Cyan AI Crest</option>
                    <option value="indigo-shield">Indigo Shield</option>
                    <option value="royal-star">Royal Bologna Star</option>
                  </select>
                </div>

                <div>
                  <label className="text-slate-300 font-semibold block mb-1">
                    Anti-Copy Guilloche
                  </label>
                  <button
                    onClick={() => setShowGuilloche(!showGuilloche)}
                    className={`w-full py-2 rounded-xl border text-center font-semibold transition ${
                      showGuilloche
                        ? 'bg-cyan-500/10 border-cyan-500/40 text-cyan-300'
                        : 'bg-slate-950 border-slate-800 text-slate-500'
                    }`}
                  >
                    {showGuilloche ? 'Guilloche Enabled' : 'Guilloche Disabled'}
                  </button>
                </div>
              </div>
            </div>
          </div>
        </div>

        {/* Right 7 Cols: Live Real-Time Rendering & Export Station */}
        <div className="lg:col-span-7 space-y-6 lg:sticky lg:top-24">
          {/* Live Preview Canvas Container */}
          <div className="bg-[#070A14] rounded-2xl border border-slate-800 p-6 flex flex-col items-center justify-center shadow-2xl relative overflow-hidden">
            <div className="w-full flex items-center justify-between pb-3 border-b border-slate-800/80 mb-2">
              <div className="flex items-center gap-2">
                <span className="w-2.5 h-2.5 rounded-full bg-cyan-400 animate-pulse" />
                <span className="text-xs font-mono font-bold text-slate-300">
                  REAL-TIME WYSIWYG PREVIEW
                </span>
              </div>
              <span className="text-[10px] font-mono uppercase bg-slate-900 text-slate-400 px-2 py-0.5 rounded border border-slate-800">
                300 DPI CMYK Ready
              </span>
            </div>

            {/* Scaled Preview Frame */}
            <div className="w-full overflow-x-auto flex items-center justify-center py-4">
              <div className="transform scale-[0.62] sm:scale-[0.7] xl:scale-[0.75] origin-top transition-transform duration-300">
                <div id="create-space-certificate-render">
                  <CertificateRenderer
                    elements={previewElements}
                    width={1000}
                    height={707}
                    bgTheme={theme}
                    isPrintOrExport={true}
                    recipientData={{
                      name: recipientName,
                      course: courseTitle,
                      date: issueDate,
                      certNo: 'CV-LIVE-2026-990142',
                      grade: grade,
                    }}
                  />
                </div>
              </div>
            </div>

            {/* Quick Export Bar */}
            <div className="w-full flex flex-wrap items-center justify-between gap-3 pt-4 border-t border-slate-800/80">
              <span className="text-xs text-slate-400">
                Ed25519 Signed • SHA-256 Ledger Authenticated
              </span>
              <div className="flex items-center gap-2">
                <button
                  onClick={() =>
                    exportCertificatePdf(
                      'create-space-certificate-render',
                      `${recipientName.replace(/\s+/g, '_')}_Official.pdf`
                    )
                  }
                  className="px-3.5 py-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs font-semibold flex items-center gap-1.5 border border-slate-700 transition"
                >
                  <FileDown className="w-3.5 h-3.5 text-cyan-400" />
                  <span>300 DPI PDF</span>
                </button>
                <button
                  onClick={() =>
                    exportCertificatePng(
                      'create-space-certificate-render',
                      `${recipientName.replace(/\s+/g, '_')}.png`
                    )
                  }
                  className="px-3.5 py-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs font-semibold flex items-center gap-1.5 border border-slate-700 transition"
                >
                  <FileDown className="w-3.5 h-3.5 text-amber-400" />
                  <span>PNG</span>
                </button>
                <button
                  onClick={() => window.print()}
                  className="px-3 py-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs font-semibold flex items-center gap-1 border border-slate-700 transition"
                >
                  <Printer className="w-3.5 h-3.5 text-slate-400" />
                  <span>Print</span>
                </button>
              </div>
            </div>
          </div>

          {/* Success Notification Banner after issuance */}
          {issuedResult && (
            <div className="p-5 rounded-2xl bg-emerald-950/50 border border-emerald-500/50 text-emerald-200 space-y-3 shadow-xl animate-in fade-in">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-2.5">
                  <CheckCircle2 className="w-5 h-5 text-emerald-400 shrink-0" />
                  <h4 className="font-sora font-bold text-sm text-white">
                    Certificate Successfully Issued & Registered!
                  </h4>
                </div>
                <span className="font-mono text-xs font-bold text-emerald-300">
                  {issuedResult.certNo}
                </span>
              </div>

              <p className="text-xs text-emerald-300/80">
                Cryptographically anchored on public registry. Recipient can now verify and add to
                LinkedIn.
              </p>

              <div className="flex items-center gap-3 pt-2">
                <button
                  onClick={() => {
                    setPublicVerifyToken(issuedResult.token);
                    setActiveTab('verify');
                  }}
                  className="px-4 py-1.5 rounded-lg bg-emerald-600 hover:bg-emerald-500 text-white text-xs font-bold flex items-center gap-1.5 transition"
                >
                  <ShieldCheck className="w-3.5 h-3.5" />
                  <span>Open Public Verification Page</span>
                </button>
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
