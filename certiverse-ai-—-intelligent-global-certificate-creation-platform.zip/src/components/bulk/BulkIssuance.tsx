import React, { useState } from 'react';
import { useCert } from '../../context/CertContext';
import { BulkImportRow, BulkBatch } from '../../types';
import {
  Upload,
  FileSpreadsheet,
  CheckCircle2,
  AlertCircle,
  Play,
  Download,
  Mail,
  Layers,
  Sparkles,
  RefreshCw,
  Archive,
  ArrowRight,
  Database,
} from 'lucide-react';
import confetti from 'canvas-confetti';

const SAMPLE_CSV_DATA: BulkImportRow[] = [
  {
    recipient_name: 'Sophia Elizabeth Martinez',
    recipient_email: 'sophia.m@mit.alumni.edu',
    course: 'Advanced Deep Learning & Agentic Architecture',
    grade: 'Summa Cum Laude (99.2%)',
    issue_date: '2026-10-09',
    skills: 'PyTorch, RAG, RLHF, Fine-Tuning',
  },
  {
    recipient_name: 'Hiroshi Tanaka',
    recipient_email: 'h.tanaka@tokyo.ac.jp',
    course: 'Advanced Deep Learning & Agentic Architecture',
    grade: 'High Distinction (96.5%)',
    issue_date: '2026-10-09',
    skills: 'Transformers, Agent Workflows, Embeddings',
  },
  {
    recipient_name: 'Amara Okafor',
    recipient_email: 'a.okafor@africanleadership.org',
    course: 'Advanced Deep Learning & Agentic Architecture',
    grade: 'Distinction (95.0%)',
    issue_date: '2026-10-09',
    skills: 'Computer Vision, PyTorch, Model Ops',
  },
  {
    recipient_name: 'Lucas Beauchamp',
    recipient_email: 'lucas.b@polytechnique.fr',
    course: 'Advanced Deep Learning & Agentic Architecture',
    grade: 'Distinction (94.2%)',
    issue_date: '2026-10-09',
    skills: 'NLP, Large Language Models, LoRA',
  },
  {
    recipient_name: 'Priya Sundaram',
    recipient_email: 'priya.sundaram@iitb.ac.in',
    course: 'Advanced Deep Learning & Agentic Architecture',
    grade: 'High Distinction (98.1%)',
    issue_date: '2026-10-09',
    skills: 'CUDA Optimization, Distributed Training',
  },
  {
    recipient_name: 'Nikolai Volkov',
    recipient_email: 'n.volkov@infosec-hub.de',
    course: 'Advanced Deep Learning & Agentic Architecture',
    grade: 'First Class Honors (93.8%)',
    issue_date: '2026-10-09',
    skills: 'Red Team AI, Safety Alignment',
  },
];

export const BulkIssuance: React.FC = () => {
  const { templates, currentOrg, addBulkBatch, bulkBatches, updateBulkBatch, issueCertificate } =
    useCert();

  const [selectedTemplateId, setSelectedTemplateId] = useState<string>(templates[0].id);
  const [importedRows, setImportedRows] = useState<BulkImportRow[]>(SAMPLE_CSV_DATA);
  const [columnMapping, setColumnMapping] = useState({
    recipient_name: 'recipient_name',
    recipient_email: 'recipient_email',
    course: 'course',
    grade: 'grade',
    issue_date: 'issue_date',
    skills: 'skills',
  });

  const [isProcessing, setIsProcessing] = useState(false);
  const [progressPercent, setProgressPercent] = useState(0);
  const [currentProgressRow, setCurrentProgressRow] = useState(0);
  const [logs, setLogs] = useState<string[]>([]);
  const [activeBatch, setActiveBatch] = useState<BulkBatch | null>(null);

  const handleFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    const reader = new FileReader();
    reader.onload = (event) => {
      const text = event.target?.result as string;
      const lines = text.split('\n').filter((l) => l.trim().length > 0);
      if (lines.length > 1) {
        const headers = lines[0].split(',').map((h) => h.trim().replace(/^"|"$/g, ''));
        const parsedRows: BulkImportRow[] = [];

        for (let i = 1; i < lines.length; i++) {
          const cols = lines[i].split(',').map((c) => c.trim().replace(/^"|"$/g, ''));
          const row: any = {};
          headers.forEach((h, index) => {
            row[h.toLowerCase().replace(/\s+/g, '_')] = cols[index] || '';
          });

          parsedRows.push({
            recipient_name: row.recipient_name || row.name || `Student #${i}`,
            recipient_email: row.recipient_email || row.email || `student${i}@example.com`,
            course: row.course || row.program || 'AI Specialization',
            grade: row.grade || 'Passed',
            issue_date: row.issue_date || new Date().toISOString().substring(0, 10),
            skills: row.skills || 'AI, Python',
          });
        }

        setImportedRows(parsedRows);
      }
    };
    reader.readAsText(file);
  };

  const load50StudentBatch = () => {
    const generated: BulkImportRow[] = [];
    const names = [
      'Liam Anderson', 'Emma Watson', 'Noah Garcia', 'Olivia Miller', 'James Davis',
      'Ava Rodriguez', 'William Martinez', 'Sophia Hernandez', 'Benjamin Lopez', 'Isabella Gonzalez',
      'Lucas Wilson', 'Mia Anderson', 'Henry Thomas', 'Evelyn Taylor', 'Alexander Moore',
      'Harper Jackson', 'Daniel Martin', 'Camila Lee', 'Matthew Perez', 'Gianna Thompson',
      'Samuel White', 'Abigail Harris', 'David Sanchez', 'Emily Clark', 'Joseph Ramirez',
    ];

    for (let i = 0; i < 48; i++) {
      const name = `${names[i % names.length]} (${i + 1})`;
      generated.push({
        recipient_name: name,
        recipient_email: `student_${i + 1}@university.edu`,
        course: templates.find((t) => t.id === selectedTemplateId)?.title || 'AI Mastery',
        grade: ['Distinction', 'Honors', 'High Pass', 'Top 5%'][i % 4],
        issue_date: '2026-10-09',
        skills: 'Deep Learning, System Design, Vector Search',
      });
    }
    setImportedRows(generated);
  };

  const startBatchExecution = async () => {
    if (importedRows.length === 0) return;

    setIsProcessing(true);
    setProgressPercent(0);
    setCurrentProgressRow(0);
    setLogs([]);

    const batchId = `batch-sharded-${Date.now().toString(36)}`;
    const newBatch: BulkBatch = {
      id: batchId,
      name: `Batch Issuance: ${importedRows.length} Credentials (${new Date().toLocaleTimeString()})`,
      totalRows: importedRows.length,
      processedRows: 0,
      successCount: 0,
      failedCount: 0,
      status: 'processing',
      templateId: selectedTemplateId,
      createdAt: new Date().toISOString().replace('T', ' ').substring(0, 19),
      downloadZipReady: false,
    };

    addBulkBatch(newBatch);
    setActiveBatch(newBatch);

    const total = importedRows.length;
    let successCount = 0;

    // Simulate sharded parallel batch with SSE streaming
    for (let i = 0; i < total; i++) {
      await new Promise((r) => setTimeout(r, Math.max(40, 1200 / total)));

      const row = importedRows[i];
      const token = `tok_live_${Math.random().toString(36).substring(2, 10)}${Math.random().toString(36).substring(2, 10)}`;
      const certNo = `CV-BATCH-2026-${Math.floor(100000 + Math.random() * 900000)}`;

      // Issue individual record into the certificate store
      issueCertificate({
        certNo,
        token,
        templateId: selectedTemplateId,
        recipientName: row.recipient_name,
        recipientEmail: row.recipient_email,
        course: row.course,
        issueDate: row.issue_date || new Date().toISOString().substring(0, 10),
        grade: row.grade,
        skills: row.skills ? row.skills.split(',').map((s) => s.trim()) : [],
        issuerName: 'Dr. Evelyn Zhang',
        issuerTitle: 'Dean of Faculty',
        issuerOrg: currentOrg.name,
        countryPack: currentOrg.countryPack,
      });

      successCount++;
      const currentProcessed = i + 1;
      const pct = Math.round((currentProcessed / total) * 100);

      setProgressPercent(pct);
      setCurrentProgressRow(currentProcessed);

      if (i % Math.ceil(total / 8) === 0 || i === total - 1) {
        setLogs((prev) => [
          `[SSE Worker-0${(i % 4) + 1}] Shard Chunk #${Math.floor(i / 10) + 1}: Generated SHA-256 & signed QR for ${row.recipient_name} -> Queued email via AWS SES`,
          ...prev.slice(0, 12),
        ]);
      }
    }

    updateBulkBatch(batchId, {
      processedRows: total,
      successCount: successCount,
      status: 'completed',
      downloadZipReady: true,
    });

    setIsProcessing(false);
    confetti({
      particleCount: 80,
      spread: 60,
      origin: { y: 0.6 },
    });
  };

  const handleDownloadZipSimulation = () => {
    const dummyBlob = new Blob([`CertiVerse AI Bulk Export Archive: ${importedRows.length} PDFs`], {
      type: 'application/zip',
    });
    const url = URL.createObjectURL(dummyBlob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `Certificates_Batch_${new Date().toISOString().substring(0, 10)}.zip`;
    a.click();
    URL.revokeObjectURL(url);
  };

  return (
    <div className="min-h-[calc(100vh-64px)] bg-[#0B0F1E] text-slate-100 p-6 md:p-8 space-y-8">
      {/* Header Banner */}
      <div className="flex flex-col md:flex-row md:items-end justify-between gap-4 border-b border-slate-800 pb-6">
        <div>
          <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-cyan-500/10 border border-cyan-500/20 text-cyan-400 text-xs font-semibold mb-3">
            <Layers className="w-3.5 h-3.5 text-cyan-400" />
            High-Throughput Sharded Issuance Engine
          </div>
          <h1 className="text-3xl md:text-4xl font-sora font-extrabold tracking-tight text-white">
            Bulk <span className="text-cyan-400">Issuance & Dispatch</span>
          </h1>
          <p className="text-slate-400 text-sm mt-1 max-w-2xl">
            Import CSV or Excel sheets, auto-map dynamic variables, compute SHA-256 hashes in
            parallel worker shards, and dispatch via AWS SES / SendGrid with live SSE telemetry.
          </p>
        </div>

        <div className="flex items-center gap-3">
          <button
            onClick={load50StudentBatch}
            className="px-4 py-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs font-semibold flex items-center gap-2 border border-slate-700 transition"
          >
            <Sparkles className="w-3.5 h-3.5 text-yellow-300" />
            Load Sample Cohort (50 Students)
          </button>
        </div>
      </div>

      {/* 2-Column Workflow Layout */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        {/* Left 2 Cols: Data Upload, Column Mapping & Preview */}
        <div className="lg:col-span-2 space-y-6">
          {/* Step 1: Select Template & Upload */}
          <div className="bg-slate-900/90 rounded-2xl border border-slate-800 p-6 space-y-4">
            <div className="flex items-center justify-between pb-3 border-b border-slate-800">
              <div className="flex items-center gap-2">
                <span className="w-6 h-6 rounded-full bg-indigo-600 text-white flex items-center justify-center text-xs font-bold">
                  1
                </span>
                <h3 className="font-sora font-bold text-sm text-white">Select Blueprint & File</h3>
              </div>
              <span className="text-xs text-slate-400 font-mono">
                {importedRows.length} rows loaded
              </span>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              {/* Template selector */}
              <div>
                <label className="text-xs font-semibold text-slate-300 block mb-1.5">
                  Certificate Blueprint
                </label>
                <select
                  value={selectedTemplateId}
                  onChange={(e) => setSelectedTemplateId(e.target.value)}
                  className="w-full bg-slate-950 border border-slate-700 rounded-xl p-2.5 text-xs text-slate-100 focus:outline-none focus:border-cyan-400"
                >
                  {templates.map((tmpl) => (
                    <option key={tmpl.id} value={tmpl.id} className="bg-slate-900 text-slate-200">
                      {tmpl.title} ({tmpl.category})
                    </option>
                  ))}
                </select>
              </div>

              {/* File upload dropzone */}
              <div>
                <label className="text-xs font-semibold text-slate-300 block mb-1.5">
                  Upload CSV / XLSX Spreadsheet
                </label>
                <label className="w-full bg-slate-950 border border-dashed border-slate-700 hover:border-cyan-400 rounded-xl p-2.5 text-xs text-slate-300 flex items-center justify-center gap-2 cursor-pointer transition">
                  <Upload className="w-4 h-4 text-cyan-400" />
                  <span>Choose file or drag & drop</span>
                  <input
                    type="file"
                    accept=".csv,.txt"
                    onChange={handleFileUpload}
                    className="hidden"
                  />
                </label>
              </div>
            </div>
          </div>

          {/* Step 2: Column Mapping */}
          <div className="bg-slate-900/90 rounded-2xl border border-slate-800 p-6 space-y-4">
            <div className="flex items-center justify-between pb-3 border-b border-slate-800">
              <div className="flex items-center gap-2">
                <span className="w-6 h-6 rounded-full bg-indigo-600 text-white flex items-center justify-center text-xs font-bold">
                  2
                </span>
                <h3 className="font-sora font-bold text-sm text-white">Dynamic Token Mapping</h3>
              </div>
              <span className="text-xs text-emerald-400 font-medium flex items-center gap-1">
                <CheckCircle2 className="w-3.5 h-3.5" /> Auto-mapped 6 columns
              </span>
            </div>

            <div className="grid grid-cols-2 md:grid-cols-3 gap-3 text-xs">
              <div className="bg-slate-950 p-3 rounded-xl border border-slate-800">
                <span className="text-slate-400 block mb-1">Canvas Token:</span>
                <span className="font-mono text-cyan-400 font-bold block">{`{{recipient_name}}`}</span>
                <span className="text-[10px] text-slate-500 mt-2 block">CSV Column:</span>
                <span className="font-medium text-slate-200">recipient_name</span>
              </div>

              <div className="bg-slate-950 p-3 rounded-xl border border-slate-800">
                <span className="text-slate-400 block mb-1">Canvas Token:</span>
                <span className="font-mono text-cyan-400 font-bold block">{`{{course}}`}</span>
                <span className="text-[10px] text-slate-500 mt-2 block">CSV Column:</span>
                <span className="font-medium text-slate-200">course</span>
              </div>

              <div className="bg-slate-950 p-3 rounded-xl border border-slate-800">
                <span className="text-slate-400 block mb-1">Canvas Token:</span>
                <span className="font-mono text-cyan-400 font-bold block">{`{{date}}`}</span>
                <span className="text-[10px] text-slate-500 mt-2 block">CSV Column:</span>
                <span className="font-medium text-slate-200">issue_date</span>
              </div>

              <div className="bg-slate-950 p-3 rounded-xl border border-slate-800">
                <span className="text-slate-400 block mb-1">Canvas Token:</span>
                <span className="font-mono text-cyan-400 font-bold block">{`{{grade}}`}</span>
                <span className="text-[10px] text-slate-500 mt-2 block">CSV Column:</span>
                <span className="font-medium text-slate-200">grade</span>
              </div>

              <div className="bg-slate-950 p-3 rounded-xl border border-slate-800">
                <span className="text-slate-400 block mb-1">System Field:</span>
                <span className="font-mono text-amber-400 font-bold block">recipient_email</span>
                <span className="text-[10px] text-slate-500 mt-2 block">CSV Column:</span>
                <span className="font-medium text-slate-200">recipient_email</span>
              </div>

              <div className="bg-slate-950 p-3 rounded-xl border border-slate-800">
                <span className="text-slate-400 block mb-1">System Field:</span>
                <span className="font-mono text-amber-400 font-bold block">skills</span>
                <span className="text-[10px] text-slate-500 mt-2 block">CSV Column:</span>
                <span className="font-medium text-slate-200">skills</span>
              </div>
            </div>
          </div>

          {/* Step 3: Staged Data Table Preview */}
          <div className="bg-slate-900/90 rounded-2xl border border-slate-800 p-6 space-y-4">
            <div className="flex items-center justify-between pb-3 border-b border-slate-800">
              <div className="flex items-center gap-2">
                <span className="w-6 h-6 rounded-full bg-indigo-600 text-white flex items-center justify-center text-xs font-bold">
                  3
                </span>
                <h3 className="font-sora font-bold text-sm text-white">Staged Rows Preview</h3>
              </div>
              <span className="text-xs text-slate-400">First 5 records displayed</span>
            </div>

            <div className="overflow-x-auto rounded-xl border border-slate-800">
              <table className="w-full text-left text-xs">
                <thead className="bg-slate-950 text-slate-400 font-semibold border-b border-slate-800">
                  <tr>
                    <th className="p-3">#</th>
                    <th className="p-3">Recipient Name</th>
                    <th className="p-3">Recipient Email</th>
                    <th className="p-3">Course Title</th>
                    <th className="p-3">Grade</th>
                    <th className="p-3">Status</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-800">
                  {importedRows.slice(0, 5).map((row, index) => (
                    <tr key={index} className="hover:bg-slate-800/40">
                      <td className="p-3 font-mono text-slate-500">{index + 1}</td>
                      <td className="p-3 font-semibold text-slate-200">{row.recipient_name}</td>
                      <td className="p-3 text-slate-400 font-mono text-[11px]">{row.recipient_email}</td>
                      <td className="p-3 text-cyan-300 truncate max-w-[200px]">{row.course}</td>
                      <td className="p-3 text-amber-400 font-medium">{row.grade || '—'}</td>
                      <td className="p-3">
                        <span className="px-2 py-0.5 rounded bg-emerald-500/10 text-emerald-400 text-[10px] font-bold border border-emerald-500/20">
                          Valid
                        </span>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        </div>

        {/* Right 1 Col: Execution Engine & Telemetry */}
        <div className="space-y-6">
          {/* Action Trigger Card */}
          <div className="bg-slate-900/90 rounded-2xl border border-slate-800 p-6 space-y-5">
            <h3 className="font-sora font-bold text-base text-white">Execution Telemetry</h3>

            {/* Launch Button */}
            <button
              onClick={startBatchExecution}
              disabled={isProcessing || importedRows.length === 0}
              className="w-full py-3 rounded-xl bg-gradient-to-r from-indigo-600 to-cyan-600 hover:from-indigo-500 hover:to-cyan-500 text-white font-bold text-sm shadow-xl shadow-indigo-600/30 flex items-center justify-center gap-2 disabled:opacity-50 transition active:scale-95"
            >
              {isProcessing ? (
                <>
                  <RefreshCw className="w-4 h-4 animate-spin text-cyan-300" />
                  <span>Processing {currentProgressRow}/{importedRows.length}...</span>
                </>
              ) : (
                <>
                  <Play className="w-4 h-4 fill-white" />
                  <span>Launch Bulk Run ({importedRows.length} Rows)</span>
                </>
              )}
            </button>

            {/* Live Progress Bar */}
            <div className="space-y-2">
              <div className="flex justify-between text-xs">
                <span className="text-slate-400">Batch Progress</span>
                <span className="font-mono font-bold text-cyan-400">{progressPercent}%</span>
              </div>
              <div className="w-full h-2.5 bg-slate-950 rounded-full overflow-hidden border border-slate-800">
                <div
                  className="h-full bg-gradient-to-r from-indigo-500 to-cyan-400 transition-all duration-150"
                  style={{ width: `${progressPercent}%` }}
                />
              </div>
              <div className="flex justify-between text-[11px] text-slate-500">
                <span>Processed: {currentProgressRow} / {importedRows.length}</span>
                <span>Worker Shards: 4 parallel</span>
              </div>
            </div>

            {/* SSE Log Stream */}
            <div className="space-y-2">
              <label className="text-[11px] font-bold uppercase tracking-wider text-slate-400 block">
                Server-Sent Events (SSE) Live Feed
              </label>
              <div className="bg-slate-950 border border-slate-800 rounded-xl p-3 h-48 overflow-y-auto font-mono text-[10px] text-slate-300 space-y-1.5 scrollbar-thin scrollbar-thumb-slate-800">
                {logs.length > 0 ? (
                  logs.map((log, i) => (
                    <div key={i} className="text-slate-300 leading-snug">
                      {log}
                    </div>
                  ))
                ) : (
                  <div className="text-slate-600 text-center py-16">
                    Awaiting batch execution trigger...
                  </div>
                )}
              </div>
            </div>

            {/* Post-execution Download */}
            {progressPercent === 100 && (
              <div className="pt-2 animate-in fade-in">
                <button
                  onClick={handleDownloadZipSimulation}
                  className="w-full py-2.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-100 text-xs font-semibold flex items-center justify-center gap-2 border border-slate-700 transition"
                >
                  <Archive className="w-4 h-4 text-cyan-400" />
                  <span>Download Complete ZIP Archive</span>
                </button>
              </div>
            )}
          </div>

          {/* Historical Batches */}
          <div className="bg-slate-900/90 rounded-2xl border border-slate-800 p-6 space-y-3">
            <h4 className="font-sora font-bold text-sm text-white">Recent Cohort Batches</h4>
            <div className="space-y-2.5">
              {bulkBatches.map((batch) => (
                <div
                  key={batch.id}
                  className="p-3 rounded-xl bg-slate-950 border border-slate-800/80 text-xs space-y-1.5"
                >
                  <div className="flex justify-between items-start">
                    <span className="font-semibold text-slate-200 truncate max-w-[180px]">
                      {batch.name}
                    </span>
                    <span className="text-[10px] font-bold uppercase px-1.5 py-0.5 rounded bg-emerald-500/20 text-emerald-400">
                      {batch.status}
                    </span>
                  </div>
                  <div className="flex justify-between text-[11px] text-slate-400">
                    <span>{batch.totalRows} Credentials</span>
                    <span className="font-mono text-slate-500">{batch.createdAt.substring(0, 10)}</span>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
