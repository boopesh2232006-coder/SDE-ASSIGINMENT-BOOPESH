import React, { useState } from 'react';
import { useCert } from '../../context/CertContext';
import { CertificateRenderer } from './CertificateRenderer';
import { exportCertificatePdf, exportCertificatePng } from '../../utils/exportCert';
import confetti from 'canvas-confetti';
import {
  Undo2,
  Redo2,
  ZoomIn,
  ZoomOut,
  Maximize2,
  FileDown,
  Printer,
  Sparkles,
  Layers,
  Lock,
  Unlock,
  Copy,
  Trash2,
  MoveUp,
  MoveDown,
  Type,
  Award,
  PenTool,
  QrCode,
  ShieldCheck,
  CheckCircle2,
  LayoutGrid,
  Palette,
  ExternalLink,
} from 'lucide-react';

export const VisualEditor: React.FC = () => {
  const {
    selectedTemplate,
    canvasElements,
    selectedElementId,
    setSelectedElementId,
    updateElement,
    addElement,
    removeElement,
    duplicateElement,
    moveElementLayer,
    undo,
    redo,
    canUndo,
    canRedo,
    activeSampleRecipient,
    setActiveSampleRecipient,
    issueCertificate,
    setActiveTab,
    setPublicVerifyToken,
    currentOrg,
  } = useCert();

  const [zoomScale, setZoomScale] = useState<number>(0.85);
  const [showBleedMargins, setShowBleedMargins] = useState<boolean>(true);
  const [showRulers, setShowRulers] = useState<boolean>(true);
  const [activeLeftTab, setActiveLeftTab] = useState<'elements' | 'layers' | 'settings'>('elements');
  const [isExporting, setIsExporting] = useState<boolean>(false);
  const [issueModalOpen, setIssueModalOpen] = useState<boolean>(false);

  // Form for single issuance modal
  const [issueForm, setIssueForm] = useState({
    recipientName: activeSampleRecipient.name,
    recipientEmail: 'alex.vance@stanford.alumni.edu',
    course: activeSampleRecipient.course,
    grade: 'Distinction (98.6%)',
    skills: 'Machine Learning, Neural Networks, Agent Workflows',
  });

  const selectedElement = canvasElements.find((el) => el.id === selectedElementId);

  // Recipient Switcher Presets
  const sampleRecipients = [
    {
      name: 'Alexander Vance, M.Sc.',
      course: selectedTemplate.title,
      date: 'October 9, 2026',
      certNo: 'CV-AI-2026-884920',
      grade: 'Distinction (98.6%)',
    },
    {
      name: 'Dr. Sophia Patel, MD, Ph.D.',
      course: 'Cardiovascular Intervention & Bio-Robotics',
      date: 'October 15, 2026',
      certNo: 'CV-MED-2026-440192',
      grade: 'Top 1% Percentile',
    },
    {
      name: 'Mei-Ling Chen',
      course: 'Cloud Distributed Systems & Kubernetes',
      date: 'September 28, 2026',
      certNo: 'CV-CLD-2026-102948',
      grade: 'Summa Cum Laude',
    },
    {
      name: 'Aarav Rajesh Sharma',
      course: 'AI & Data Engineering (NSQF Level 6)',
      date: 'October 5, 2026',
      certNo: 'CV-NSDC-2026-661092',
      grade: 'Grade A+ Certified',
    },
  ];

  const handleExportPdf = async () => {
    setIsExporting(true);
    try {
      await exportCertificatePdf('certificate-canvas-root', `${selectedTemplate.title.replace(/\s+/g, '_')}_300DPI.pdf`);
    } catch (err) {
      console.error('Export failed', err);
    } finally {
      setIsExporting(false);
    }
  };

  const handleExportPng = async () => {
    setIsExporting(true);
    try {
      await exportCertificatePng('certificate-canvas-root', `${selectedTemplate.title.replace(/\s+/g, '_')}.png`);
    } catch (err) {
      console.error('Export failed', err);
    } finally {
      setIsExporting(false);
    }
  };

  const handlePrint = () => {
    window.print();
  };

  const handleIssueSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const token = `tok_live_${Math.random().toString(36).substring(2, 10)}${Math.random().toString(36).substring(2, 10)}`;
    const certNo = `CV-${selectedTemplate.category.substring(0, 3).toUpperCase()}-2026-${Math.floor(100000 + Math.random() * 900000)}`;

    const newRecord = issueCertificate({
      certNo,
      token,
      templateId: selectedTemplate.id,
      recipientName: issueForm.recipientName,
      recipientEmail: issueForm.recipientEmail,
      course: issueForm.course,
      issueDate: new Date().toISOString().substring(0, 10),
      grade: issueForm.grade,
      skills: issueForm.skills.split(',').map((s) => s.trim()).filter(Boolean),
      issuerName: 'Dr. Evelyn Zhang',
      issuerTitle: 'Director of AI Research',
      issuerOrg: currentOrg.name,
      countryPack: currentOrg.countryPack,
    });

    confetti({
      particleCount: 100,
      spread: 70,
      origin: { y: 0.6 },
    });

    setIssueModalOpen(false);
    setPublicVerifyToken(newRecord.token);
    setActiveTab('verify');
  };

  return (
    <div className="flex flex-col h-[calc(100vh-64px)] overflow-hidden bg-slate-950 text-slate-100">
      {/* Top Action Bar */}
      <div className="h-14 border-b border-slate-800 bg-slate-900/90 backdrop-blur px-4 flex items-center justify-between shrink-0 z-30">
        {/* Left: Template info & Undo/Redo */}
        <div className="flex items-center gap-3">
          <div className="flex items-center gap-2 pr-3 border-r border-slate-800">
            <span className="font-semibold text-sm text-slate-200 truncate max-w-[220px]">
              {selectedTemplate.title}
            </span>
            <span className="text-[10px] uppercase font-bold px-2 py-0.5 rounded bg-indigo-500/20 text-indigo-400 border border-indigo-500/30">
              {selectedTemplate.orientation} • {selectedTemplate.paper}
            </span>
          </div>

          <div className="flex items-center gap-1">
            <button
              onClick={undo}
              disabled={!canUndo}
              title="Undo (Ctrl+Z)"
              className="p-1.5 rounded hover:bg-slate-800 text-slate-400 hover:text-slate-100 disabled:opacity-30 disabled:pointer-events-none"
            >
              <Undo2 className="w-4 h-4" />
            </button>
            <button
              onClick={redo}
              disabled={!canRedo}
              title="Redo (Ctrl+Y)"
              className="p-1.5 rounded hover:bg-slate-800 text-slate-400 hover:text-slate-100 disabled:opacity-30 disabled:pointer-events-none"
            >
              <Redo2 className="w-4 h-4" />
            </button>
          </div>
        </div>

        {/* Center: Live Recipient Simulation & View Controls */}
        <div className="flex items-center gap-3">
          {/* Sample recipient selector */}
          <div className="flex items-center gap-1.5 text-xs bg-slate-800/80 px-2.5 py-1 rounded-md border border-slate-700">
            <span className="text-slate-400 font-medium">Preview Recipient:</span>
            <select
              value={activeSampleRecipient.name}
              onChange={(e) => {
                const found = sampleRecipients.find((r) => r.name === e.target.value);
                if (found) {
                  setActiveSampleRecipient(found);
                  setIssueForm((prev) => ({
                    ...prev,
                    recipientName: found.name,
                    course: found.course,
                  }));
                }
              }}
              className="bg-transparent text-cyan-400 font-semibold focus:outline-none cursor-pointer"
            >
              {sampleRecipients.map((r) => (
                <option key={r.name} value={r.name} className="bg-slate-900 text-slate-200">
                  {r.name}
                </option>
              ))}
            </select>
          </div>

          {/* Bleed Guideline Toggle */}
          <button
            onClick={() => setShowBleedMargins(!showBleedMargins)}
            className={`px-2.5 py-1 rounded text-xs font-medium border flex items-center gap-1 transition ${
              showBleedMargins
                ? 'bg-rose-500/10 border-rose-500/40 text-rose-400'
                : 'bg-slate-800 border-slate-700 text-slate-400 hover:text-slate-200'
            }`}
          >
            3mm Bleed {showBleedMargins ? 'ON' : 'OFF'}
          </button>

          {/* Rulers Toggle */}
          <button
            onClick={() => setShowRulers(!showRulers)}
            className={`px-2.5 py-1 rounded text-xs font-medium border flex items-center gap-1 transition ${
              showRulers
                ? 'bg-indigo-500/10 border-indigo-500/40 text-indigo-400'
                : 'bg-slate-800 border-slate-700 text-slate-400 hover:text-slate-200'
            }`}
          >
            <LayoutGrid className="w-3.5 h-3.5" />
            Rulers
          </button>

          {/* Zoom Controls */}
          <div className="flex items-center gap-1 bg-slate-800/80 rounded px-1.5 py-0.5 border border-slate-700">
            <button
              onClick={() => setZoomScale(Math.max(0.4, zoomScale - 0.1))}
              className="p-1 hover:text-cyan-400 text-slate-400"
            >
              <ZoomOut className="w-3.5 h-3.5" />
            </button>
            <span className="text-[11px] font-mono text-slate-300 w-10 text-center">
              {Math.round(zoomScale * 100)}%
            </span>
            <button
              onClick={() => setZoomScale(Math.min(1.4, zoomScale + 0.1))}
              className="p-1 hover:text-cyan-400 text-slate-400"
            >
              <ZoomIn className="w-3.5 h-3.5" />
            </button>
            <button
              onClick={() => setZoomScale(0.85)}
              title="Reset Zoom"
              className="p-1 hover:text-cyan-400 text-slate-400"
            >
              <Maximize2 className="w-3 h-3" />
            </button>
          </div>
        </div>

        {/* Right: Export & Issue CTA */}
        <div className="flex items-center gap-2">
          {/* Export Dropdown */}
          <div className="relative group">
            <button
              disabled={isExporting}
              className="px-3 py-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs font-semibold flex items-center gap-1.5 border border-slate-700 transition"
            >
              <FileDown className="w-4 h-4 text-cyan-400" />
              {isExporting ? 'Exporting...' : 'Export'}
            </button>
            <div className="absolute right-0 top-full mt-1 w-48 bg-slate-900 border border-slate-800 rounded-lg shadow-2xl p-1.5 hidden group-hover:block z-50">
              <button
                onClick={handleExportPdf}
                className="w-full text-left px-2.5 py-1.5 text-xs text-slate-200 hover:bg-indigo-600/30 rounded flex items-center justify-between"
              >
                <span>300 DPI PDF (Print)</span>
                <span className="text-[10px] text-amber-400 font-bold">CMYK</span>
              </button>
              <button
                onClick={handleExportPng}
                className="w-full text-left px-2.5 py-1.5 text-xs text-slate-200 hover:bg-indigo-600/30 rounded flex items-center justify-between"
              >
                <span>High-Res PNG</span>
                <span className="text-[10px] text-slate-400">2x</span>
              </button>
              <button
                onClick={handlePrint}
                className="w-full text-left px-2.5 py-1.5 text-xs text-slate-200 hover:bg-indigo-600/30 rounded flex items-center gap-1.5"
              >
                <Printer className="w-3.5 h-3.5 text-slate-400" />
                <span>System Print</span>
              </button>
            </div>
          </div>

          {/* Issue Certificate Button */}
          <button
            onClick={() => setIssueModalOpen(true)}
            className="px-4 py-1.5 rounded-lg bg-gradient-to-r from-indigo-600 to-cyan-600 hover:from-indigo-500 hover:to-cyan-500 text-white text-xs font-bold shadow-lg shadow-indigo-600/20 flex items-center gap-1.5 transition active:scale-95"
          >
            <Sparkles className="w-4 h-4 text-yellow-300" />
            Issue Live Credential
          </button>
        </div>
      </div>

      {/* Main Studio Body: 3-Column Layout */}
      <div className="flex-1 flex overflow-hidden">
        {/* Left Sidebar: Toolbox & Layer Stack */}
        <div className="w-72 border-r border-slate-800 bg-slate-900/95 flex flex-col shrink-0">
          {/* Tabs */}
          <div className="flex border-b border-slate-800 text-xs font-medium">
            <button
              onClick={() => setActiveLeftTab('elements')}
              className={`flex-1 py-2.5 text-center flex items-center justify-center gap-1.5 transition ${
                activeLeftTab === 'elements'
                  ? 'border-b-2 border-indigo-500 text-indigo-400 bg-slate-800/40'
                  : 'text-slate-400 hover:text-slate-200'
              }`}
            >
              <Type className="w-3.5 h-3.5" />
              Elements
            </button>
            <button
              onClick={() => setActiveLeftTab('layers')}
              className={`flex-1 py-2.5 text-center flex items-center justify-center gap-1.5 transition ${
                activeLeftTab === 'layers'
                  ? 'border-b-2 border-indigo-500 text-indigo-400 bg-slate-800/40'
                  : 'text-slate-400 hover:text-slate-200'
              }`}
            >
              <Layers className="w-3.5 h-3.5" />
              Layers ({canvasElements.length})
            </button>
          </div>

          <div className="flex-1 overflow-y-auto p-3 space-y-4">
            {activeLeftTab === 'elements' ? (
              <>
                {/* Dynamic Smart Tokens */}
                <div>
                  <label className="text-[11px] font-bold uppercase tracking-wider text-slate-400 mb-2 block">
                    Dynamic Tokens
                  </label>
                  <div className="grid grid-cols-2 gap-1.5">
                    <button
                      onClick={() =>
                        addElement('token', {
                          tokenName: '{{recipient_name}}',
                          content: activeSampleRecipient.name,
                          fontSize: 36,
                          fontWeight: 700,
                          fontFamily: 'Cinzel',
                          color: '#F59E0B',
                        })
                      }
                      className="p-2 text-left bg-slate-800/70 hover:bg-indigo-950/60 hover:border-indigo-500/50 rounded-lg border border-slate-700/80 text-xs transition group"
                    >
                      <div className="font-semibold text-slate-200 group-hover:text-indigo-300">
                        Recipient Name
                      </div>
                      <div className="text-[10px] text-slate-400 font-mono">
                        {`{{recipient_name}}`}
                      </div>
                    </button>
                    <button
                      onClick={() =>
                        addElement('token', {
                          tokenName: '{{course}}',
                          content: activeSampleRecipient.course,
                          fontSize: 24,
                          fontWeight: 600,
                          fontFamily: 'Sora',
                          color: '#06B6D4',
                        })
                      }
                      className="p-2 text-left bg-slate-800/70 hover:bg-indigo-950/60 hover:border-indigo-500/50 rounded-lg border border-slate-700/80 text-xs transition group"
                    >
                      <div className="font-semibold text-slate-200 group-hover:text-indigo-300">
                        Course / Program
                      </div>
                      <div className="text-[10px] text-slate-400 font-mono">{`{{course}}`}</div>
                    </button>
                    <button
                      onClick={() =>
                        addElement('token', {
                          tokenName: '{{date}}',
                          content: activeSampleRecipient.date,
                          fontSize: 12,
                          color: '#94A3B8',
                        })
                      }
                      className="p-2 text-left bg-slate-800/70 hover:bg-indigo-950/60 hover:border-indigo-500/50 rounded-lg border border-slate-700/80 text-xs transition group"
                    >
                      <div className="font-semibold text-slate-200 group-hover:text-indigo-300">
                        Issue Date
                      </div>
                      <div className="text-[10px] text-slate-400 font-mono">{`{{date}}`}</div>
                    </button>
                    <button
                      onClick={() =>
                        addElement('token', {
                          tokenName: '{{cert_no}}',
                          content: activeSampleRecipient.certNo,
                          fontSize: 11,
                          fontFamily: 'Fira Code',
                          color: '#64748B',
                        })
                      }
                      className="p-2 text-left bg-slate-800/70 hover:bg-indigo-950/60 hover:border-indigo-500/50 rounded-lg border border-slate-700/80 text-xs transition group"
                    >
                      <div className="font-semibold text-slate-200 group-hover:text-indigo-300">
                        Certificate ID
                      </div>
                      <div className="text-[10px] text-slate-400 font-mono">{`{{cert_no}}`}</div>
                    </button>
                  </div>
                </div>

                {/* Typography & Headers */}
                <div>
                  <label className="text-[11px] font-bold uppercase tracking-wider text-slate-400 mb-2 block">
                    Typography Elements
                  </label>
                  <div className="grid grid-cols-2 gap-1.5">
                    <button
                      onClick={() =>
                        addElement('text', {
                          content: 'Certificate of Achievement',
                          fontSize: 40,
                          fontWeight: 700,
                          fontFamily: 'Playfair Display',
                          color: '#FFFFFF',
                        })
                      }
                      className="p-2 text-left bg-slate-800/70 hover:bg-slate-700/80 rounded-lg border border-slate-700/80 text-xs transition flex items-center gap-2"
                    >
                      <Type className="w-4 h-4 text-cyan-400 shrink-0" />
                      <span>Main Title</span>
                    </button>
                    <button
                      onClick={() =>
                        addElement('text', {
                          content: 'ORGANIZATION NAME HERE',
                          fontSize: 14,
                          fontWeight: 700,
                          letterSpacing: 3,
                          color: '#38BDF8',
                        })
                      }
                      className="p-2 text-left bg-slate-800/70 hover:bg-slate-700/80 rounded-lg border border-slate-700/80 text-xs transition flex items-center gap-2"
                    >
                      <Type className="w-3.5 h-3.5 text-indigo-400 shrink-0" />
                      <span>Org Header</span>
                    </button>
                    <button
                      onClick={() =>
                        addElement('text', {
                          content: 'for successfully completing all curriculum requirements',
                          fontSize: 15,
                          color: '#CBD5E1',
                        })
                      }
                      className="col-span-2 p-2 text-left bg-slate-800/70 hover:bg-slate-700/80 rounded-lg border border-slate-700/80 text-xs transition flex items-center gap-2"
                    >
                      <Type className="w-3.5 h-3.5 text-slate-400 shrink-0" />
                      <span>Descriptive Paragraph</span>
                    </button>
                  </div>
                </div>

                {/* Authenticity & Seals */}
                <div>
                  <label className="text-[11px] font-bold uppercase tracking-wider text-slate-400 mb-2 block">
                    Security & Seals
                  </label>
                  <div className="grid grid-cols-2 gap-1.5">
                    <button
                      onClick={() => addElement('seal', { sealVariant: 'gold-foil' })}
                      className="p-2 text-left bg-slate-800/70 hover:bg-amber-950/40 hover:border-amber-500/50 rounded-lg border border-slate-700/80 text-xs transition flex items-center gap-2"
                    >
                      <Award className="w-4 h-4 text-amber-400 shrink-0" />
                      <span>Gold Foil Seal</span>
                    </button>
                    <button
                      onClick={() => addElement('seal', { sealVariant: 'cyan-crest' })}
                      className="p-2 text-left bg-slate-800/70 hover:bg-cyan-950/40 hover:border-cyan-500/50 rounded-lg border border-slate-700/80 text-xs transition flex items-center gap-2"
                    >
                      <ShieldCheck className="w-4 h-4 text-cyan-400 shrink-0" />
                      <span>Cyan Crest</span>
                    </button>
                    <button
                      onClick={() => addElement('signature')}
                      className="p-2 text-left bg-slate-800/70 hover:bg-slate-700/80 rounded-lg border border-slate-700/80 text-xs transition flex items-center gap-2"
                    >
                      <PenTool className="w-4 h-4 text-rose-400 shrink-0" />
                      <span>E-Signature</span>
                    </button>
                    <button
                      onClick={() => addElement('qr')}
                      className="p-2 text-left bg-slate-800/70 hover:bg-slate-700/80 rounded-lg border border-slate-700/80 text-xs transition flex items-center gap-2"
                    >
                      <QrCode className="w-4 h-4 text-green-400 shrink-0" />
                      <span>Verification QR</span>
                    </button>
                  </div>
                </div>

                {/* Decorative & Guilloche */}
                <div>
                  <label className="text-[11px] font-bold uppercase tracking-wider text-slate-400 mb-2 block">
                    Decorations & Borders
                  </label>
                  <div className="grid grid-cols-2 gap-1.5">
                    <button
                      onClick={() =>
                        addElement('guilloche', {
                          width: 850,
                          height: 550,
                          x: 75,
                          y: 75,
                          zIndex: 2,
                        })
                      }
                      className="p-2 text-left bg-slate-800/70 hover:bg-slate-700/80 rounded-lg border border-slate-700/80 text-xs transition flex items-center gap-2"
                    >
                      <Sparkles className="w-4 h-4 text-cyan-400 shrink-0" />
                      <span>Guilloche Wave</span>
                    </button>
                    <button
                      onClick={() =>
                        addElement('border', {
                          width: 950,
                          height: 657,
                          x: 25,
                          y: 25,
                          borderWidth: 3,
                          borderColor: '#F59E0B',
                          zIndex: 1,
                        })
                      }
                      className="p-2 text-left bg-slate-800/70 hover:bg-slate-700/80 rounded-lg border border-slate-700/80 text-xs transition flex items-center gap-2"
                    >
                      <LayoutGrid className="w-4 h-4 text-amber-400 shrink-0" />
                      <span>Gold Border</span>
                    </button>
                  </div>
                </div>
              </>
            ) : (
              /* Layers View */
              <div className="space-y-1">
                <div className="text-[11px] text-slate-400 pb-2 flex justify-between items-center">
                  <span>Stack Order (Top to Bottom)</span>
                  <span className="text-[10px] font-mono">z-index</span>
                </div>
                {canvasElements
                  .slice()
                  .sort((a, b) => b.zIndex - a.zIndex)
                  .map((el) => {
                    const isSelected = el.id === selectedElementId;
                    return (
                      <div
                        key={el.id}
                        onClick={() => setSelectedElementId(el.id)}
                        className={`p-2 rounded-lg border flex items-center justify-between text-xs cursor-pointer transition ${
                          isSelected
                            ? 'bg-indigo-600/20 border-cyan-400/80 text-white'
                            : 'bg-slate-800/50 border-slate-800 text-slate-300 hover:bg-slate-800'
                        }`}
                      >
                        <div className="flex items-center gap-2 truncate">
                          <span className="text-slate-500 font-mono text-[10px]">#{el.zIndex}</span>
                          <span className="capitalize font-medium">
                            {el.type === 'token' ? el.tokenName : el.type}
                          </span>
                        </div>
                        <div className="flex items-center gap-1">
                          <button
                            onClick={(e) => {
                              e.stopPropagation();
                              updateElement(el.id, { locked: !el.locked });
                            }}
                            className="p-1 hover:text-cyan-400 text-slate-400"
                          >
                            {el.locked ? <Lock className="w-3 h-3 text-amber-400" /> : <Unlock className="w-3 h-3" />}
                          </button>
                          <button
                            onClick={(e) => {
                              e.stopPropagation();
                              moveElementLayer(el.id, 'up');
                            }}
                            className="p-1 hover:text-cyan-400 text-slate-400"
                          >
                            <MoveUp className="w-3 h-3" />
                          </button>
                          <button
                            onClick={(e) => {
                              e.stopPropagation();
                              moveElementLayer(el.id, 'down');
                            }}
                            className="p-1 hover:text-cyan-400 text-slate-400"
                          >
                            <MoveDown className="w-3 h-3" />
                          </button>
                          <button
                            onClick={(e) => {
                              e.stopPropagation();
                              removeElement(el.id);
                            }}
                            className="p-1 hover:text-rose-400 text-slate-400"
                          >
                            <Trash2 className="w-3 h-3" />
                          </button>
                        </div>
                      </div>
                    );
                  })}
              </div>
            )}
          </div>
        </div>

        {/* Center Viewport: Certificate Canvas + Rulers */}
        <div className="flex-1 bg-[#070A14] flex flex-col items-center justify-center p-8 overflow-auto relative">
          {/* Horizontal Ruler simulation */}
          {showRulers && (
            <div className="absolute top-0 left-0 right-0 h-5 bg-slate-900 border-b border-slate-800 flex items-center justify-between px-6 text-[9px] font-mono text-slate-500 pointer-events-none select-none z-20">
              <span>0mm</span>
              <span>50mm</span>
              <span>100mm</span>
              <span>150mm</span>
              <span>200mm</span>
              <span>250mm</span>
              <span>297mm (A4)</span>
            </div>
          )}

          {/* Certificate Canvas Container */}
          <div className="relative shadow-2xl transition-transform ease-out">
            <CertificateRenderer
              elements={canvasElements}
              width={selectedTemplate.width}
              height={selectedTemplate.height}
              scale={zoomScale}
              bgTheme={selectedTemplate.bgTheme}
              selectedElementId={selectedElementId}
              onSelectElement={(id) => setSelectedElementId(id)}
              onUpdateElementPosition={(id, x, y) => updateElement(id, { x, y })}
              recipientData={activeSampleRecipient}
              showBleedMargins={showBleedMargins}
            />
          </div>
        </div>

        {/* Right Inspector: Properties Panel */}
        <div className="w-80 border-l border-slate-800 bg-slate-900/95 flex flex-col shrink-0 overflow-y-auto p-4 space-y-5">
          {selectedElement ? (
            <>
              {/* Header */}
              <div className="flex items-center justify-between pb-3 border-b border-slate-800">
                <div>
                  <h3 className="font-semibold text-sm text-slate-100 capitalize">
                    {selectedElement.type} Element
                  </h3>
                  <span className="text-[10px] font-mono text-slate-400">{selectedElement.id}</span>
                </div>
                <div className="flex items-center gap-1">
                  <button
                    onClick={() => duplicateElement(selectedElement.id)}
                    title="Duplicate"
                    className="p-1.5 rounded hover:bg-slate-800 text-slate-400 hover:text-slate-100"
                  >
                    <Copy className="w-4 h-4" />
                  </button>
                  <button
                    onClick={() => removeElement(selectedElement.id)}
                    title="Delete"
                    className="p-1.5 rounded hover:bg-rose-950/50 text-slate-400 hover:text-rose-400"
                  >
                    <Trash2 className="w-4 h-4" />
                  </button>
                </div>
              </div>

              {/* Text / Content controls */}
              {(selectedElement.type === 'text' || selectedElement.type === 'token') && (
                <div className="space-y-3">
                  <label className="text-xs font-semibold text-slate-300 block">Content</label>
                  {selectedElement.type === 'token' ? (
                    <div className="text-xs font-mono bg-slate-950 p-2 rounded border border-slate-800 text-cyan-400">
                      Token: {selectedElement.tokenName}
                    </div>
                  ) : (
                    <textarea
                      value={selectedElement.content || ''}
                      onChange={(e) => updateElement(selectedElement.id, { content: e.target.value })}
                      rows={2}
                      className="w-full bg-slate-950 border border-slate-700 rounded-lg p-2 text-xs text-slate-100 focus:outline-none focus:border-cyan-500"
                    />
                  )}

                  {/* Font Family */}
                  <div className="grid grid-cols-2 gap-2">
                    <div>
                      <label className="text-[11px] text-slate-400 block mb-1">Font Family</label>
                      <select
                        value={selectedElement.fontFamily || 'Inter'}
                        onChange={(e) =>
                          updateElement(selectedElement.id, {
                            fontFamily: e.target.value as any,
                          })
                        }
                        className="w-full bg-slate-950 border border-slate-700 rounded p-1.5 text-xs text-slate-200"
                      >
                        <option value="Sora">Sora (Modern)</option>
                        <option value="Inter">Inter (Clean)</option>
                        <option value="Playfair Display">Playfair (Serif)</option>
                        <option value="Cinzel">Cinzel (Diplomatic)</option>
                        <option value="Alex Brush">Alex Brush (Script)</option>
                        <option value="Fira Code">Fira Code (Tech)</option>
                      </select>
                    </div>

                    <div>
                      <label className="text-[11px] text-slate-400 block mb-1">Font Size (px)</label>
                      <input
                        type="number"
                        min={8}
                        max={120}
                        value={selectedElement.fontSize || 16}
                        onChange={(e) =>
                          updateElement(selectedElement.id, {
                            fontSize: Number(e.target.value),
                          })
                        }
                        className="w-full bg-slate-950 border border-slate-700 rounded p-1.5 text-xs text-slate-200 font-mono"
                      />
                    </div>
                  </div>

                  {/* Alignment & Weight */}
                  <div className="grid grid-cols-2 gap-2">
                    <div>
                      <label className="text-[11px] text-slate-400 block mb-1">Alignment</label>
                      <select
                        value={selectedElement.textAlign || 'center'}
                        onChange={(e) =>
                          updateElement(selectedElement.id, {
                            textAlign: e.target.value as any,
                          })
                        }
                        className="w-full bg-slate-950 border border-slate-700 rounded p-1.5 text-xs text-slate-200"
                      >
                        <option value="left">Left</option>
                        <option value="center">Center</option>
                        <option value="right">Right</option>
                      </select>
                    </div>
                    <div>
                      <label className="text-[11px] text-slate-400 block mb-1">Color</label>
                      <div className="flex items-center gap-2">
                        <input
                          type="color"
                          value={selectedElement.color || '#FFFFFF'}
                          onChange={(e) =>
                            updateElement(selectedElement.id, { color: e.target.value })
                          }
                          className="w-8 h-8 rounded border border-slate-700 cursor-pointer bg-transparent"
                        />
                        <span className="text-xs font-mono text-slate-400 uppercase">
                          {selectedElement.color || '#FFFFFF'}
                        </span>
                      </div>
                    </div>
                  </div>
                </div>
              )}

              {/* Signature Customization */}
              {selectedElement.type === 'signature' && (
                <div className="space-y-3">
                  <div>
                    <label className="text-[11px] text-slate-400 block mb-1">Signer Name</label>
                    <input
                      type="text"
                      value={selectedElement.signerName || ''}
                      onChange={(e) =>
                        updateElement(selectedElement.id, { signerName: e.target.value })
                      }
                      className="w-full bg-slate-950 border border-slate-700 rounded p-1.5 text-xs text-slate-200"
                    />
                  </div>
                  <div>
                    <label className="text-[11px] text-slate-400 block mb-1">Signer Official Title</label>
                    <input
                      type="text"
                      value={selectedElement.signerTitle || ''}
                      onChange={(e) =>
                        updateElement(selectedElement.id, { signerTitle: e.target.value })
                      }
                      className="w-full bg-slate-950 border border-slate-700 rounded p-1.5 text-xs text-slate-200"
                    />
                  </div>
                </div>
              )}

              {/* Seal Customization */}
              {selectedElement.type === 'seal' && (
                <div className="space-y-3">
                  <div>
                    <label className="text-[11px] text-slate-400 block mb-1">Seal Variant</label>
                    <select
                      value={selectedElement.sealVariant || 'gold-foil'}
                      onChange={(e) =>
                        updateElement(selectedElement.id, { sealVariant: e.target.value as any })
                      }
                      className="w-full bg-slate-950 border border-slate-700 rounded p-1.5 text-xs text-slate-200"
                    >
                      <option value="gold-foil">Gold Foil Embossed</option>
                      <option value="cyan-crest">Cyan AI Crest</option>
                      <option value="indigo-shield">Indigo Cyber Shield</option>
                      <option value="royal-star">Royal Bologna Star</option>
                    </select>
                  </div>
                  <div>
                    <label className="text-[11px] text-slate-400 block mb-1">Embossed Top Text</label>
                    <input
                      type="text"
                      value={selectedElement.sealText || ''}
                      onChange={(e) =>
                        updateElement(selectedElement.id, { sealText: e.target.value })
                      }
                      className="w-full bg-slate-950 border border-slate-700 rounded p-1.5 text-xs text-slate-200"
                    />
                  </div>
                  <div>
                    <label className="text-[11px] text-slate-400 block mb-1">Embossed Subtext</label>
                    <input
                      type="text"
                      value={selectedElement.sealSubtext || ''}
                      onChange={(e) =>
                        updateElement(selectedElement.id, { sealSubtext: e.target.value })
                      }
                      className="w-full bg-slate-950 border border-slate-700 rounded p-1.5 text-xs text-slate-200"
                    />
                  </div>
                </div>
              )}

              {/* Position & Geometry */}
              <div className="space-y-2 pt-3 border-t border-slate-800">
                <label className="text-xs font-semibold text-slate-300 block">Position & Dimensions</label>
                <div className="grid grid-cols-2 gap-2 text-xs">
                  <div>
                    <span className="text-[10px] text-slate-500 font-mono block">X (px)</span>
                    <input
                      type="number"
                      value={selectedElement.x}
                      onChange={(e) =>
                        updateElement(selectedElement.id, { x: Number(e.target.value) })
                      }
                      className="w-full bg-slate-950 border border-slate-700 rounded p-1 font-mono text-slate-200"
                    />
                  </div>
                  <div>
                    <span className="text-[10px] text-slate-500 font-mono block">Y (px)</span>
                    <input
                      type="number"
                      value={selectedElement.y}
                      onChange={(e) =>
                        updateElement(selectedElement.id, { y: Number(e.target.value) })
                      }
                      className="w-full bg-slate-950 border border-slate-700 rounded p-1 font-mono text-slate-200"
                    />
                  </div>
                  <div>
                    <span className="text-[10px] text-slate-500 font-mono block">Width (px)</span>
                    <input
                      type="number"
                      value={selectedElement.width}
                      onChange={(e) =>
                        updateElement(selectedElement.id, { width: Number(e.target.value) })
                      }
                      className="w-full bg-slate-950 border border-slate-700 rounded p-1 font-mono text-slate-200"
                    />
                  </div>
                  <div>
                    <span className="text-[10px] text-slate-500 font-mono block">Height (px)</span>
                    <input
                      type="number"
                      value={selectedElement.height}
                      onChange={(e) =>
                        updateElement(selectedElement.id, { height: Number(e.target.value) })
                      }
                      className="w-full bg-slate-950 border border-slate-700 rounded p-1 font-mono text-slate-200"
                    />
                  </div>
                </div>
              </div>
            </>
          ) : (
            /* Global Template Properties when no element selected */
            <div className="space-y-4">
              <div className="pb-3 border-b border-slate-800">
                <h3 className="font-semibold text-sm text-slate-100">Template Settings</h3>
                <p className="text-xs text-slate-400 mt-0.5">
                  Click any element on canvas to inspect and edit its properties.
                </p>
              </div>

              <div>
                <label className="text-[11px] font-bold uppercase tracking-wider text-slate-400 mb-2 block">
                  Background Theme
                </label>
                <div className="grid grid-cols-2 gap-2">
                  {[
                    { id: 'dark-sapphire', label: 'Dark Sapphire', color: '#1E1B4B' },
                    { id: 'cyber-slate', label: 'Cyber Slate', color: '#0F172A' },
                    { id: 'classic-ivory', label: 'Classic Ivory', color: '#FEF3C7' },
                    { id: 'royal-gold', label: 'Royal Gold', color: '#451A03' },
                    { id: 'emerald-crest', label: 'Emerald Crest', color: '#064E3B' },
                    { id: 'minimal-frost', label: 'Minimal Frost', color: '#F1F5F9' },
                  ].map((theme) => (
                    <button
                      key={theme.id}
                      onClick={() => {
                        selectedTemplate.bgTheme = theme.id as any;
                      }}
                      className={`p-2 rounded-lg border text-left text-xs transition flex items-center gap-2 ${
                        selectedTemplate.bgTheme === theme.id
                          ? 'border-cyan-400 bg-slate-800 text-white'
                          : 'border-slate-800 hover:border-slate-700 text-slate-400'
                      }`}
                    >
                      <div
                        className="w-4 h-4 rounded-full border border-slate-600 shrink-0"
                        style={{ backgroundColor: theme.color }}
                      />
                      <span className="truncate">{theme.label}</span>
                    </button>
                  ))}
                </div>
              </div>

              <div>
                <label className="text-[11px] font-bold uppercase tracking-wider text-slate-400 mb-2 block">
                  Document Standard
                </label>
                <div className="bg-slate-950 p-3 rounded-lg border border-slate-800 space-y-2 text-xs">
                  <div className="flex justify-between">
                    <span className="text-slate-400">Orientation:</span>
                    <span className="font-semibold text-slate-200 capitalize">
                      {selectedTemplate.orientation}
                    </span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-slate-400">Paper Standard:</span>
                    <span className="font-semibold text-slate-200">{selectedTemplate.paper} (ISO 216)</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-slate-400">Print DPI:</span>
                    <span className="font-semibold text-cyan-400">300 DPI Ultra-Fine</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-slate-400">Bleed Allowance:</span>
                    <span className="font-semibold text-rose-400">3.0 mm (standard)</span>
                  </div>
                </div>
              </div>
            </div>
          )}
        </div>
      </div>

      {/* Live Issuance Modal */}
      {issueModalOpen && (
        <div className="fixed inset-0 bg-slate-950/80 backdrop-blur-md flex items-center justify-center p-4 z-50 animate-in fade-in">
          <div className="w-full max-w-lg bg-slate-900 border border-slate-800 rounded-2xl p-6 shadow-2xl relative">
            <div className="flex items-center justify-between pb-4 border-b border-slate-800 mb-5">
              <div className="flex items-center gap-3">
                <div className="p-2 rounded-xl bg-indigo-500/10 border border-indigo-500/20 text-indigo-400">
                  <Sparkles className="w-5 h-5 text-yellow-300" />
                </div>
                <div>
                  <h3 className="font-sora font-bold text-lg text-white">Issue Official Credential</h3>
                  <p className="text-xs text-slate-400">
                    Generates verifiable SHA-256 seal & cryptographic QR link
                  </p>
                </div>
              </div>
              <button
                onClick={() => setIssueModalOpen(false)}
                className="text-slate-400 hover:text-white text-lg font-bold"
              >
                ✕
              </button>
            </div>

            <form onSubmit={handleIssueSubmit} className="space-y-4">
              <div>
                <label className="text-xs font-semibold text-slate-300 block mb-1">
                  Recipient Full Name
                </label>
                <input
                  type="text"
                  required
                  value={issueForm.recipientName}
                  onChange={(e) => setIssueForm({ ...issueForm, recipientName: e.target.value })}
                  className="w-full bg-slate-950 border border-slate-700 rounded-lg p-2.5 text-sm text-slate-100 focus:outline-none focus:border-cyan-500"
                />
              </div>

              <div>
                <label className="text-xs font-semibold text-slate-300 block mb-1">
                  Recipient Email (For Notification & Digital Wallet)
                </label>
                <input
                  type="email"
                  required
                  value={issueForm.recipientEmail}
                  onChange={(e) => setIssueForm({ ...issueForm, recipientEmail: e.target.value })}
                  className="w-full bg-slate-950 border border-slate-700 rounded-lg p-2.5 text-sm text-slate-100 focus:outline-none focus:border-cyan-500"
                />
              </div>

              <div>
                <label className="text-xs font-semibold text-slate-300 block mb-1">
                  Course or Specialization Title
                </label>
                <input
                  type="text"
                  required
                  value={issueForm.course}
                  onChange={(e) => setIssueForm({ ...issueForm, course: e.target.value })}
                  className="w-full bg-slate-950 border border-slate-700 rounded-lg p-2.5 text-sm text-slate-100 focus:outline-none focus:border-cyan-500"
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="text-xs font-semibold text-slate-300 block mb-1">
                    Grade / Honors Distinction
                  </label>
                  <input
                    type="text"
                    value={issueForm.grade}
                    onChange={(e) => setIssueForm({ ...issueForm, grade: e.target.value })}
                    className="w-full bg-slate-950 border border-slate-700 rounded-lg p-2.5 text-sm text-slate-100 focus:outline-none focus:border-cyan-500"
                  />
                </div>
                <div>
                  <label className="text-xs font-semibold text-slate-300 block mb-1">
                    Issuer Organization
                  </label>
                  <input
                    type="text"
                    disabled
                    value={currentOrg.name}
                    className="w-full bg-slate-950/60 border border-slate-800 rounded-lg p-2.5 text-sm text-slate-400 cursor-not-allowed"
                  />
                </div>
              </div>

              <div>
                <label className="text-xs font-semibold text-slate-300 block mb-1">
                  Demonstrated Competencies (comma separated)
                </label>
                <input
                  type="text"
                  value={issueForm.skills}
                  onChange={(e) => setIssueForm({ ...issueForm, skills: e.target.value })}
                  className="w-full bg-slate-950 border border-slate-700 rounded-lg p-2.5 text-sm text-slate-100 focus:outline-none focus:border-cyan-500"
                />
              </div>

              <div className="p-3 rounded-lg bg-indigo-500/10 border border-indigo-500/20 text-xs text-indigo-300 flex items-center gap-2 mt-2">
                <CheckCircle2 className="w-4 h-4 text-cyan-400 shrink-0" />
                <span>
                  The credential will be anchored with an Ed25519 signature and registered on public lookup.
                </span>
              </div>

              <div className="flex items-center justify-end gap-3 pt-3 border-t border-slate-800">
                <button
                  type="button"
                  onClick={() => setIssueModalOpen(false)}
                  className="px-4 py-2 rounded-lg bg-slate-800 hover:bg-slate-700 text-xs font-semibold text-slate-300"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-5 py-2 rounded-lg bg-gradient-to-r from-indigo-600 to-cyan-600 hover:from-indigo-500 hover:to-cyan-500 text-white text-xs font-bold shadow-lg shadow-indigo-600/30"
                >
                  Generate & Verify Now
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
