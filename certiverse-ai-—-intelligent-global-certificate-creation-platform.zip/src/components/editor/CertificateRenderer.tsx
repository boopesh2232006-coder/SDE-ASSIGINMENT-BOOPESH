import React, { useEffect, useState, useRef } from 'react';
import QRCode from 'qrcode';
import { CanvasElement } from '../../types';

interface CertificateRendererProps {
  elements: CanvasElement[];
  width?: number;
  height?: number;
  scale?: number;
  bgTheme?: string;
  selectedElementId?: string | null;
  onSelectElement?: (id: string | null) => void;
  onUpdateElementPosition?: (id: string, x: number, y: number) => void;
  recipientData?: {
    name: string;
    course: string;
    date: string;
    certNo: string;
    grade?: string;
    skills?: string[];
  };
  token?: string;
  isPrintOrExport?: boolean;
  showBleedMargins?: boolean;
}

export const CertificateRenderer: React.FC<CertificateRendererProps> = ({
  elements,
  width = 1000,
  height = 707,
  scale = 1,
  bgTheme = 'dark-sapphire',
  selectedElementId = null,
  onSelectElement,
  onUpdateElementPosition,
  recipientData = {
    name: 'Alexander Vance, M.Sc.',
    course: 'Large Language Models & Agentic Architecture',
    date: 'October 9, 2026',
    certNo: 'CV-AI-2026-884920',
  },
  token = 'tok_live_7e8b91fa023a4b9c8d11',
  isPrintOrExport = false,
  showBleedMargins = false,
}) => {
  const [qrDataUrl, setQrDataUrl] = useState<string>('');
  const containerRef = useRef<HTMLDivElement>(null);
  const draggingRef = useRef<{ id: string; startX: number; startY: number; elX: number; elY: number } | null>(null);

  useEffect(() => {
    // Generate real QR Code data URL
    const verifyUrl = `https://certiverse.ai/v/${token}`;
    QRCode.toDataURL(verifyUrl, {
      width: 250,
      margin: 1,
      color: {
        dark: bgTheme === 'classic-ivory' || bgTheme === 'minimal-frost' ? '#0F172A' : '#38BDF8',
        light: bgTheme === 'classic-ivory' || bgTheme === 'minimal-frost' ? '#FFFFFF' : '#0B0F1E',
      },
    })
      .then((url) => setQrDataUrl(url))
      .catch(() => {});
  }, [token, bgTheme]);

  // Background CSS styles based on theme
  const getBackgroundStyles = () => {
    switch (bgTheme) {
      case 'dark-sapphire':
        return 'bg-gradient-to-br from-[#0B0F1E] via-[#111827] to-[#1E1B4B] text-slate-100';
      case 'cyber-slate':
        return 'bg-gradient-to-br from-[#090D16] via-[#0F172A] to-[#064E3B] text-slate-100';
      case 'classic-ivory':
        return 'bg-gradient-to-br from-[#FFFBEB] via-[#FEF3C7] to-[#FFFDF5] text-slate-900 border-[#D97706]/30';
      case 'royal-gold':
        return 'bg-gradient-to-br from-[#1C1917] via-[#292524] to-[#451A03] text-amber-100';
      case 'emerald-crest':
        return 'bg-gradient-to-br from-[#022C22] via-[#064E3B] to-[#042F2E] text-slate-100';
      case 'minimal-frost':
        return 'bg-gradient-to-br from-[#FFFFFF] via-[#F8FAFC] to-[#F1F5F9] text-slate-900';
      default:
        return 'bg-[#0B0F1E] text-slate-100';
    }
  };

  // Helper to replace dynamic tokens
  const resolveTokenText = (tokenName?: string, defaultContent?: string): string => {
    if (!tokenName) return defaultContent || '';
    switch (tokenName.trim()) {
      case '{{recipient_name}}':
        return recipientData.name;
      case '{{course}}':
        return recipientData.course;
      case '{{date}}':
        return recipientData.date;
      case '{{cert_no}}':
        return `ID: ${recipientData.certNo}`;
      case '{{grade}}':
        return recipientData.grade || 'Graduated with Distinction';
      default:
        return defaultContent || tokenName;
    }
  };

  // Drag interaction handlers
  const handleMouseDown = (e: React.MouseEvent, el: CanvasElement) => {
    if (isPrintOrExport || el.locked) return;
    e.stopPropagation();
    if (onSelectElement) onSelectElement(el.id);

    draggingRef.current = {
      id: el.id,
      startX: e.clientX,
      startY: e.clientY,
      elX: el.x,
      elY: el.y,
    };

    const handleMouseMove = (moveEvent: MouseEvent) => {
      if (!draggingRef.current) return;
      const dx = (moveEvent.clientX - draggingRef.current.startX) / scale;
      const dy = (moveEvent.clientY - draggingRef.current.startY) / scale;
      const newX = Math.round(draggingRef.current.elX + dx);
      const newY = Math.round(draggingRef.current.elY + dy);
      if (onUpdateElementPosition) {
        onUpdateElementPosition(draggingRef.current.id, newX, newY);
      }
    };

    const handleMouseUp = () => {
      draggingRef.current = null;
      window.removeEventListener('mousemove', handleMouseMove);
      window.removeEventListener('mouseup', handleMouseUp);
    };

    window.addEventListener('mousemove', handleMouseMove);
    window.addEventListener('mouseup', handleMouseUp);
  };

  return (
    <div
      ref={containerRef}
      id="certificate-canvas-root"
      style={{
        width: `${width}px`,
        height: `${height}px`,
        transform: scale !== 1 ? `scale(${scale})` : undefined,
        transformOrigin: 'top left',
      }}
      onClick={() => onSelectElement && onSelectElement(null)}
      className={`relative select-none overflow-hidden shadow-2xl transition-all ${getBackgroundStyles()}`}
    >
      {/* 3mm Safe Margins & Bleed Guideline indicator */}
      {showBleedMargins && !isPrintOrExport && (
        <div
          className="absolute inset-[15px] border border-dashed border-red-500/40 pointer-events-none z-50 flex items-start justify-end p-2"
        >
          <span className="text-[10px] font-mono text-red-400 bg-red-950/80 px-1.5 py-0.5 rounded border border-red-500/30">
            3mm Bleed Margin Cut Line
          </span>
        </div>
      )}

      {/* Render elements in layer order */}
      {elements
        .slice()
        .sort((a, b) => a.zIndex - b.zIndex)
        .map((el) => {
          const isSelected = selectedElementId === el.id && !isPrintOrExport;

          let elementContent = null;

          if (el.type === 'border') {
            elementContent = (
              <div
                style={{
                  width: '100%',
                  height: '100%',
                  borderWidth: `${el.borderWidth || 2}px`,
                  borderColor: el.borderColor || '#F59E0B',
                  borderStyle: el.borderStyle || 'solid',
                  borderRadius: `${el.borderRadius || 0}px`,
                }}
                className="w-full h-full pointer-events-none"
              />
            );
          } else if (el.type === 'guilloche') {
            elementContent = (
              <svg
                width="100%"
                height="100%"
                viewBox="0 0 800 500"
                fill="none"
                xmlns="http://www.w3.org/2000/svg"
                className="w-full h-full pointer-events-none opacity-25"
              >
                <g stroke="#06B6D4" strokeWidth="0.8">
                  {Array.from({ length: 14 }).map((_, i) => (
                    <ellipse
                      key={i}
                      cx="400"
                      cy="250"
                      rx={150 + i * 22}
                      ry={90 + i * 14}
                      transform={`rotate(${i * 6} 400 250)`}
                      stroke={i % 2 === 0 ? '#06B6D4' : '#F59E0B'}
                      strokeOpacity="0.4"
                    />
                  ))}
                </g>
              </svg>
            );
          } else if (el.type === 'token') {
            const resolvedText = resolveTokenText(el.tokenName, el.content);
            elementContent = (
              <div
                style={{
                  fontFamily: el.fontFamily ? `'${el.fontFamily}', sans-serif` : undefined,
                  fontSize: `${el.fontSize || 24}px`,
                  fontWeight: el.fontWeight || 600,
                  color: el.color || '#F8FAFC',
                  textAlign: el.textAlign || 'center',
                  letterSpacing: el.letterSpacing ? `${el.letterSpacing}px` : undefined,
                }}
                className="w-full h-full flex items-center justify-center break-words leading-tight"
              >
                {resolvedText}
              </div>
            );
          } else if (el.type === 'text') {
            elementContent = (
              <div
                style={{
                  fontFamily: el.fontFamily ? `'${el.fontFamily}', sans-serif` : undefined,
                  fontSize: `${el.fontSize || 16}px`,
                  fontWeight: el.fontWeight || 400,
                  fontStyle: el.fontStyle || 'normal',
                  color: el.color || '#94A3B8',
                  textAlign: el.textAlign || 'center',
                  letterSpacing: el.letterSpacing ? `${el.letterSpacing}px` : undefined,
                }}
                className="w-full h-full flex items-center justify-center leading-snug"
              >
                {el.content}
              </div>
            );
          } else if (el.type === 'seal') {
            const isGold = el.sealVariant !== 'cyan-crest' && el.sealVariant !== 'indigo-shield';
            elementContent = (
              <div className="w-full h-full flex flex-col items-center justify-center relative">
                {/* Outer Seal Starburst / Notched Circle */}
                <div
                  className={`w-full h-full rounded-full flex flex-col items-center justify-center text-center p-2 shadow-xl ${
                    isGold ? 'gold-foil-seal text-amber-950' : 'bg-gradient-to-tr from-cyan-600 to-indigo-600 text-white'
                  }`}
                >
                  <div className="w-[88%] h-[88%] rounded-full border-2 border-dashed border-amber-950/40 flex flex-col items-center justify-center p-1">
                    {/* Seal Star Icon */}
                    <svg className="w-5 h-5 mb-0.5 fill-current opacity-90" viewBox="0 0 24 24">
                      <polygon points="12 2 15.09 8.26 22 9.27 17 14.14 18.18 21.02 12 17.77 5.82 21.02 7 14.14 2 9.27 8.91 8.26 12 2" />
                    </svg>
                    <span className="text-[9px] font-bold tracking-widest uppercase leading-none text-center">
                      {el.sealText || 'VERIFIED'}
                    </span>
                    <span className="text-[7px] font-semibold tracking-wider opacity-75 mt-0.5">
                      {el.sealSubtext || 'CREDENTIAL'}
                    </span>
                  </div>
                </div>
              </div>
            );
          } else if (el.type === 'signature') {
            elementContent = (
              <div className="w-full h-full flex flex-col items-center justify-end pb-1 text-center">
                {/* Elegant Cursive SVG or Font representation */}
                <div className="font-signature text-3xl leading-none text-cyan-300 drop-shadow mb-1 select-none">
                  {el.signerName || 'Evelyn Zhang'}
                </div>
                <div className="w-4/5 h-[1.5px] bg-slate-500/50 mb-1" />
                <div className="text-[12px] font-semibold text-slate-200 tracking-wide">
                  {el.signerName || 'Dr. Evelyn Zhang'}
                </div>
                <div className="text-[10px] text-slate-400 font-medium">
                  {el.signerTitle || 'Director of AI Research'}
                </div>
              </div>
            );
          } else if (el.type === 'qr') {
            elementContent = (
              <div className="w-full h-full p-1 bg-white/10 backdrop-blur-sm rounded-lg border border-white/20 flex flex-col items-center justify-center">
                {qrDataUrl ? (
                  <img src={qrDataUrl} alt="Verify QR Code" className="w-[85%] h-[85%] object-contain rounded" />
                ) : (
                  <div className="w-full h-full bg-slate-800 rounded animate-pulse" />
                )}
                <span className="text-[8px] font-mono font-medium text-slate-300 mt-0.5">SCAN TO VERIFY</span>
              </div>
            );
          }

          return (
            <div
              key={el.id}
              onClick={(e) => {
                if (!isPrintOrExport) {
                  e.stopPropagation();
                  if (onSelectElement) onSelectElement(el.id);
                }
              }}
              onMouseDown={(e) => handleMouseDown(e, el)}
              style={{
                position: 'absolute',
                left: `${el.x}px`,
                top: `${el.y}px`,
                width: `${el.width}px`,
                height: `${el.height}px`,
                transform: el.rotation ? `rotate(${el.rotation}deg)` : undefined,
                opacity: el.opacity ?? 1,
                zIndex: el.zIndex,
                cursor: isPrintOrExport || el.locked ? 'default' : 'move',
              }}
              className={`transition-[outline] ${
                isSelected
                  ? 'outline-2 outline-cyan-400 outline-offset-2 ring-2 ring-indigo-500/40 bg-indigo-500/5'
                  : ''
              }`}
            >
              {elementContent}
              {isSelected && (
                <div className="absolute -top-2.5 -right-2.5 w-5 h-5 bg-cyan-400 text-slate-950 rounded-full flex items-center justify-center text-[10px] font-bold shadow">
                  ✓
                </div>
              )}
            </div>
          );
        })}
    </div>
  );
};
