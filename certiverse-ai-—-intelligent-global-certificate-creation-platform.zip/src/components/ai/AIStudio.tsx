import React, { useState } from 'react';
import { useCert } from '../../context/CertContext';
import { CertificateTemplate, CanvasElement } from '../../types';
import {
  Sparkles,
  Wand2,
  Palette,
  ShieldCheck,
  Languages,
  Eye,
  CheckCircle2,
  AlertTriangle,
  RefreshCw,
  Copy,
  Check,
  ArrowRight,
  FileCode,
} from 'lucide-react';
import confetti from 'canvas-confetti';

const MULTILINGUAL_TRANSLATIONS: Record<
  string,
  {
    title: string;
    orgHeader: string;
    statement: string;
    dateLabel: string;
    certIdLabel: string;
    isRtl?: boolean;
  }
> = {
  English: {
    title: 'Certificate of Excellence',
    orgHeader: 'GLOBAL ACADEMY OF ADVANCED STUDIES',
    statement: 'for successfully demonstrating mastery and completing the rigorous curriculum in',
    dateLabel: 'Issued on',
    certIdLabel: 'Credential ID',
    isRtl: false,
  },
  French: {
    title: "Certificat d'Excellence",
    orgHeader: 'ACADÉMIE MONDIALE DES ÉTUDES SUPÉRIEURES',
    statement: 'pour avoir démontré avec succès sa maîtrise du programme d’études en',
    dateLabel: 'Délivré le',
    certIdLabel: 'Identifiant du Titre',
    isRtl: false,
  },
  German: {
    title: 'Exzellenzzertifikat',
    orgHeader: 'GLOBALE AKADEMIE FÜR WEITERFÜHRENDE STUDIEN',
    statement: 'für den erfolgreichen Nachweis herausragender Fachkompetenz im Fachgebiet',
    dateLabel: 'Ausstellungsdatum',
    certIdLabel: 'Zertifikatsnummer',
    isRtl: false,
  },
  Spanish: {
    title: 'Certificado de Excelencia',
    orgHeader: 'ACADEMIA GLOBAL DE ESTUDIOS AVANZADOS',
    statement: 'por haber demostrado con éxito el dominio y completado el plan de estudios en',
    dateLabel: 'Fecha de emisión',
    certIdLabel: 'ID de Credencial',
    isRtl: false,
  },
  Arabic: {
    title: 'شهادة التميز والجدارة',
    orgHeader: 'الأكاديمية العالمية للدراسات المتقدمة',
    statement: 'تقديراً لإتمام متطلبات المنهج الأكاديمي بنجاح واقتدار في تخصص',
    dateLabel: 'تاريخ الإصدار',
    certIdLabel: 'معرف الشهادة',
    isRtl: true,
  },
  Hindi: {
    title: 'उत्कृष्टता प्रमाण पत्र',
    orgHeader: 'वैश्विक उच्च अध्ययन संस्थान',
    statement: 'पाठ्यक्रम के सभी मानकों को सफलतापूर्वक उत्तीर्ण करने के उपलक्ष्य में',
    dateLabel: 'जारी करने की तिथि',
    certIdLabel: 'प्रमाणपत्र संख्या',
    isRtl: false,
  },
  Japanese: {
    title: '卓越性修了証書',
    orgHeader: 'グローバル高等学術院',
    statement: '所定のカリキュラムを修了し優秀な学業成果を収めたことを証する',
    dateLabel: '発行日',
    certIdLabel: '認証番号',
    isRtl: false,
  },
  Chinese: {
    title: '卓越成就结业证书',
    orgHeader: '全球高等学术研究中心',
    statement: '特此证明该学员已圆满完成全部专业课程并成绩优异',
    dateLabel: '签发日期',
    certIdLabel: '证书编号',
    isRtl: false,
  },
  Portuguese: {
    title: 'Certificado de Excelência',
    orgHeader: 'ACADEMIA GLOBAL DE ESTUDOS AVANÇADOS',
    statement: 'por ter completado com distinção e demonstrado domínio no programa de',
    dateLabel: 'Data de Emissão',
    certIdLabel: 'Código do Certificado',
    isRtl: false,
  },
  Italian: {
    title: 'Certificato di Eccellenza',
    orgHeader: 'ACCADEMIA GLOBALE DI STUDI AVANZATI',
    statement: 'per aver completato con merito il percorso di specializzazione in',
    dateLabel: 'Rilasciato il',
    certIdLabel: 'ID Certificato',
    isRtl: false,
  },
};

export const AIStudio: React.FC = () => {
  const { selectedTemplate, setSelectedTemplate, setCanvasElements, setActiveTab } = useCert();

  const [activeTabSub, setActiveTabSub] = useState<'prompt' | 'brand' | 'validator' | 'languages'>(
    'prompt'
  );

  // Prompt Generator State
  const [promptText, setPromptText] = useState(
    'Create an elite Cyber Warfare & Threat Intelligence credential with dark sapphire background, neon emerald security borders, guilloche pattern, and dual cryptographic authority signatures.'
  );
  const [isGenerating, setIsGenerating] = useState(false);
  const [generatedJson, setGeneratedJson] = useState<string | null>(null);

  // Brand Extractor State
  const [brandOrgName, setBrandOrgName] = useState('Stanford Deep Learning Lab');
  const [brandPrimaryColor, setBrandPrimaryColor] = useState('#4F46E5');
  const [brandSecondaryColor, setBrandSecondaryColor] = useState('#06B6D4');
  const [extractedBrandKit, setExtractedBrandKit] = useState<any>(null);

  // Validator State
  const [validatorReport, setValidatorReport] = useState<any>(null);
  const [isValidating, setIsValidating] = useState(false);

  // Multilingual State
  const [selectedLanguage, setSelectedLanguage] = useState<string>('French');

  // Alt-Text state
  const [altTextResult, setAltTextResult] = useState<string>('');

  // Handle Prompt -> Design JSON Generation
  const handleGenerateFromPrompt = () => {
    setIsGenerating(true);
    setTimeout(() => {
      const isCyber = promptText.toLowerCase().includes('cyber');
      const isGold = promptText.toLowerCase().includes('gold') || promptText.toLowerCase().includes('academic');

      const bgTheme = isCyber ? 'cyber-slate' : isGold ? 'royal-gold' : 'dark-sapphire';
      const primaryColor = isCyber ? '#10B981' : isGold ? '#F59E0B' : '#06B6D4';

      const customElements: CanvasElement[] = [
        {
          id: 'ai-border',
          type: 'border',
          x: 20,
          y: 20,
          width: 960,
          height: 667,
          borderWidth: 3,
          borderColor: primaryColor,
          borderStyle: 'solid',
          zIndex: 1,
        },
        {
          id: 'ai-guilloche',
          type: 'guilloche',
          x: 35,
          y: 35,
          width: 930,
          height: 637,
          opacity: 0.18,
          zIndex: 2,
        },
        {
          id: 'ai-org',
          type: 'text',
          x: 100,
          y: 65,
          width: 800,
          height: 35,
          content: 'INTERNATIONAL COUNCIL OF ACCREDITED PRACTITIONERS',
          fontFamily: 'Sora',
          fontSize: 15,
          fontWeight: 700,
          letterSpacing: 4,
          color: primaryColor,
          textAlign: 'center',
          zIndex: 10,
        },
        {
          id: 'ai-title',
          type: 'text',
          x: 100,
          y: 115,
          width: 800,
          height: 65,
          content: isCyber ? 'Certified Threat Hunter & SOC Specialist' : 'Distinguished Mastery Award',
          fontFamily: 'Playfair Display',
          fontSize: 38,
          fontWeight: 700,
          color: '#F8FAFC',
          textAlign: 'center',
          zIndex: 10,
        },
        {
          id: 'ai-recipient',
          type: 'token',
          tokenName: '{{recipient_name}}',
          x: 100,
          y: 235,
          width: 800,
          height: 55,
          content: 'Alexander Vance, M.Sc.',
          fontFamily: 'Cinzel',
          fontSize: 38,
          fontWeight: 700,
          color: primaryColor,
          textAlign: 'center',
          zIndex: 11,
        },
        {
          id: 'ai-course',
          type: 'token',
          tokenName: '{{course}}',
          x: 100,
          y: 355,
          width: 800,
          height: 45,
          content: isCyber ? 'Zero-Trust Architecture & Threat Hunting' : 'Autonomous AI Systems & Robotics',
          fontFamily: 'Sora',
          fontSize: 24,
          fontWeight: 600,
          color: '#E2E8F0',
          textAlign: 'center',
          zIndex: 11,
        },
        {
          id: 'ai-seal',
          type: 'seal',
          x: 440,
          y: 470,
          width: 120,
          height: 120,
          sealVariant: isGold ? 'gold-foil' : 'cyan-crest',
          sealText: 'AI VERIFIED AUTHENTIC',
          sealSubtext: 'ED25519 SEAL',
          zIndex: 12,
        },
        {
          id: 'ai-sig1',
          type: 'signature',
          x: 120,
          y: 490,
          width: 220,
          height: 90,
          signerName: 'Dr. Evelyn Zhang',
          signerTitle: 'Chief Scientist',
          signatureStyle: 'classic',
          zIndex: 10,
        },
        {
          id: 'ai-sig2',
          type: 'signature',
          x: 660,
          y: 490,
          width: 220,
          height: 90,
          signerName: 'Marcus Sterling',
          signerTitle: 'Lead Inspector',
          signatureStyle: 'formal',
          zIndex: 10,
        },
        {
          id: 'ai-qr',
          type: 'qr',
          tokenName: '{{qr}}',
          x: 60,
          y: 580,
          width: 75,
          height: 75,
          zIndex: 15,
        },
      ];

      const newTemplate: CertificateTemplate = {
        ...selectedTemplate,
        id: `tmpl-ai-gen-${Date.now().toString(36)}`,
        title: `AI Generated: ${promptText.substring(0, 32)}...`,
        bgTheme: bgTheme as any,
        elements: customElements,
      };

      setGeneratedJson(JSON.stringify(newTemplate, null, 2));
      setSelectedTemplate(newTemplate);
      setCanvasElements(customElements);
      setIsGenerating(false);

      confetti({
        particleCount: 70,
        spread: 60,
        origin: { y: 0.6 },
      });
    }, 1200);
  };

  // Run Content Validator & Fraud Shield
  const handleRunValidator = () => {
    setIsValidating(true);
    setTimeout(() => {
      setValidatorReport({
        score: 96,
        status: 'PASSED',
        tamperShieldTier: 'BANK-GRADE (TIER 4)',
        findings: [
          {
            type: 'success',
            title: 'Dynamic Variables Enclosed',
            desc: 'All tokens ({{recipient_name}}, {{course}}, {{qr}}) are correctly parameterized.',
          },
          {
            type: 'success',
            title: 'Legal Accreditation Disclaimer',
            desc: 'Found valid certification authority statement and ISO standards adherence.',
          },
          {
            type: 'info',
            title: 'Contact Hours Clarity',
            desc: 'Consider specifying precise CEU / contact hours for full IACET standard reciprocity.',
          },
          {
            type: 'success',
            title: 'Tamper-Proof Microprint & Watermark',
            desc: 'Guilloche security wave pattern prevents screenshot replication and forge attempts.',
          },
        ],
      });
      setIsValidating(false);
    }, 900);
  };

  // Run Multilingual Translation & Auto-Layout
  const handleApplyLanguage = (lang: string) => {
    setSelectedLanguage(lang);
    const trans = MULTILINGUAL_TRANSLATIONS[lang] || MULTILINGUAL_TRANSLATIONS['English'];

    const updatedElements = selectedTemplate.elements.map((el) => {
      if (el.id.includes('title') || el.type === 'text' && el.fontSize && el.fontSize > 30) {
        return {
          ...el,
          content: trans.title,
          textAlign: trans.isRtl ? 'center' : el.textAlign,
        };
      }
      if (el.id.includes('org')) {
        return {
          ...el,
          content: trans.orgHeader,
        };
      }
      if (el.id.includes('desc')) {
        return {
          ...el,
          content: trans.statement,
        };
      }
      return el;
    });

    setCanvasElements(updatedElements);
    confetti({
      particleCount: 50,
      spread: 50,
      origin: { y: 0.6 },
    });
  };

  // Generate Accessibility Alt-Text
  const handleGenerateAltText = () => {
    const text = `Official digital certificate issued by ${selectedTemplate.title} to Alexander Vance for mastery of Large Language Models and Agentic Architecture. Features dual cryptographic verification QR code, official gold seal, and registered on public ledger.`;
    setAltTextResult(text);
  };

  return (
    <div className="min-h-[calc(100vh-64px)] bg-[#0B0F1E] text-slate-100 p-6 md:p-8 space-y-8">
      {/* Header Banner */}
      <div className="flex flex-col md:flex-row md:items-end justify-between gap-4 border-b border-slate-800 pb-6">
        <div>
          <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-indigo-500/10 border border-indigo-500/20 text-indigo-400 text-xs font-semibold mb-3">
            <Sparkles className="w-3.5 h-3.5 text-yellow-300" />
            Gemini-Powered Intelligent Studio
          </div>
          <h1 className="text-3xl md:text-4xl font-sora font-extrabold tracking-tight text-white">
            AI <span className="text-cyan-400">Design Studio</span>
          </h1>
          <p className="text-slate-400 text-sm mt-1 max-w-2xl">
            Generate custom certificate designs from natural language, extract brand kits,
            validate legal accreditation with Fraud Shield, and translate across 20+ languages with
            RTL support.
          </p>
        </div>
      </div>

      {/* Tabs */}
      <div className="flex border-b border-slate-800 text-xs font-medium space-x-2">
        {[
          { id: 'prompt', label: 'Prompt -> Blueprint', icon: Wand2 },
          { id: 'brand', label: 'Brand-Kit Extractor', icon: Palette },
          { id: 'validator', label: 'Fraud Shield & Validator', icon: ShieldCheck },
          { id: 'languages', label: 'Multilingual & RTL (20+)', icon: Languages },
        ].map((tab) => {
          const Icon = tab.icon;
          return (
            <button
              key={tab.id}
              onClick={() => setActiveTabSub(tab.id as any)}
              className={`py-3 px-4 rounded-t-xl flex items-center gap-2 transition ${
                activeTabSub === tab.id
                  ? 'border-b-2 border-cyan-400 text-cyan-400 bg-slate-900 font-bold'
                  : 'text-slate-400 hover:text-slate-200 hover:bg-slate-900/40'
              }`}
            >
              <Icon className="w-4 h-4" />
              <span>{tab.label}</span>
            </button>
          );
        })}
      </div>

      {/* Tab 1: Prompt -> Blueprint Generator */}
      {activeTabSub === 'prompt' && (
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
          <div className="bg-slate-900/90 rounded-2xl border border-slate-800 p-6 space-y-5">
            <div>
              <h3 className="font-sora font-bold text-base text-white">
                Describe Your Ideal Credential
              </h3>
              <p className="text-xs text-slate-400 mt-0.5">
                Specify mood, colors, industry, borders, typography, and authority signatures.
              </p>
            </div>

            <textarea
              value={promptText}
              onChange={(e) => setPromptText(e.target.value)}
              rows={5}
              className="w-full bg-slate-950 border border-slate-700/80 rounded-xl p-3.5 text-xs text-slate-100 placeholder:text-slate-500 focus:outline-none focus:border-cyan-400 leading-relaxed"
            />

            {/* Quick Inspiration Prompts */}
            <div className="space-y-1.5">
              <span className="text-[11px] font-bold uppercase tracking-wider text-slate-400 block">
                Quick Inspiration Prompts:
              </span>
              <div className="flex flex-wrap gap-1.5">
                {[
                  'Quantum Computing Research Fellow (Cyan & Deep Navy)',
                  'Medical Oncology Board Certification (Emerald & Gold Foil)',
                  'Global FinTech Algorithmic Trader (Slate & Gold Minimal)',
                  'Executive Master of Business Administration (Ivory Parchment)',
                ].map((preset) => (
                  <button
                    key={preset}
                    onClick={() => setPromptText(preset)}
                    className="px-2.5 py-1 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-300 text-[11px] border border-slate-700 transition"
                  >
                    {preset}
                  </button>
                ))}
              </div>
            </div>

            <button
              onClick={handleGenerateFromPrompt}
              disabled={isGenerating}
              className="w-full py-3 rounded-xl bg-gradient-to-r from-indigo-600 to-cyan-600 hover:from-indigo-500 hover:to-cyan-500 text-white font-bold text-xs shadow-xl shadow-indigo-600/30 flex items-center justify-center gap-2 transition"
            >
              {isGenerating ? (
                <>
                  <RefreshCw className="w-4 h-4 animate-spin text-cyan-300" />
                  <span>Synthesizing Vector Blueprint...</span>
                </>
              ) : (
                <>
                  <Sparkles className="w-4 h-4 text-yellow-300" />
                  <span>Generate Blueprint & Apply to Canvas</span>
                </>
              )}
            </button>
          </div>

          {/* Generated Blueprint JSON View */}
          <div className="bg-slate-900/90 rounded-2xl border border-slate-800 p-6 space-y-4 flex flex-col justify-between">
            <div>
              <div className="flex items-center justify-between pb-3 border-b border-slate-800">
                <div className="flex items-center gap-2">
                  <FileCode className="w-4 h-4 text-cyan-400" />
                  <h3 className="font-sora font-bold text-sm text-white">Generated Design Schema</h3>
                </div>
                <button
                  onClick={() => setActiveTab('editor')}
                  className="text-xs text-cyan-400 hover:underline flex items-center gap-1 font-semibold"
                >
                  <span>Open in Canvas Editor</span>
                  <ArrowRight className="w-3.5 h-3.5" />
                </button>
              </div>

              <div className="mt-4 bg-slate-950 p-4 rounded-xl border border-slate-800/80 font-mono text-[11px] text-slate-300 h-72 overflow-y-auto scrollbar-thin scrollbar-thumb-slate-800">
                {generatedJson ? (
                  <pre>{generatedJson}</pre>
                ) : (
                  <div className="text-slate-600 text-center py-24">
                    Click &quot;Generate Blueprint&quot; to compile schema JSON.
                  </div>
                )}
              </div>
            </div>

            {/* Accessibility Alt-Text Generator */}
            <div className="pt-3 border-t border-slate-800 space-y-2">
              <div className="flex items-center justify-between">
                <span className="text-xs font-semibold text-slate-300 flex items-center gap-1.5">
                  <Eye className="w-3.5 h-3.5 text-indigo-400" />
                  WCAG 2.2 Compliant Alt-Text
                </span>
                <button
                  onClick={handleGenerateAltText}
                  className="text-[11px] text-cyan-400 hover:underline font-semibold"
                >
                  Generate Alt-Text
                </button>
              </div>
              {altTextResult && (
                <div className="p-2.5 rounded-lg bg-slate-950 border border-slate-800 text-[11px] text-slate-300">
                  {altTextResult}
                </div>
              )}
            </div>
          </div>
        </div>
      )}

      {/* Tab 2: Brand-Kit Extractor */}
      {activeTabSub === 'brand' && (
        <div className="max-w-3xl mx-auto bg-slate-900/90 rounded-2xl border border-slate-800 p-6 space-y-6">
          <div>
            <h3 className="font-sora font-bold text-base text-white">
              Institutional Brand-Kit Extractor
            </h3>
            <p className="text-xs text-slate-400 mt-0.5">
              Harmonize certificate colors, seal embossing, and fonts with your university or
              enterprise identity.
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-4 text-xs">
            <div>
              <label className="text-slate-300 font-semibold block mb-1">Organization Name</label>
              <input
                type="text"
                value={brandOrgName}
                onChange={(e) => setBrandOrgName(e.target.value)}
                className="w-full bg-slate-950 border border-slate-700 rounded-xl p-2.5 text-slate-100"
              />
            </div>
            <div>
              <label className="text-slate-300 font-semibold block mb-1">
                Official Website / Domain
              </label>
              <input
                type="text"
                defaultValue="https://stanford.edu"
                className="w-full bg-slate-950 border border-slate-700 rounded-xl p-2.5 text-slate-100 font-mono"
              />
            </div>
          </div>

          <div className="grid grid-cols-2 gap-4 text-xs">
            <div>
              <label className="text-slate-300 font-semibold block mb-1">Primary Brand Color</label>
              <div className="flex items-center gap-2">
                <input
                  type="color"
                  value={brandPrimaryColor}
                  onChange={(e) => setBrandPrimaryColor(e.target.value)}
                  className="w-9 h-9 rounded-lg border border-slate-700 cursor-pointer bg-transparent"
                />
                <span className="font-mono text-slate-300 uppercase">{brandPrimaryColor}</span>
              </div>
            </div>
            <div>
              <label className="text-slate-300 font-semibold block mb-1">
                Secondary Accent Color
              </label>
              <div className="flex items-center gap-2">
                <input
                  type="color"
                  value={brandSecondaryColor}
                  onChange={(e) => setBrandSecondaryColor(e.target.value)}
                  className="w-9 h-9 rounded-lg border border-slate-700 cursor-pointer bg-transparent"
                />
                <span className="font-mono text-slate-300 uppercase">{brandSecondaryColor}</span>
              </div>
            </div>
          </div>

          <div className="pt-2">
            <button
              onClick={() => {
                setExtractedBrandKit({
                  fonts: ['Cinzel (Display)', 'Inter (Body)', 'Alex Brush (Signatures)'],
                  seal: 'Royal Gold 24k with Embossed Latitudinal Rings',
                  border: 'Double-Stitch 3mm with Security Micro-Text',
                });
                confetti({ particleCount: 40 });
              }}
              className="px-5 py-2.5 rounded-xl bg-indigo-600 hover:bg-indigo-500 text-white font-bold text-xs flex items-center gap-2"
            >
              <Wand2 className="w-4 h-4" />
              <span>Apply Brand-Kit to Current Canvas</span>
            </button>
          </div>

          {extractedBrandKit && (
            <div className="bg-slate-950 p-4 rounded-xl border border-slate-800 space-y-2 text-xs">
              <span className="font-bold text-cyan-400 block">Applied Brand System:</span>
              <div className="text-slate-300">
                • Typography Hierarchy: {extractedBrandKit.fonts.join(' • ')}
              </div>
              <div className="text-slate-300">• Embellished Seal: {extractedBrandKit.seal}</div>
              <div className="text-slate-300">• Border Integrity: {extractedBrandKit.border}</div>
            </div>
          )}
        </div>
      )}

      {/* Tab 3: Fraud Shield & Content Validator */}
      {activeTabSub === 'validator' && (
        <div className="max-w-3xl mx-auto bg-slate-900/90 rounded-2xl border border-slate-800 p-6 space-y-6">
          <div className="flex items-center justify-between">
            <div>
              <h3 className="font-sora font-bold text-base text-white">
                Fraud Shield & Accreditation Audit
              </h3>
              <p className="text-xs text-slate-400 mt-0.5">
                Deep inspects typography, legally required disclaimer clauses, and anti-forgery
                elements.
              </p>
            </div>
            <button
              onClick={handleRunValidator}
              disabled={isValidating}
              className="px-4 py-2 rounded-xl bg-cyan-600 hover:bg-cyan-500 text-white font-bold text-xs flex items-center gap-2"
            >
              {isValidating ? (
                <RefreshCw className="w-4 h-4 animate-spin" />
              ) : (
                <ShieldCheck className="w-4 h-4" />
              )}
              <span>Run Deep Audit</span>
            </button>
          </div>

          {validatorReport ? (
            <div className="space-y-4">
              <div className="flex items-center justify-between p-4 rounded-xl bg-emerald-950/40 border border-emerald-500/40">
                <div>
                  <span className="text-xs text-emerald-300 block">Security & Compliance Index</span>
                  <span className="text-3xl font-sora font-extrabold text-white">
                    {validatorReport.score} / 100
                  </span>
                </div>
                <div className="text-right">
                  <span className="text-xs font-mono font-bold text-emerald-400 bg-emerald-500/20 px-2 py-0.5 rounded border border-emerald-500/30">
                    {validatorReport.tamperShieldTier}
                  </span>
                </div>
              </div>

              <div className="space-y-2.5">
                {validatorReport.findings.map((f: any, idx: number) => (
                  <div
                    key={idx}
                    className="p-3.5 rounded-xl bg-slate-950 border border-slate-800 flex items-start gap-3"
                  >
                    {f.type === 'success' ? (
                      <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0 mt-0.5" />
                    ) : (
                      <AlertTriangle className="w-4 h-4 text-amber-400 shrink-0 mt-0.5" />
                    )}
                    <div>
                      <h4 className="text-xs font-bold text-white">{f.title}</h4>
                      <p className="text-[11px] text-slate-400 mt-0.5">{f.desc}</p>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          ) : (
            <div className="text-center py-16 text-slate-500 text-xs">
              Click &quot;Run Deep Audit&quot; to evaluate template compliance.
            </div>
          )}
        </div>
      )}

      {/* Tab 4: Multilingual & RTL Auto-Layout */}
      {activeTabSub === 'languages' && (
        <div className="max-w-4xl mx-auto bg-slate-900/90 rounded-2xl border border-slate-800 p-6 space-y-6">
          <div>
            <h3 className="font-sora font-bold text-base text-white">
              Multilingual Auto-Layout (20+ Languages + RTL Support)
            </h3>
            <p className="text-xs text-slate-400 mt-0.5">
              Converts certificates into global credentials with verified native terminology and
              font bounding box adjustments.
            </p>
          </div>

          <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-5 gap-2.5">
            {Object.keys(MULTILINGUAL_TRANSLATIONS).map((lang) => {
              const item = MULTILINGUAL_TRANSLATIONS[lang];
              const isSelected = selectedLanguage === lang;
              return (
                <button
                  key={lang}
                  onClick={() => handleApplyLanguage(lang)}
                  className={`p-3 rounded-xl border text-left text-xs transition ${
                    isSelected
                      ? 'bg-indigo-600/30 border-cyan-400 text-white shadow'
                      : 'bg-slate-950 border-slate-800 text-slate-300 hover:border-slate-700'
                  }`}
                >
                  <div className="flex justify-between items-center mb-1">
                    <span className="font-bold text-white">{lang}</span>
                    {item.isRtl && (
                      <span className="text-[9px] font-mono font-bold text-amber-400 bg-amber-500/20 px-1 rounded">
                        RTL
                      </span>
                    )}
                  </div>
                  <div className="text-[10px] text-slate-400 truncate">{item.title}</div>
                </button>
              );
            })}
          </div>

          <div className="p-4 rounded-xl bg-slate-950 border border-slate-800 text-xs space-y-2">
            <span className="font-bold text-cyan-400 block">
              Active Language Preview ({selectedLanguage}):
            </span>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-3 text-slate-300">
              <div>
                <span className="text-slate-500 text-[10px] block">Translated Title:</span>
                <span className="font-semibold text-white">
                  {MULTILINGUAL_TRANSLATIONS[selectedLanguage]?.title}
                </span>
              </div>
              <div>
                <span className="text-slate-500 text-[10px] block">Organization Banner:</span>
                <span className="font-semibold text-white">
                  {MULTILINGUAL_TRANSLATIONS[selectedLanguage]?.orgHeader}
                </span>
              </div>
              <div className="md:col-span-2">
                <span className="text-slate-500 text-[10px] block">Conferral Statement:</span>
                <span className="italic text-slate-300">
                  {MULTILINGUAL_TRANSLATIONS[selectedLanguage]?.statement}
                </span>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
