import React, { useState } from 'react';
import { useCert } from '../../context/CertContext';
import { UserRole, Organization } from '../../types';
import { generateProceduralSvg, getOrgHue } from '../../utils/proceduralLogo';
import {
  Shield,
  KeyRound,
  Building,
  UserCheck,
  CheckCircle2,
  Lock,
  Globe2,
  RefreshCw,
  Hash,
  Database,
  History,
  Layers,
  Sparkles,
} from 'lucide-react';

export const AuthAndOrgs: React.FC = () => {
  const {
    currentUser,
    setCurrentUserRole,
    organizations,
    currentOrg,
    switchOrganization,
    toggle2FA,
    updateOrgSettings,
    auditLogs,
  } = useCert();

  const [newOrgName, setNewOrgName] = useState('');
  const [showAddOrg, setShowAddOrg] = useState(false);

  const roles: { role: UserRole; desc: string }[] = [
    { role: 'OWNER', desc: 'Full billing, audit purge, cryptographic root keys & workspace access' },
    { role: 'ADMIN', desc: 'Team member invitations, compliance packs & domain settings' },
    { role: 'DESIGNER', desc: 'Can create and edit visual templates, brand kits & typography' },
    { role: 'ISSUER', desc: 'Can execute single & bulk certificate runs, verify credentials' },
    { role: 'VIEWER', desc: 'Read-only access to templates, audit registry & verification logs' },
  ];

  return (
    <div className="min-h-[calc(100vh-64px)] bg-[#0B0F1E] text-slate-100 p-6 md:p-8 space-y-8">
      {/* Header Banner */}
      <div className="flex flex-col md:flex-row md:items-end justify-between gap-4 border-b border-slate-800 pb-6">
        <div>
          <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-indigo-500/10 border border-indigo-500/20 text-indigo-400 text-xs font-semibold mb-3">
            <Shield className="w-3.5 h-3.5 text-cyan-400" />
            Zero-Trust Identity • BCrypt-12 • Ed25519 Root Authorities
          </div>
          <h1 className="text-3xl md:text-4xl font-sora font-extrabold tracking-tight text-white">
            Identity, Orgs & <span className="text-cyan-400">Security</span>
          </h1>
          <p className="text-slate-400 text-sm mt-1 max-w-2xl">
            Manage granular Role-Based Access Control (RBAC), multi-tenant workspaces with
            procedural SVG logos, Two-Factor Authentication (2FA), and WORM immutable audit logs.
          </p>
        </div>
      </div>

      {/* 2-Column Grid */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        {/* Left 2 Cols: RBAC & Multi-Tenant Workspaces */}
        <div className="lg:col-span-2 space-y-6">
          {/* RBAC Role Switcher Simulator */}
          <div className="bg-slate-900/90 rounded-2xl border border-slate-800 p-6 space-y-4">
            <div className="flex items-center justify-between pb-3 border-b border-slate-800">
              <div className="flex items-center gap-2">
                <UserCheck className="w-4 h-4 text-cyan-400" />
                <h3 className="font-sora font-bold text-sm text-white">
                  RBAC Role Simulator (Active: {currentUser.role})
                </h3>
              </div>
              <span className="text-xs text-slate-400 font-mono">{currentUser.email}</span>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-3">
              {roles.map((r) => {
                const isCurrent = currentUser.role === r.role;
                return (
                  <button
                    key={r.role}
                    onClick={() => setCurrentUserRole(r.role)}
                    className={`p-3.5 rounded-xl border text-left transition flex flex-col justify-between ${
                      isCurrent
                        ? 'bg-indigo-600/20 border-cyan-400 text-white shadow-lg'
                        : 'bg-slate-950 border-slate-800 hover:border-slate-700 text-slate-400'
                    }`}
                  >
                    <div>
                      <div className="flex items-center justify-between mb-1">
                        <span className="font-bold text-xs text-white">{r.role}</span>
                        {isCurrent && <CheckCircle2 className="w-3.5 h-3.5 text-cyan-400" />}
                      </div>
                      <p className="text-[11px] leading-snug text-slate-400">{r.desc}</p>
                    </div>
                  </button>
                );
              })}
            </div>
          </div>

          {/* Workspaces & Procedural Logos */}
          <div className="bg-slate-900/90 rounded-2xl border border-slate-800 p-6 space-y-4">
            <div className="flex items-center justify-between pb-3 border-b border-slate-800">
              <div className="flex items-center gap-2">
                <Building className="w-4 h-4 text-indigo-400" />
                <h3 className="font-sora font-bold text-sm text-white">
                  Multi-Tenant Workspaces & Procedural Logos
                </h3>
              </div>
              <span className="text-xs text-slate-400 font-mono">
                {organizations.length} Active Tenants
              </span>
            </div>

            <div className="space-y-3">
              {organizations.map((org) => {
                const isSelected = org.id === currentOrg.id;
                const svgMarkup = generateProceduralSvg(org.name, org.hue, 44);

                return (
                  <div
                    key={org.id}
                    onClick={() => switchOrganization(org.id)}
                    className={`p-4 rounded-xl border cursor-pointer transition flex items-center justify-between ${
                      isSelected
                        ? 'bg-indigo-950/40 border-cyan-400 shadow-md'
                        : 'bg-slate-950 border-slate-800/80 hover:border-slate-700'
                    }`}
                  >
                    <div className="flex items-center gap-3.5">
                      <div
                        className="shrink-0 rounded-xl overflow-hidden shadow"
                        dangerouslySetInnerHTML={{ __html: svgMarkup }}
                      />
                      <div>
                        <div className="flex items-center gap-2">
                          <h4 className="font-bold text-sm text-white">{org.name}</h4>
                          <span className="text-[10px] font-mono px-1.5 py-0.5 rounded bg-slate-800 text-slate-400">
                            Hue: {org.hue}°
                          </span>
                        </div>
                        <div className="flex items-center gap-3 text-xs text-slate-400 mt-1">
                          <span>Domain: {org.customDomain || 'certiverse.ai'}</span>
                          <span>•</span>
                          <span>Plan: {org.plan}</span>
                          <span>•</span>
                          <span>Storage: {org.storageUsedMb} MB</span>
                        </div>
                      </div>
                    </div>

                    <div>
                      {isSelected ? (
                        <span className="px-3 py-1 rounded-full bg-cyan-500/20 text-cyan-300 text-xs font-bold border border-cyan-500/40">
                          Active Workspace
                        </span>
                      ) : (
                        <span className="text-xs text-slate-400 hover:text-white">Switch</span>
                      )}
                    </div>
                  </div>
                );
              })}
            </div>

            {/* Workspace Settings (White-label & Custom Domain) */}
            <div className="pt-4 border-t border-slate-800 grid grid-cols-1 md:grid-cols-2 gap-4 text-xs">
              <div className="bg-slate-950 p-3.5 rounded-xl border border-slate-800 flex items-center justify-between">
                <div>
                  <span className="font-bold text-white block">White-Label Branding</span>
                  <span className="text-[11px] text-slate-400">
                    Remove CertiVerse badge on verified certificates
                  </span>
                </div>
                <input
                  type="checkbox"
                  checked={currentOrg.whitelabel}
                  onChange={(e) => updateOrgSettings({ whitelabel: e.target.checked })}
                  className="w-4 h-4 accent-indigo-500 cursor-pointer"
                />
              </div>

              <div className="bg-slate-950 p-3.5 rounded-xl border border-slate-800 flex items-center justify-between">
                <div>
                  <span className="font-bold text-white block">Custom SSL Domain</span>
                  <span className="text-[11px] text-slate-400 font-mono">
                    {currentOrg.customDomain}
                  </span>
                </div>
                <span className="text-[10px] font-bold text-emerald-400 bg-emerald-500/10 px-2 py-0.5 rounded border border-emerald-500/20">
                  Cloudflare SSL Active
                </span>
              </div>
            </div>
          </div>
        </div>

        {/* Right 1 Col: Security Settings & WORM Audit Trail */}
        <div className="space-y-6">
          {/* 2FA & SSO Security Card */}
          <div className="bg-slate-900/90 rounded-2xl border border-slate-800 p-6 space-y-4">
            <div className="flex items-center gap-2 pb-2 border-b border-slate-800">
              <KeyRound className="w-4 h-4 text-amber-400" />
              <h3 className="font-sora font-bold text-sm text-white">Security & 2FA Status</h3>
            </div>

            <div className="space-y-3 text-xs">
              {/* 2FA Toggle */}
              <div className="flex items-center justify-between p-3 rounded-xl bg-slate-950 border border-slate-800">
                <div>
                  <span className="font-bold text-white block">TOTP Two-Factor Auth</span>
                  <span className="text-[11px] text-slate-400">
                    Required for issuer & owner roles
                  </span>
                </div>
                <button
                  onClick={toggle2FA}
                  className={`px-3 py-1 rounded-full font-bold text-[11px] border transition ${
                    currentUser.twoFactorEnabled
                      ? 'bg-emerald-500/20 text-emerald-400 border-emerald-500/30'
                      : 'bg-rose-500/20 text-rose-400 border-rose-500/30'
                  }`}
                >
                  {currentUser.twoFactorEnabled ? 'Enabled' : 'Disabled'}
                </button>
              </div>

              {/* JWT Rotation Specs */}
              <div className="p-3 rounded-xl bg-slate-950 border border-slate-800 space-y-1.5 text-[11px]">
                <div className="flex justify-between text-slate-400">
                  <span>Access Token Lifetime:</span>
                  <span className="font-mono text-cyan-400 font-bold">15 Minutes (RS256)</span>
                </div>
                <div className="flex justify-between text-slate-400">
                  <span>Refresh Rotation:</span>
                  <span className="font-mono text-indigo-400 font-bold">7-Day Sliding Window</span>
                </div>
                <div className="flex justify-between text-slate-400">
                  <span>Password Hash Cost:</span>
                  <span className="font-mono text-amber-400 font-bold">BCrypt-12 Salted</span>
                </div>
              </div>
            </div>
          </div>

          {/* Cryptographic WORM (Write Once Read Many) Audit Log */}
          <div className="bg-slate-900/90 rounded-2xl border border-slate-800 p-6 space-y-4">
            <div className="flex items-center justify-between pb-2 border-b border-slate-800">
              <div className="flex items-center gap-2">
                <History className="w-4 h-4 text-cyan-400" />
                <h3 className="font-sora font-bold text-sm text-white">Immutable WORM Audit Trail</h3>
              </div>
              <span className="text-[10px] text-slate-500 font-mono">Chained Hashes</span>
            </div>

            <div className="space-y-2.5 max-h-72 overflow-y-auto scrollbar-thin scrollbar-thumb-slate-800">
              {auditLogs.map((log) => (
                <div
                  key={log.id}
                  className="p-2.5 rounded-xl bg-slate-950 border border-slate-800/80 text-[11px] space-y-1"
                >
                  <div className="flex justify-between items-center text-[10px]">
                    <span className="font-bold text-cyan-400">{log.action}</span>
                    <span className="text-slate-500 font-mono">{log.timestamp}</span>
                  </div>
                  <p className="text-slate-300 leading-tight">{log.details}</p>
                  <div className="text-[9px] font-mono text-slate-600 truncate">
                    Hash Chain: {log.immutableHash}
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
