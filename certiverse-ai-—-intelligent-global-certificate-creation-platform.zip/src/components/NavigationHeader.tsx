import React from 'react';
import { useCert } from '../context/CertContext';
import { BrandLogo } from './BrandLogo';
import { generateProceduralSvg } from '../utils/proceduralLogo';
import {
  Sparkles,
  Award,
  ShieldCheck,
  Layers,
  Wand2,
  Globe,
  Lock,
  FileCode,
  Sun,
  Moon,
  ChevronDown,
  Sliders,
  Plus,
} from 'lucide-react';

export const NavigationHeader: React.FC = () => {
  const {
    activeTab,
    setActiveTab,
    currentOrg,
    organizations,
    switchOrganization,
    currentUser,
    isDarkMode,
    toggleDarkMode,
  } = useCert();

  const navItems = [
    { id: 'landing', label: 'Overview', icon: null },
    { id: 'create_cert', label: 'Create Certificate', icon: Award },
    { id: 'editor', label: 'Canvas Studio', icon: Sliders },
    { id: 'gallery', label: '30+ Templates', icon: Layers },
    { id: 'verify', label: 'Verify Portal', icon: ShieldCheck },
    { id: 'bulk', label: 'Bulk Engine', icon: Sparkles },
    { id: 'ai_studio', label: 'AI Studio', icon: Wand2 },
    { id: 'compliance', label: 'Country Packs', icon: Globe },
    { id: 'orgs_auth', label: 'RBAC & Orgs', icon: Lock },
    { id: 'monorepo_code', label: 'Architecture', icon: FileCode },
  ];

  const orgLogoSvg = generateProceduralSvg(currentOrg.name, currentOrg.hue, 28);

  return (
    <header className="h-16 border-b border-slate-800 bg-[#090D1A]/95 backdrop-blur-md px-4 sm:px-6 flex items-center justify-between sticky top-0 z-40 shrink-0">
      {/* Left: Brand Logo & Workspace Switcher */}
      <div className="flex items-center gap-6">
        <button
          onClick={() => setActiveTab('landing')}
          className="text-left focus:outline-none transition active:scale-95"
        >
          <BrandLogo size={32} />
        </button>

        {/* Tenant Organization Switcher */}
        <div className="hidden lg:flex items-center gap-2 pl-4 border-l border-slate-800">
          <div
            className="rounded-lg overflow-hidden shadow shrink-0"
            dangerouslySetInnerHTML={{ __html: orgLogoSvg }}
          />
          <select
            value={currentOrg.id}
            onChange={(e) => switchOrganization(e.target.value)}
            className="bg-transparent text-xs font-semibold text-slate-200 focus:outline-none cursor-pointer max-w-[160px] truncate"
          >
            {organizations.map((org) => (
              <option key={org.id} value={org.id} className="bg-slate-900 text-slate-100">
                {org.name}
              </option>
            ))}
          </select>
        </div>
      </div>

      {/* Center: Navigation Tabs */}
      <nav className="hidden xl:flex items-center gap-1">
        {navItems.map((item) => {
          const isCurrent = activeTab === item.id;
          const Icon = item.icon;
          return (
            <button
              key={item.id}
              onClick={() => setActiveTab(item.id)}
              className={`px-3 py-1.5 rounded-lg text-xs font-semibold flex items-center gap-1.5 transition ${
                isCurrent
                  ? 'bg-indigo-600/20 text-cyan-400 border border-indigo-500/30 shadow'
                  : 'text-slate-400 hover:text-slate-200 hover:bg-slate-800/50'
              }`}
            >
              {Icon && <Icon className="w-3.5 h-3.5" />}
              <span>{item.label}</span>
            </button>
          );
        })}
      </nav>

      {/* Right: Role indicator & Actions */}
      <div className="flex items-center gap-3">
        {/* Mobile Nav Select */}
        <div className="xl:hidden">
          <select
            value={activeTab}
            onChange={(e) => setActiveTab(e.target.value)}
            className="bg-slate-900 border border-slate-800 rounded-lg px-2.5 py-1.5 text-xs text-slate-200 font-semibold focus:outline-none"
          >
            {navItems.map((item) => (
              <option key={item.id} value={item.id} className="bg-slate-900 text-slate-100">
                {item.label}
              </option>
            ))}
          </select>
        </div>

        {/* Current Role Badge */}
        <button
          onClick={() => setActiveTab('orgs_auth')}
          title="Click to switch RBAC simulation role"
          className="flex items-center gap-1.5 px-2.5 py-1 rounded-full bg-slate-900 border border-slate-800 hover:border-slate-700 transition"
        >
          <span className="w-2 h-2 rounded-full bg-emerald-400" />
          <span className="text-[11px] font-mono font-bold text-slate-300">
            {currentUser.role}
          </span>
        </button>

        {/* Create Certificate Button */}
        <button
          onClick={() => setActiveTab('create_cert')}
          className={`px-3.5 py-1.5 rounded-lg text-xs font-bold shadow-md transition active:scale-95 flex items-center gap-1.5 ${
            activeTab === 'create_cert'
              ? 'bg-cyan-500 text-slate-950 shadow-cyan-500/20'
              : 'bg-gradient-to-r from-indigo-600 to-cyan-600 hover:from-indigo-500 hover:to-cyan-500 text-white shadow-indigo-600/20'
          }`}
        >
          <Plus className="w-3.5 h-3.5" />
          <span>Create Certificate</span>
        </button>

        {/* Studio CTA Button */}
        {activeTab !== 'editor' && (
          <button
            onClick={() => setActiveTab('editor')}
            className="hidden sm:flex px-3 py-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs font-semibold border border-slate-700 transition"
          >
            Canvas Studio
          </button>
        )}
      </div>
    </header>
  );
};
