import React, { useState } from 'react';
import { useCert } from '../../context/CertContext';
import { COUNTRY_PACKS, CountryPack } from '../../data/countryPacks';
import {
  Globe,
  ShieldCheck,
  FileCode,
  Check,
  Copy,
  CreditCard,
  Trash2,
  Lock,
  Layers,
  Sparkles,
  ExternalLink,
} from 'lucide-react';
import confetti from 'canvas-confetti';

export const CountryPacks: React.FC = () => {
  const { currentOrg, updateOrgSettings, addElement, setActiveTab } = useCert();

  const [activePackId, setActivePackId] = useState<string>('india_abc_nsdc');
  const [copiedSchema, setCopiedSchema] = useState(false);
  const [purgeEmail, setPurgeEmail] = useState('');
  const [purgeSuccess, setPurgeSuccess] = useState(false);

  const pack = COUNTRY_PACKS[activePackId] || COUNTRY_PACKS['india_abc_nsdc'];

  const copySchemaJson = () => {
    navigator.clipboard.writeText(JSON.stringify(pack.sampleJsonSchema, null, 2));
    setCopiedSchema(true);
    setTimeout(() => setCopiedSchema(false), 2000);
  };

  const handleActivatePack = (pId: string) => {
    updateOrgSettings({ countryPack: pId as any });
    confetti({
      particleCount: 50,
      spread: 60,
    });
  };

  const handleInjectFieldToken = (field: any) => {
    addElement('token', {
      tokenName: field.tokenKey,
      content: field.defaultValue,
      fontSize: 16,
      color: '#F59E0B',
      textAlign: 'center',
    });
    setActiveTab('editor');
  };

  const handlePurgeRequest = (e: React.FormEvent) => {
    e.preventDefault();
    if (!purgeEmail) return;
    setPurgeSuccess(true);
    setTimeout(() => setPurgeSuccess(false), 4000);
    setPurgeEmail('');
  };

  return (
    <div className="min-h-[calc(100vh-64px)] bg-[#0B0F1E] text-slate-100 p-6 md:p-8 space-y-8">
      {/* Header Banner */}
      <div className="flex flex-col md:flex-row md:items-end justify-between gap-4 border-b border-slate-800 pb-6">
        <div>
          <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-cyan-500/10 border border-cyan-500/20 text-cyan-400 text-xs font-semibold mb-3">
            <Globe className="w-3.5 h-3.5 text-cyan-400" />
            Global Regulatory Standards & Pluggable Compliance Packs
          </div>
          <h1 className="text-3xl md:text-4xl font-sora font-extrabold tracking-tight text-white">
            Country <span className="text-cyan-400">Compliance Packs</span>
          </h1>
          <p className="text-slate-400 text-sm mt-1 max-w-2xl">
            Plug-and-play regulatory schemas for India Skill Mission & ABC, US Continuing Education
            (CEU), and European Union Europass (ECTS) with automated field validations.
          </p>
        </div>
      </div>

      {/* Country Pack Selection Cards */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        {Object.values(COUNTRY_PACKS).map((cp) => {
          const isCurrentActive = currentOrg.countryPack === cp.id;
          const isSelectedTab = activePackId === cp.id;

          return (
            <div
              key={cp.id}
              onClick={() => setActivePackId(cp.id)}
              className={`p-5 rounded-2xl border cursor-pointer transition flex flex-col justify-between ${
                isSelectedTab
                  ? 'bg-slate-900 border-cyan-400 shadow-xl shadow-cyan-500/10'
                  : 'bg-slate-900/60 border-slate-800 hover:border-slate-700'
              }`}
            >
              <div>
                <div className="flex items-center justify-between mb-3">
                  <span className="text-3xl">{cp.flagEmoji}</span>
                  {isCurrentActive && (
                    <span className="text-[10px] font-bold uppercase px-2 py-0.5 rounded-full bg-emerald-500/20 text-emerald-400 border border-emerald-500/30">
                      Active Org Pack
                    </span>
                  )}
                </div>
                <h3 className="font-sora font-bold text-sm text-white">{cp.name}</h3>
                <p className="text-[11px] text-slate-400 mt-1 leading-snug">{cp.standardsBody}</p>
              </div>

              <div className="pt-4 mt-4 border-t border-slate-800/80 flex items-center justify-between text-xs">
                <span className="text-cyan-400 font-semibold">{cp.fields.length} Custom Fields</span>
                <span className="font-mono text-slate-500">{cp.region}</span>
              </div>
            </div>
          );
        })}
      </div>

      {/* Active Pack Detailed Configuration & JSON Schema */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        {/* Left 2 Cols: Pack Specifications & Field Injector */}
        <div className="lg:col-span-2 bg-slate-900/90 rounded-2xl border border-slate-800 p-6 space-y-6">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 pb-4 border-b border-slate-800">
            <div>
              <div className="flex items-center gap-2">
                <span className="text-2xl">{pack.flagEmoji}</span>
                <h3 className="font-sora font-bold text-lg text-white">{pack.name}</h3>
              </div>
              <p className="text-xs text-slate-400 mt-1">{pack.description}</p>
            </div>

            <button
              onClick={() => handleActivatePack(pack.id)}
              className="px-4 py-2 rounded-xl bg-gradient-to-r from-indigo-600 to-cyan-600 hover:from-indigo-500 hover:to-cyan-500 text-white font-bold text-xs shrink-0 shadow"
            >
              Set as Default Workspace Pack
            </button>
          </div>

          {/* Compliance Badge */}
          <div className="p-4 rounded-xl bg-slate-950 border border-slate-800 flex items-center justify-between">
            <div className="flex items-center gap-3">
              <ShieldCheck className="w-6 h-6 text-emerald-400" />
              <div>
                <span className="text-xs font-bold text-white block">
                  {pack.complianceBadge.title}
                </span>
                <span className="text-[11px] font-mono text-slate-400">
                  Standard Code: {pack.complianceBadge.code}
                </span>
              </div>
            </div>
            <span
              className="text-xs font-bold px-2.5 py-1 rounded-full border"
              style={{
                borderColor: pack.complianceBadge.color,
                color: pack.complianceBadge.color,
              }}
            >
              Audited 2026
            </span>
          </div>

          {/* Pluggable Fields */}
          <div className="space-y-3">
            <h4 className="font-sora font-bold text-sm text-white">
              Compliance Form Fields & Dynamic Tokens
            </h4>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
              {pack.fields.map((f) => (
                <div
                  key={f.id}
                  className="p-3.5 rounded-xl bg-slate-950 border border-slate-800/80 flex flex-col justify-between space-y-2"
                >
                  <div>
                    <div className="flex justify-between items-start">
                      <span className="font-semibold text-xs text-slate-200">{f.label}</span>
                      <span className="text-[10px] font-mono text-cyan-400 font-bold">
                        {f.tokenKey}
                      </span>
                    </div>
                    <p className="text-[11px] text-slate-400 mt-1">{f.description}</p>
                  </div>

                  <div className="pt-2 border-t border-slate-900 flex justify-between items-center text-xs">
                    <span className="text-[10px] text-slate-500 font-mono">
                      Default: {f.defaultValue}
                    </span>
                    <button
                      onClick={() => handleInjectFieldToken(f)}
                      className="text-cyan-400 hover:text-cyan-300 text-[11px] font-semibold"
                    >
                      + Add to Canvas
                    </button>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>

        {/* Right 1 Col: Pluggable JSON Schema & Privacy Purge (GDPR/DPDP) */}
        <div className="space-y-6">
          {/* JSON Schema Card */}
          <div className="bg-slate-900/90 rounded-2xl border border-slate-800 p-6 space-y-3">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2">
                <FileCode className="w-4 h-4 text-cyan-400" />
                <h4 className="font-sora font-bold text-sm text-white">Pluggable Schema JSON</h4>
              </div>
              <button
                onClick={copySchemaJson}
                className="text-xs text-cyan-400 hover:text-cyan-300 flex items-center gap-1 font-semibold"
              >
                {copiedSchema ? <Check className="w-3.5 h-3.5" /> : <Copy className="w-3.5 h-3.5" />}
                {copiedSchema ? 'Copied' : 'Copy'}
              </button>
            </div>

            <div className="bg-slate-950 p-3 rounded-xl border border-slate-800/80 font-mono text-[10px] text-slate-300 h-60 overflow-y-auto scrollbar-thin scrollbar-thumb-slate-800">
              <pre>{JSON.stringify(pack.sampleJsonSchema, null, 2)}</pre>
            </div>
          </div>

          {/* Privacy & Right to be Forgotten (GDPR & DPDP) */}
          <div className="bg-slate-900/90 rounded-2xl border border-slate-800 p-6 space-y-4">
            <div className="flex items-center gap-2">
              <Trash2 className="w-4 h-4 text-rose-400" />
              <h4 className="font-sora font-bold text-sm text-white">
                GDPR & DPDP Privacy Purge
              </h4>
            </div>
            <p className="text-xs text-slate-400">
              Process verified deletion requests in accordance with EU GDPR Article 17 and India
              Digital Personal Data Protection Act (DPDP) 2023.
            </p>

            <form onSubmit={handlePurgeRequest} className="space-y-3">
              <input
                type="email"
                placeholder="recipient.email@domain.com"
                value={purgeEmail}
                onChange={(e) => setPurgeEmail(e.target.value)}
                className="w-full bg-slate-950 border border-slate-700 rounded-xl p-2.5 text-xs text-slate-100 placeholder:text-slate-500"
              />
              <button
                type="submit"
                className="w-full py-2 rounded-xl bg-rose-950/60 hover:bg-rose-900 text-rose-300 border border-rose-800/50 text-xs font-bold transition"
              >
                Execute Cryptographic Right-to-Erasure
              </button>
            </form>

            {purgeSuccess && (
              <div className="p-2.5 rounded-lg bg-emerald-950/60 border border-emerald-500/40 text-xs text-emerald-300">
                P-II purged from ledger. Immutable hash tombstoned as per DPDP standard.
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};
