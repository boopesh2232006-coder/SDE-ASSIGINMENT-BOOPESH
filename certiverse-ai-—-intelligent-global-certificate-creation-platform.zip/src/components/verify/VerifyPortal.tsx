import React, { useState, useEffect } from 'react';
import { useCert } from '../../context/CertContext';
import { CertificateRecord } from '../../types';
import { CertificateRenderer } from '../editor/CertificateRenderer';
import { exportCertificatePdf } from '../../utils/exportCert';
import {
  ShieldCheck,
  ShieldAlert,
  CheckCircle,
  ExternalLink,
  Copy,
  Check,
  Download,
  Share2,
  Code2,
  Calendar,
  Building2,
  Hash,
  Search,
  Award,
  Link as LinkIcon,
  Globe,
} from 'lucide-react';

export const VerifyPortal: React.FC = () => {
  const { certificates, getCertificateByTokenOrId, publicVerifyToken, setPublicVerifyToken, templates } =
    useCert();

  const [searchQuery, setSearchQuery] = useState<string>(
    publicVerifyToken || 'tok_live_7e8b91fa023a4b9c8d11'
  );
  const [activeCert, setActiveCert] = useState<CertificateRecord | null>(null);
  const [copiedLink, setCopiedLink] = useState(false);
  const [copiedEmbed, setCopiedEmbed] = useState(false);
  const [copiedHash, setCopiedHash] = useState(false);
  const [showEmbedCode, setShowEmbedCode] = useState(false);

  useEffect(() => {
    const cert = getCertificateByTokenOrId(searchQuery);
    if (cert) {
      setActiveCert(cert);
    } else if (certificates.length > 0) {
      setActiveCert(certificates[0]);
    }
  }, [searchQuery, certificates]);

  const handleSearch = (e: React.FormEvent) => {
    e.preventDefault();
    const cert = getCertificateByTokenOrId(searchQuery);
    if (cert) {
      setActiveCert(cert);
    }
  };

  const copyToClipboard = (text: string, setter: (val: boolean) => void) => {
    navigator.clipboard.writeText(text);
    setter(true);
    setTimeout(() => setter(false), 2000);
  };

  // Build real Add to LinkedIn URL
  const getLinkedInCertUrl = (cert: CertificateRecord) => {
    const issueDate = new Date(cert.issueDate);
    const year = issueDate.getFullYear() || 2026;
    const month = issueDate.getMonth() + 1 || 10;
    const certUrl = `https://certiverse.ai/v/${cert.token}`;

    const params = new URLSearchParams({
      startTask: 'CERTIFICATION_NAME',
      name: cert.course,
      organizationName: cert.issuerOrg,
      issueYear: year.toString(),
      issueMonth: month.toString(),
      certUrl: certUrl,
      certId: cert.certNo,
    });

    return `https://www.linkedin.com/profile/add?${params.toString()}`;
  };

  // Find matching template elements for full rendering
  const activeTemplate = templates.find((t) => t.id === activeCert?.templateId) || templates[0];

  return (
    <div className="min-h-[calc(100vh-64px)] bg-[#0B0F1E] text-slate-100 p-6 md:p-8 space-y-8">
      {/* Header Search & Lookup Bar */}
      <div className="max-w-4xl mx-auto text-center space-y-4">
        <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-cyan-500/10 border border-cyan-500/20 text-cyan-400 text-xs font-semibold">
          <ShieldCheck className="w-3.5 h-3.5 text-cyan-400" />
          Public Cryptographic Registry • Zero-Knowledge Verification
        </div>

        <h1 className="text-3xl md:text-5xl font-sora font-extrabold tracking-tight text-white">
          Verify <span className="text-cyan-400">Authenticity</span>
        </h1>
        <p className="text-slate-400 text-sm max-w-xl mx-auto">
          Enter any Certificate ID, signed verification token, or upload a digital credential to
          validate against immutable cryptographic signatures.
        </p>

        {/* Search input form */}
        <form onSubmit={handleSearch} className="max-w-xl mx-auto flex items-center gap-2">
          <div className="relative flex-1">
            <Search className="w-4 h-4 text-slate-400 absolute left-3.5 top-1/2 -translate-y-1/2 pointer-events-none" />
            <input
              type="text"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              placeholder="e.g. CV-AI-2026-884920 or tok_live_..."
              className="w-full bg-slate-900 border border-slate-700/80 rounded-xl pl-10 pr-4 py-2.5 text-sm text-slate-100 placeholder:text-slate-500 focus:outline-none focus:border-cyan-400"
            />
          </div>
          <button
            type="submit"
            className="px-5 py-2.5 rounded-xl bg-gradient-to-r from-indigo-600 to-cyan-600 hover:from-indigo-500 hover:to-cyan-500 text-white text-xs font-bold shadow-lg shadow-indigo-600/30 transition shrink-0"
          >
            Verify Ledger
          </button>
        </form>

        {/* Quick Demo Switcher */}
        <div className="flex items-center justify-center gap-2 text-xs text-slate-400 pt-1">
          <span>Try Demo Credential:</span>
          <button
            onClick={() => setSearchQuery('CV-AI-2026-884920')}
            className="text-cyan-400 underline hover:text-cyan-300 font-mono"
          >
            [Active Valid]
          </button>
          <span>•</span>
          <button
            onClick={() => setSearchQuery('CV-NSDC-2026-661092')}
            className="text-amber-400 underline hover:text-amber-300 font-mono"
          >
            [India NSDC/ABC]
          </button>
          <span>•</span>
          <button
            onClick={() => setSearchQuery('tok_revoked_demo_sample99')}
            className="text-rose-400 underline hover:text-rose-300 font-mono"
          >
            [Revoked Demo]
          </button>
        </div>
      </div>

      {/* Main Verification Card */}
      {activeCert ? (
        <div className="max-w-5xl mx-auto space-y-6">
          {/* Status Alert Banner */}
          {activeCert.status === 'active' ? (
            <div className="p-4 rounded-2xl bg-emerald-950/40 border border-emerald-500/40 text-emerald-200 flex flex-col md:flex-row items-center justify-between gap-4 shadow-lg shadow-emerald-950/20">
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 rounded-full bg-emerald-500/20 border border-emerald-400 flex items-center justify-center shrink-0">
                  <ShieldCheck className="w-6 h-6 text-emerald-400" />
                </div>
                <div>
                  <h3 className="font-sora font-bold text-base text-white flex items-center gap-2">
                    Official Authenticated Credential
                    <span className="text-[10px] font-mono uppercase bg-emerald-500/20 text-emerald-400 px-2 py-0.5 rounded border border-emerald-500/30">
                      Untampered & Valid
                    </span>
                  </h3>
                  <p className="text-xs text-emerald-300/80 mt-0.5">
                    Digitally signed by {activeCert.issuerOrg} using Ed25519 & anchored on public
                    ledger.
                  </p>
                </div>
              </div>

              <div className="flex items-center gap-2">
                <a
                  href={getLinkedInCertUrl(activeCert)}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="px-3.5 py-1.5 rounded-lg bg-[#0A66C2] hover:bg-[#004182] text-white text-xs font-bold flex items-center gap-1.5 shadow transition"
                >
                  <Award className="w-3.5 h-3.5" />
                  Add to LinkedIn
                </a>
                <button
                  onClick={() =>
                    exportCertificatePdf(
                      'verify-rendered-certificate',
                      `${activeCert.certNo}.pdf`
                    )
                  }
                  className="px-3.5 py-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs font-semibold flex items-center gap-1.5 border border-slate-700 transition"
                >
                  <Download className="w-3.5 h-3.5 text-cyan-400" />
                  Download PDF
                </button>
              </div>
            </div>
          ) : (
            <div className="p-4 rounded-2xl bg-rose-950/50 border border-rose-500/50 text-rose-200 flex flex-col md:flex-row items-center justify-between gap-4 shadow-lg shadow-rose-950/20">
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 rounded-full bg-rose-500/20 border border-rose-400 flex items-center justify-center shrink-0">
                  <ShieldAlert className="w-6 h-6 text-rose-400" />
                </div>
                <div>
                  <h3 className="font-sora font-bold text-base text-white flex items-center gap-2">
                    Credential Revoked by Issuer
                    <span className="text-[10px] font-mono uppercase bg-rose-500/20 text-rose-400 px-2 py-0.5 rounded border border-rose-500/30">
                      Invalid / Revoked
                    </span>
                  </h3>
                  <p className="text-xs text-rose-300 mt-0.5">
                    Revocation Reason: {activeCert.revocationReason || 'Violated accreditation criteria'}
                  </p>
                </div>
              </div>

              <div className="text-right text-xs text-rose-300 font-mono">
                Revoked On: {activeCert.revokedAt?.substring(0, 10)}
              </div>
            </div>
          )}

          {/* Certificate Visual Presentation */}
          <div className="bg-[#070A14] rounded-2xl border border-slate-800 p-6 flex flex-col items-center justify-center shadow-2xl relative overflow-hidden">
            <div id="verify-rendered-certificate" className="transform scale-[0.8] origin-center my-4">
              <CertificateRenderer
                elements={activeTemplate.elements}
                width={activeTemplate.width}
                height={activeTemplate.height}
                bgTheme={activeTemplate.bgTheme}
                recipientData={{
                  name: activeCert.recipientName,
                  course: activeCert.course,
                  date: activeCert.issueDate,
                  certNo: activeCert.certNo,
                  grade: activeCert.grade,
                }}
                token={activeCert.token}
                isPrintOrExport={true}
              />
            </div>
          </div>

          {/* Verification Details Grid */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            {/* Left Card: Recipient & Credential Specs */}
            <div className="bg-slate-900/90 rounded-2xl border border-slate-800 p-5 space-y-4">
              <div className="flex items-center gap-2 pb-3 border-b border-slate-800">
                <Building2 className="w-4 h-4 text-cyan-400" />
                <h4 className="font-sora font-bold text-sm text-white">Credential Specifications</h4>
              </div>

              <div className="space-y-3 text-xs">
                <div className="flex justify-between items-center py-1 border-b border-slate-800/60">
                  <span className="text-slate-400">Recipient Name</span>
                  <span className="font-bold text-slate-100">{activeCert.recipientName}</span>
                </div>
                <div className="flex justify-between items-center py-1 border-b border-slate-800/60">
                  <span className="text-slate-400">Awarded Program</span>
                  <span className="font-semibold text-cyan-300 text-right max-w-[260px] truncate">
                    {activeCert.course}
                  </span>
                </div>
                <div className="flex justify-between items-center py-1 border-b border-slate-800/60">
                  <span className="text-slate-400">Certificate Number</span>
                  <span className="font-mono font-bold text-slate-200">{activeCert.certNo}</span>
                </div>
                <div className="flex justify-between items-center py-1 border-b border-slate-800/60">
                  <span className="text-slate-400">Issuing Organization</span>
                  <span className="font-semibold text-slate-100">{activeCert.issuerOrg}</span>
                </div>
                <div className="flex justify-between items-center py-1 border-b border-slate-800/60">
                  <span className="text-slate-400">Issue Date</span>
                  <span className="font-mono text-slate-300">{activeCert.issueDate}</span>
                </div>
                {activeCert.grade && (
                  <div className="flex justify-between items-center py-1 border-b border-slate-800/60">
                    <span className="text-slate-400">Graduation Grade</span>
                    <span className="font-bold text-amber-400">{activeCert.grade}</span>
                  </div>
                )}
                {activeCert.skills && activeCert.skills.length > 0 && (
                  <div className="pt-1">
                    <span className="text-slate-400 block mb-1.5">Verified Competencies:</span>
                    <div className="flex flex-wrap gap-1.5">
                      {activeCert.skills.map((s, idx) => (
                        <span
                          key={idx}
                          className="px-2 py-0.5 rounded bg-slate-800 text-slate-300 text-[11px] border border-slate-700"
                        >
                          {s}
                        </span>
                      ))}
                    </div>
                  </div>
                )}
              </div>
            </div>

            {/* Right Card: Cryptography & Blockchain Proof */}
            <div className="bg-slate-900/90 rounded-2xl border border-slate-800 p-5 space-y-4">
              <div className="flex items-center gap-2 pb-3 border-b border-slate-800">
                <Hash className="w-4 h-4 text-indigo-400" />
                <h4 className="font-sora font-bold text-sm text-white">Cryptographic Proof & Ledger</h4>
              </div>

              <div className="space-y-3 text-xs">
                {/* SHA-256 Digest */}
                <div>
                  <div className="flex justify-between items-center text-slate-400 mb-1">
                    <span>SHA-256 Document Digest:</span>
                    <button
                      onClick={() => copyToClipboard(activeCert.sha256Hash, setCopiedHash)}
                      className="text-cyan-400 hover:text-cyan-300 text-[10px] flex items-center gap-1 font-semibold"
                    >
                      {copiedHash ? <Check className="w-3 h-3 text-green-400" /> : <Copy className="w-3 h-3" />}
                      {copiedHash ? 'Copied' : 'Copy'}
                    </button>
                  </div>
                  <div className="bg-slate-950 p-2 rounded-lg font-mono text-[10px] text-slate-300 break-all border border-slate-800">
                    {activeCert.sha256Hash}
                  </div>
                </div>

                {/* Blockchain Proof */}
                {activeCert.blockchainAnchor && (
                  <div className="bg-indigo-950/20 border border-indigo-500/20 rounded-xl p-3 space-y-1.5">
                    <div className="flex justify-between items-center">
                      <span className="text-slate-400">Anchor Network:</span>
                      <span className="font-semibold text-indigo-300">
                        {activeCert.blockchainAnchor.network}
                      </span>
                    </div>
                    <div className="flex justify-between items-center">
                      <span className="text-slate-400">Block Height:</span>
                      <span className="font-mono text-slate-200">
                        #{activeCert.blockchainAnchor.blockNumber}
                      </span>
                    </div>
                    <div className="flex justify-between items-center">
                      <span className="text-slate-400">Transaction Hash:</span>
                      <span className="font-mono text-[10px] text-slate-300 truncate max-w-[160px]">
                        {activeCert.blockchainAnchor.txHash}
                      </span>
                    </div>
                  </div>
                )}

                {/* Embed & Share Actions */}
                <div className="pt-2 flex items-center justify-between gap-3">
                  <button
                    onClick={() =>
                      copyToClipboard(`https://certiverse.ai/v/${activeCert.token}`, setCopiedLink)
                    }
                    className="flex-1 py-2 rounded-lg bg-slate-800 hover:bg-slate-700 text-xs font-semibold text-slate-300 flex items-center justify-center gap-1.5 transition"
                  >
                    <Share2 className="w-3.5 h-3.5 text-cyan-400" />
                    {copiedLink ? 'Link Copied!' : 'Copy Share Link'}
                  </button>

                  <button
                    onClick={() => setShowEmbedCode(!showEmbedCode)}
                    className="flex-1 py-2 rounded-lg bg-slate-800 hover:bg-slate-700 text-xs font-semibold text-slate-300 flex items-center justify-center gap-1.5 transition"
                  >
                    <Code2 className="w-3.5 h-3.5 text-indigo-400" />
                    Embed Badge
                  </button>
                </div>

                {showEmbedCode && (
                  <div className="bg-slate-950 p-2.5 rounded-lg border border-slate-800 text-[10px] font-mono text-slate-300 space-y-1">
                    <div className="flex justify-between text-slate-400">
                      <span>HTML iFrame Embed Widget:</span>
                      <button
                        onClick={() =>
                          copyToClipboard(
                            `<iframe src="https://certiverse.ai/v/${activeCert.token}" width="600" height="420" frameborder="0"></iframe>`,
                            setCopiedEmbed
                          )
                        }
                        className="text-cyan-400 font-semibold"
                      >
                        {copiedEmbed ? 'Copied' : 'Copy'}
                      </button>
                    </div>
                    <div className="text-slate-400 break-all select-all">
                      {`<iframe src="https://certiverse.ai/v/${activeCert.token}" width="600" height="420" frameborder="0"></iframe>`}
                    </div>
                  </div>
                )}
              </div>
            </div>
          </div>
        </div>
      ) : (
        <div className="max-w-md mx-auto text-center py-12 text-slate-400">
          <p>No certificate found matching token &quot;{searchQuery}&quot;.</p>
        </div>
      )}
    </div>
  );
};
