import React, { useState } from 'react';
import {
  Folder,
  FileCode,
  FileText,
  Copy,
  Check,
  Server,
  Layers,
  Database,
  Terminal,
  Cpu,
  GitBranch,
} from 'lucide-react';

const MONOREPO_FILES: Record<
  string,
  {
    language: string;
    path: string;
    content: string;
  }
> = {
  'docker-compose.yml': {
    language: 'yaml',
    path: '/docker-compose.yml',
    content: `version: '3.8'

services:
  # CertiVerse AI Web Application (Vite + React)
  web:
    build:
      context: ./apps/web
      dockerfile: Dockerfile
    ports:
      - "3000:3000"
    environment:
      - VITE_API_URL=http://localhost:8080/api/v1
    depends_on:
      - api

  # Spring Boot Modular Monolith Backend
  api:
    build:
      context: ./apps/api
      dockerfile: Dockerfile
    ports:
      - "8080:8080"
    environment:
      - SPRING_PROFILES_ACTIVE=prod
      - SPRING_DATASOURCE_URL=jdbc:postgresql://postgres:5432/certiverse
      - SPRING_DATASOURCE_USERNAME=certiverse_admin
      - SPRING_DATASOURCE_PASSWORD=certiverse_secure_password
      - SPRING_DATA_REDIS_HOST=redis
      - SPRING_DATA_REDIS_PORT=6379
      - AWS_S3_ENDPOINT=http://minio:9000
      - AWS_S3_BUCKET=certiverse-assets
    depends_on:
      postgres:
        condition: service_healthy
      redis:
        condition: service_started

  # PostgreSQL 15 Relational Database
  postgres:
    image: postgres:15-alpine
    environment:
      POSTGRES_DB: certiverse
      POSTGRES_USER: certiverse_admin
      POSTGRES_PASSWORD: certiverse_secure_password
    ports:
      - "5432:5432"
    volumes:
      - postgres_data:/var/lib/postgresql/data
    healthcheck:
      test: ["CMD-SHELL", "pg_isready -U certiverse_admin -d certiverse"]
      interval: 5s
      timeout: 5s
      retries: 5

  # Redis 7 Cache & BullMQ / Task Queue
  redis:
    image: redis:7-alpine
    ports:
      - "6379:6379"
    volumes:
      - redis_data:/data

  # S3 Compatible Object Storage (MinIO)
  minio:
    image: minio/minio:latest
    command: server /data --console-address ":9001"
    environment:
      MINIO_ROOT_USER: minio_admin
      MINIO_ROOT_PASSWORD: minio_secure_password
    ports:
      - "9000:9000"
      - "9001:9001"
    volumes:
      - minio_data:/data

volumes:
  postgres_data:
  redis_data:
  minio_data:`,
  },

  'README.md': {
    language: 'markdown',
    path: '/README.md',
    content: `# CertiVerse AI — Intelligent Global Certificate Creation Platform

> Enterprise-grade certificate creation, bulk issuance, AI design studio, and tamper-proof cryptographic verification platform with global compliance packs.

---

## 🏗️ Architecture Overview

CertiVerse AI is organized as a high-performance Monorepo:

\`\`\`
certiverse-ai/
├── apps/
│   ├── web/                    # React 19 + TypeScript + Vite + Tailwind CSS + Canvas Studio
│   └── api/                    # Java 21 + Spring Boot 3.3 Modular Monolith
│       ├── module-auth/        # JWT 15m/7d rotation, BCrypt-12, RBAC, 2FA TOTP
│       ├── module-orgs/        # Multi-tenant workspaces, procedural hash(orgId)->hue logos
│       ├── module-templates/   # 30+ categorized certificate blueprints & guilloche engine
│       ├── module-certificates/# 300 DPI CMYK PDF generation, SHA-256 hash & Ed25519 signing
│       ├── module-bulk/        # 100k row sharded CSV/XLSX pipeline with SSE streaming
│       ├── module-verify/      # Public GET /v/{token}, offline JWT verification, revocation registry
│       ├── module-ai/          # Google Gemini design generator, brand kit extractor, fraud shield
│       ├── module-assets/      # MinIO/S3 vector asset storage
│       ├── module-billing/     # Stripe + Razorpay multi-currency checkout
│       ├── module-audit/       # Immutable WORM (Write Once Read Many) cryptographic audit log
│       └── module-notification/# AWS SES & SendGrid email dispatch with deliverability tracking
├── docker-compose.yml          # Postgres 15, Redis 7, MinIO, Spring Boot API, React Web
└── .github/workflows/ci.yml    # Linting, integration tests, Docker build & Cloudflare deployment
\`\`\`

---

## 🚀 Quickstart

\`\`\`bash
# 1. Clone repository
git clone https://github.com/certiverse/certiverse-ai.git
cd certiverse-ai

# 2. Run infrastructure via Docker Compose
docker compose up -d

# 3. Access web application
open http://localhost:3000
# 4. Access backend Swagger / OpenAPI UI
open http://localhost:8080/swagger-ui.html
\`\`\`

---

## 🛡️ Cryptographic & Compliance Guarantees

1. **SHA-256 Digest**: Each certificate is mathematically hashed and anchored on public ledger (Polygon).
2. **Ed25519 Digital Signatures**: Issuing organizations hold distinct cryptographic keypairs.
3. **Pluggable Regulatory Packs**:
   - 🇮🇳 **India ABC / NSDC**: APAAR 12-digit registry, NSQF levels, DigiLocker XML schema.
   - 🇺🇸 **US CEU**: IACET ANSI/IACET 1-2018 continuing education units.
   - 🇪🇺 **EU Europass**: ECTS workload credit transfer & Bologna Process schema.
   - 🇬🇧 **UK CPD**: Structured CPD contact hours standard.
4. **WORM Immutable Audit**: Every issuance, key rotation, and role change is logged to a cryptographic append-only chain.`,
  },

  'VerifyController.java': {
    language: 'java',
    path: '/apps/api/src/main/java/ai/certiverse/verify/VerifyController.java',
    content: `package ai.certiverse.verify;

import ai.certiverse.certificates.CertificateRecord;
import ai.certiverse.certificates.CertificateService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.Map;

@RestController
@RequestMapping("/api/v1/verify")
@RequiredArgsConstructor
@Tag(name = "Verification", description = "Public cryptographic certificate verification endpoints")
public class VerifyController {

    private final CertificateService certificateService;
    private final CryptographicLedgerService ledgerService;

    @GetMapping("/{token}")
    @Operation(summary = "Verify certificate by cryptographic token or cert number")
    public ResponseEntity<VerificationResponse> verifyCertificate(@PathVariable String token) {
        CertificateRecord record = certificateService.findByTokenOrCertNo(token)
            .orElseThrow(() -> new CertificateNotFoundException("No credential found for token: " + token));

        // 1. Verify SHA-256 Digest
        boolean hashMatches = ledgerService.verifyDocumentHash(record);

        // 2. Verify Ed25519 Signature
        boolean signatureValid = ledgerService.verifySignature(record);

        // 3. Check Revocation Registry
        boolean isRevoked = record.getStatus() == CertificateStatus.REVOKED;

        VerificationResponse response = VerificationResponse.builder()
            .valid(hashMatches && signatureValid && !isRevoked)
            .certificateNumber(record.getCertNo())
            .recipientName(record.getRecipientName())
            .courseName(record.getCourse())
            .issuerOrganization(record.getIssuerOrgName())
            .issueDate(record.getIssueDate())
            .sha256Hash(record.getSha256Hash())
            .status(record.getStatus())
            .revocationReason(isRevoked ? record.getRevocationReason() : null)
            .blockchainTxHash(record.getBlockchainTxHash())
            .build();

        return ResponseEntity.ok(response);
    }
}`,
  },

  'CertificateService.java': {
    language: 'java',
    path: '/apps/api/src/main/java/ai/certiverse/certificates/CertificateService.java',
    content: `package ai.certiverse.certificates;

import ai.certiverse.audit.AuditService;
import ai.certiverse.crypto.Sha256Hasher;
import ai.certiverse.crypto.Ed25519Signer;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.Instant;
import java.util.UUID;

@Service
@RequiredArgsConstructor
@Slf4j
public class CertificateService {

    private final CertificateRepository certificateRepository;
    private final Sha256Hasher sha256Hasher;
    private final Ed25519Signer ed25519Signer;
    private final AuditService auditService;

    @Transactional
    public CertificateRecord issueCredential(IssueCredentialRequest request, String issuerOrgId) {
        String token = "tok_live_" + UUID.randomUUID().toString().replace("-", "");
        String certNo = "CV-" + request.getCategoryCode() + "-" + Instant.now().getEpochSecond();

        // 1. Compute SHA-256 cryptographic digest
        String documentHash = sha256Hasher.hash(request.getRecipientName(), request.getCourse(), certNo);

        // 2. Sign with organization private key
        byte[] digitalSignature = ed25519Signer.sign(documentHash, issuerOrgId);

        CertificateRecord entity = CertificateRecord.builder()
            .certNo(certNo)
            .token(token)
            .recipientName(request.getRecipientName())
            .recipientEmail(request.getRecipientEmail())
            .course(request.getCourse())
            .grade(request.getGrade())
            .issueDate(Instant.now())
            .issuerOrgId(issuerOrgId)
            .sha256Hash(documentHash)
            .digitalSignature(digitalSignature)
            .status(CertificateStatus.ACTIVE)
            .build();

        CertificateRecord saved = certificateRepository.save(entity);

        // Append to WORM immutable audit trail
        auditService.recordAppendOnly("CERTIFICATE_ISSUED", saved.getCertNo(), "Issued to " + saved.getRecipientName());

        return saved;
    }
}`,
  },

  'SecurityConfig.java': {
    language: 'java',
    path: '/apps/api/src/main/java/ai/certiverse/auth/SecurityConfig.java',
    content: `package ai.certiverse.auth;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.security.config.annotation.method.configuration.EnableMethodSecurity;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.http.SessionCreationPolicy;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.security.web.SecurityFilterChain;
import org.springframework.security.web.authentication.UsernamePasswordAuthenticationFilter;

@Configuration
@EnableMethodSecurity(prePostEnabled = true)
public class SecurityConfig {

    private final JwtAuthenticationFilter jwtFilter;

    public SecurityConfig(JwtAuthenticationFilter jwtFilter) {
        this.jwtFilter = jwtFilter;
    }

    @Bean
    public PasswordEncoder passwordEncoder() {
        return new BCryptPasswordEncoder(12); // BCrypt cost 12
    }

    @Bean
    public SecurityFilterChain securityFilterChain(HttpSecurity http) throws Exception {
        return http
            .csrf(csrf -> csrf.disable())
            .sessionManagement(sm -> sm.sessionCreationPolicy(SessionCreationPolicy.STATELESS))
            .authorizeHttpRequests(auth -> auth
                .requestMatchers("/api/v1/verify/**", "/swagger-ui/**", "/v3/api-docs/**").permitAll()
                .requestMatchers("/api/v1/auth/login", "/api/v1/auth/refresh", "/api/v1/auth/2fa").permitAll()
                .requestMatchers("/api/v1/admin/**").hasAnyRole("OWNER", "ADMIN")
                .requestMatchers("/api/v1/bulk/**").hasAnyRole("OWNER", "ADMIN", "ISSUER")
                .anyRequest().authenticated()
            )
            .addFilterBefore(jwtFilter, UsernamePasswordAuthenticationFilter.class)
            .build();
    }
}`,
  },
};

export const ArchitectureViewer: React.FC = () => {
  const [selectedFileKey, setSelectedFileKey] = useState<string>('docker-compose.yml');
  const [copied, setCopied] = useState(false);

  const file = MONOREPO_FILES[selectedFileKey];

  const handleCopy = () => {
    navigator.clipboard.writeText(file.content);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  return (
    <div className="min-h-[calc(100vh-64px)] bg-[#0B0F1E] text-slate-100 p-6 md:p-8 space-y-8">
      {/* Header Banner */}
      <div className="flex flex-col md:flex-row md:items-end justify-between gap-4 border-b border-slate-800 pb-6">
        <div>
          <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-indigo-500/10 border border-indigo-500/20 text-indigo-400 text-xs font-semibold mb-3">
            <Cpu className="w-3.5 h-3.5 text-cyan-400" />
            Monorepo Architecture & Backend Modular Monolith
          </div>
          <h1 className="text-3xl md:text-4xl font-sora font-extrabold tracking-tight text-white">
            Architecture & <span className="text-cyan-400">Code Explorer</span>
          </h1>
          <p className="text-slate-400 text-sm mt-1 max-w-2xl">
            Inspect the full Monorepo file tree: React web frontend, Java Spring Boot modular
            monolith backend modules, PostgreSQL 15 schemas, and Docker Compose orchestration.
          </p>
        </div>
      </div>

      {/* Explorer Grid */}
      <div className="grid grid-cols-1 lg:grid-cols-4 gap-6">
        {/* Left 1 Col: File Tree */}
        <div className="bg-slate-900/90 rounded-2xl border border-slate-800 p-4 space-y-3">
          <div className="text-xs font-bold uppercase tracking-wider text-slate-400 px-2 pb-2 border-b border-slate-800 flex items-center justify-between">
            <span>Repository Tree</span>
            <GitBranch className="w-3.5 h-3.5 text-cyan-400" />
          </div>

          <div className="space-y-1 text-xs">
            {Object.keys(MONOREPO_FILES).map((key) => {
              const isSelected = selectedFileKey === key;
              return (
                <button
                  key={key}
                  onClick={() => setSelectedFileKey(key)}
                  className={`w-full text-left px-3 py-2 rounded-xl transition flex items-center gap-2 ${
                    isSelected
                      ? 'bg-indigo-600/30 border border-cyan-400/60 text-white font-semibold'
                      : 'text-slate-400 hover:bg-slate-800/60 hover:text-slate-200'
                  }`}
                >
                  <FileCode className="w-4 h-4 text-cyan-400 shrink-0" />
                  <span className="truncate font-mono text-[11px]">{key}</span>
                </button>
              );
            })}
          </div>

          {/* Infrastructure Spec Checklist */}
          <div className="pt-4 border-t border-slate-800/80 space-y-2 text-[11px] text-slate-400">
            <span className="font-bold text-slate-300 block">Stack Specifications:</span>
            <div className="flex items-center gap-2 text-slate-300">
              <Server className="w-3.5 h-3.5 text-emerald-400" />
              <span>Java 21 • Spring Boot 3.3 Monolith</span>
            </div>
            <div className="flex items-center gap-2 text-slate-300">
              <Database className="w-3.5 h-3.5 text-cyan-400" />
              <span>PostgreSQL 15 & Redis 7 Cache</span>
            </div>
            <div className="flex items-center gap-2 text-slate-300">
              <Layers className="w-3.5 h-3.5 text-amber-400" />
              <span>MinIO S3 Compatible Storage</span>
            </div>
            <div className="flex items-center gap-2 text-slate-300">
              <Terminal className="w-3.5 h-3.5 text-indigo-400" />
              <span>Docker Compose & GitHub CI</span>
            </div>
          </div>
        </div>

        {/* Right 3 Cols: Code Viewer */}
        <div className="lg:col-span-3 bg-slate-900/90 rounded-2xl border border-slate-800 p-5 flex flex-col space-y-3">
          <div className="flex items-center justify-between pb-3 border-b border-slate-800">
            <div className="flex items-center gap-2">
              <span className="text-xs font-mono font-bold text-cyan-400">{file.path}</span>
              <span className="text-[10px] font-mono px-2 py-0.5 rounded bg-slate-800 text-slate-400 uppercase">
                {file.language}
              </span>
            </div>
            <button
              onClick={handleCopy}
              className="px-3 py-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs font-semibold flex items-center gap-1.5 border border-slate-700 transition"
            >
              {copied ? <Check className="w-3.5 h-3.5 text-green-400" /> : <Copy className="w-3.5 h-3.5" />}
              <span>{copied ? 'Copied' : 'Copy Source'}</span>
            </button>
          </div>

          <div className="flex-1 bg-slate-950 p-4 rounded-xl border border-slate-800/80 font-mono text-[12px] text-slate-200 overflow-auto max-h-[600px] leading-relaxed scrollbar-thin scrollbar-thumb-slate-800">
            <pre>{file.content}</pre>
          </div>
        </div>
      </div>
    </div>
  );
};
