import React, { useState } from 'react';
import { useCert } from '../../context/CertContext';
import { CertificateTemplate, CertificateCategory } from '../../types';
import { CATEGORIES_LIST } from '../../data/templates';
import { CertificateRenderer } from '../editor/CertificateRenderer';
import {
  Search,
  SlidersHorizontal,
  Sparkles,
  ExternalLink,
  Copy,
  Check,
  Award,
  Layers,
  ChevronRight,
  Eye,
} from 'lucide-react';

export const TemplateGallery: React.FC = () => {
  const { templates, setSelectedTemplate, setActiveTab, cloneTemplate } = useCert();

  const [searchQuery, setSearchQuery] = useState('');
  const [selectedCategory, setSelectedCategory] = useState<string>('All');
  const [selectedOrientation, setSelectedOrientation] = useState<string>('All');
  const [selectedPaper, setSelectedPaper] = useState<string>('All');
  const [previewTemplate, setPreviewTemplate] = useState<CertificateTemplate | null>(null);

  const filteredTemplates = templates.filter((tmpl) => {
    const matchesSearch =
      tmpl.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
      tmpl.description.toLowerCase().includes(searchQuery.toLowerCase()) ||
      tmpl.category.toLowerCase().includes(searchQuery.toLowerCase()) ||
      (tmpl.complianceTag && tmpl.complianceTag.toLowerCase().includes(searchQuery.toLowerCase()));

    const matchesCategory = selectedCategory === 'All' || tmpl.category === selectedCategory;
    const matchesOrientation = selectedOrientation === 'All' || tmpl.orientation === selectedOrientation.toLowerCase();
    const matchesPaper = selectedPaper === 'All' || tmpl.paper === selectedPaper;

    return matchesSearch && matchesCategory && matchesOrientation && matchesPaper;
  });

  const handleSelectAndEdit = (tmpl: CertificateTemplate) => {
    setSelectedTemplate(tmpl);
    setActiveTab('editor');
  };

  const handleCloneAndEdit = (tmpl: CertificateTemplate) => {
    const cloned = cloneTemplate(tmpl);
    setSelectedTemplate(cloned);
    setActiveTab('editor');
  };

  return (
    <div className="min-h-[calc(100vh-64px)] bg-[#0B0F1E] text-slate-100 p-6 md:p-8 space-y-8">
      {/* Header Banner */}
      <div className="flex flex-col md:flex-row md:items-end justify-between gap-4 border-b border-slate-800 pb-6">
        <div>
          <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-indigo-500/10 border border-indigo-500/20 text-indigo-400 text-xs font-semibold mb-3">
            <Sparkles className="w-3.5 h-3.5 text-cyan-400" />
            30+ Global Accredited Frameworks
          </div>
          <h1 className="text-3xl md:text-4xl font-sora font-extrabold tracking-tight text-white">
            Template <span className="text-cyan-400">Gallery</span>
          </h1>
          <p className="text-slate-400 text-sm mt-1 max-w-2xl">
            Explore industry-standard certificate blueprints with pre-built cryptographic layouts,
            guilloche borders, micro-text security, and international regulatory compliance.
          </p>
        </div>

        {/* Search input */}
        <div className="relative w-full md:w-80">
          <Search className="w-4 h-4 text-slate-400 absolute left-3.5 top-1/2 -translate-y-1/2 pointer-events-none" />
          <input
            type="text"
            placeholder="Search templates, standards, topics..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="w-full bg-slate-900 border border-slate-700/80 rounded-xl pl-10 pr-4 py-2 text-sm text-slate-100 placeholder:text-slate-500 focus:outline-none focus:border-cyan-400 transition"
          />
        </div>
      </div>

      {/* Filter Toolbar */}
      <div className="space-y-3">
        {/* Category Pills Slider */}
        <div className="flex items-center gap-2 overflow-x-auto pb-2 scrollbar-thin scrollbar-thumb-slate-800">
          <button
            onClick={() => setSelectedCategory('All')}
            className={`px-3.5 py-1.5 rounded-full text-xs font-semibold whitespace-nowrap transition ${
              selectedCategory === 'All'
                ? 'bg-gradient-to-r from-indigo-600 to-cyan-600 text-white shadow-md'
                : 'bg-slate-900 text-slate-400 hover:text-slate-200 border border-slate-800'
            }`}
          >
            All Categories ({templates.length})
          </button>
          {CATEGORIES_LIST.map((cat) => {
            const count = templates.filter((t) => t.category === cat).length;
            return (
              <button
                key={cat}
                onClick={() => setSelectedCategory(cat)}
                className={`px-3 py-1.5 rounded-full text-xs font-medium whitespace-nowrap transition flex items-center gap-1.5 ${
                  selectedCategory === cat
                    ? 'bg-indigo-600 text-white shadow-md'
                    : 'bg-slate-900 text-slate-400 hover:text-slate-200 border border-slate-800'
                }`}
              >
                <span>{cat}</span>
                <span className="text-[10px] opacity-70 bg-black/30 px-1.5 py-0.2 rounded-full">
                  {count}
                </span>
              </button>
            );
          })}
        </div>

        {/* Secondary filters: Orientation & Paper */}
        <div className="flex flex-wrap items-center justify-between gap-4 pt-2 text-xs text-slate-400">
          <div className="flex items-center gap-3">
            <span className="font-semibold text-slate-300">Orientation:</span>
            {['All', 'Landscape', 'Portrait'].map((or) => (
              <button
                key={or}
                onClick={() => setSelectedOrientation(or)}
                className={`px-2.5 py-1 rounded-md border transition ${
                  selectedOrientation === or
                    ? 'bg-slate-800 border-cyan-500/60 text-cyan-400 font-semibold'
                    : 'border-slate-800 text-slate-400 hover:text-slate-200'
                }`}
              >
                {or}
              </button>
            ))}

            <span className="font-semibold text-slate-300 ml-3">Paper:</span>
            {['All', 'A4', 'Letter'].map((pap) => (
              <button
                key={pap}
                onClick={() => setSelectedPaper(pap)}
                className={`px-2.5 py-1 rounded-md border transition ${
                  selectedPaper === pap
                    ? 'bg-slate-800 border-cyan-500/60 text-cyan-400 font-semibold'
                    : 'border-slate-800 text-slate-400 hover:text-slate-200'
                }`}
              >
                {pap}
              </button>
            ))}
          </div>

          <div>
            Showing <span className="font-bold text-white">{filteredTemplates.length}</span> templates
          </div>
        </div>
      </div>

      {/* Templates Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {filteredTemplates.map((tmpl) => (
          <div
            key={tmpl.id}
            className="group bg-slate-900/80 rounded-2xl border border-slate-800 hover:border-cyan-500/50 transition-all duration-300 overflow-hidden flex flex-col hover:shadow-2xl hover:shadow-cyan-500/10"
          >
            {/* Visual Thumbnail Frame */}
            <div
              className={`h-48 relative bg-gradient-to-br ${tmpl.thumbnailGradient} p-4 flex flex-col justify-between overflow-hidden`}
            >
              <div className="flex items-center justify-between z-10">
                <span className="text-[10px] uppercase font-bold tracking-wider px-2 py-0.5 rounded bg-black/40 backdrop-blur-md text-cyan-300 border border-white/10">
                  {tmpl.category}
                </span>
                {tmpl.complianceTag && (
                  <span className="text-[10px] font-bold px-2 py-0.5 rounded bg-amber-500/20 text-amber-300 border border-amber-500/30">
                    {tmpl.complianceTag}
                  </span>
                )}
              </div>

              {/* Decorative mini certificate mockup */}
              <div className="my-auto mx-auto w-4/5 h-24 bg-black/40 rounded-lg border border-white/20 p-2 flex flex-col items-center justify-center text-center backdrop-blur-sm shadow-inner group-hover:scale-105 transition-transform duration-300">
                <div className="w-8 h-1 bg-cyan-400/80 rounded mb-1.5" />
                <h4 className="text-[11px] font-playfair font-bold text-white truncate max-w-[200px]">
                  {tmpl.title}
                </h4>
                <div className="text-[9px] text-slate-400 font-inter mt-1 truncate max-w-[180px]">
                  {tmpl.description}
                </div>
              </div>

              {/* Bottom metadata tag */}
              <div className="flex items-center justify-between text-[10px] text-slate-300 z-10">
                <span>
                  {tmpl.orientation.toUpperCase()} • {tmpl.paper}
                </span>
                <span>{tmpl.elements.length} dynamic elements</span>
              </div>
            </div>

            {/* Content Details */}
            <div className="p-5 flex-1 flex flex-col justify-between space-y-4">
              <div>
                <h3 className="font-sora font-bold text-base text-white group-hover:text-cyan-400 transition-colors">
                  {tmpl.title}
                </h3>
                <p className="text-slate-400 text-xs mt-1 leading-relaxed line-clamp-2">
                  {tmpl.description}
                </p>
              </div>

              <div className="pt-2 border-t border-slate-800/80 flex items-center justify-between gap-2">
                <button
                  onClick={() => setPreviewTemplate(tmpl)}
                  className="px-3 py-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-300 hover:text-white text-xs font-semibold flex items-center gap-1.5 transition"
                >
                  <Eye className="w-3.5 h-3.5 text-cyan-400" />
                  Preview
                </button>
                <div className="flex items-center gap-2">
                  <button
                    onClick={() => handleCloneAndEdit(tmpl)}
                    title="Clone to new template"
                    className="p-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-400 hover:text-white transition"
                  >
                    <Copy className="w-4 h-4" />
                  </button>
                  <button
                    onClick={() => handleSelectAndEdit(tmpl)}
                    className="px-3.5 py-1.5 rounded-lg bg-indigo-600 hover:bg-indigo-500 text-white text-xs font-bold flex items-center gap-1 transition shadow"
                  >
                    <span>Customize</span>
                    <ChevronRight className="w-3.5 h-3.5" />
                  </button>
                </div>
              </div>
            </div>
          </div>
        ))}
      </div>

      {/* Fullscreen Preview Modal */}
      {previewTemplate && (
        <div className="fixed inset-0 bg-slate-950/85 backdrop-blur-md flex items-center justify-center p-4 z-50 animate-in fade-in">
          <div className="w-full max-w-4xl bg-slate-900 border border-slate-800 rounded-2xl p-6 shadow-2xl flex flex-col max-h-[90vh] overflow-hidden">
            {/* Modal Header */}
            <div className="flex items-center justify-between pb-4 border-b border-slate-800 shrink-0">
              <div>
                <h3 className="font-sora font-bold text-lg text-white">
                  {previewTemplate.title}
                </h3>
                <span className="text-xs text-slate-400">
                  {previewTemplate.category} • {previewTemplate.orientation} • {previewTemplate.paper}
                </span>
              </div>
              <button
                onClick={() => setPreviewTemplate(null)}
                className="text-slate-400 hover:text-white text-lg font-bold"
              >
                ✕
              </button>
            </div>

            {/* Preview Canvas */}
            <div className="flex-1 bg-[#060810] my-4 rounded-xl p-4 overflow-auto flex items-center justify-center">
              <div className="transform scale-[0.65] origin-center">
                <CertificateRenderer
                  elements={previewTemplate.elements}
                  width={previewTemplate.width}
                  height={previewTemplate.height}
                  bgTheme={previewTemplate.bgTheme}
                  isPrintOrExport={true}
                />
              </div>
            </div>

            {/* Modal Footer */}
            <div className="flex items-center justify-between pt-4 border-t border-slate-800 shrink-0">
              <span className="text-xs text-slate-400">
                Ready for high-res 300 DPI PDF generation & cryptographic QR issuance.
              </span>
              <div className="flex items-center gap-3">
                <button
                  onClick={() => setPreviewTemplate(null)}
                  className="px-4 py-2 rounded-lg bg-slate-800 hover:bg-slate-700 text-xs font-semibold text-slate-300"
                >
                  Close
                </button>
                <button
                  onClick={() => {
                    handleSelectAndEdit(previewTemplate);
                    setPreviewTemplate(null);
                  }}
                  className="px-5 py-2 rounded-lg bg-gradient-to-r from-indigo-600 to-cyan-600 hover:from-indigo-500 hover:to-cyan-500 text-white text-xs font-bold shadow-lg shadow-indigo-600/30"
                >
                  Open in Visual Editor
                </button>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
