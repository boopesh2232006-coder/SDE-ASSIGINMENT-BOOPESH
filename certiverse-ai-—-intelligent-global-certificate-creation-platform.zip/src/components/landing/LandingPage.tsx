import React, { useState } from 'react';
import { useCert } from '../../context/CertContext';
import { BrandLogo } from '../BrandLogo';
import {
  Sparkles,
  ShieldCheck,
  Award,
  Layers,
  ArrowRight,
  CheckCircle2,
  Lock,
  Globe,
  FileDown,
  Printer,
  Search,
  ExternalLink,
  ChevronRight,
  Database,
  Users,
} from 'lucide-react';

export const LandingPage: React.FC = () => {
  const { setActiveTab, setPublicVerifyToken, getCertificateByTokenOrId } = useCert();

  const [verifyInput, setVerifyInput] = useState('');
  const [currency, setCurrency] = useState<'USD' | 'INR'>('USD');

  const handleHeroVerify = (e: React.FormEvent) => {
    e.preventDefault();
    if (!verifyInput) return;
    setPublicVerifyToken(verifyInput);
    setActiveTab('verify');
  };

  return (
    <div className="min-h-screen bg-[#0B0F1E] text-slate-100 flex flex-col">
      {/* Hero Section */}
      <section className="relative overflow-hidden pt-12 pb-20 md:pt-20 md:pb-32 px-4 sm:px-6 lg:px-8 border-b border-slate-800/80 guilloche-pattern">
        {/* Glow ambient background effects */}
        <div className="absolute top-1/4 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[650px] h-[350px] bg-gradient-to-tr from-indigo-600/20 via-cyan-500/15 to-transparent blur-[120px] pointer-events-none rounded-full" />

        <div className="max-w-7xl mx-auto flex flex-col lg:flex-row items-center gap-12 relative z-10">
          {/* Left Column: Headlines & Action buttons */}
          <div className="flex-1 text-center lg:text-left space-y-6">
            <div className="inline-flex items-center gap-2 px-3.5 py-1.5 rounded-full bg-indigo-500/10 border border-indigo-500/20 text-indigo-400 text-xs font-semibold backdrop-blur-md">
              <Sparkles className="w-4 h-4 text-cyan-400 animate-pulse" />
              <span>Next-Gen Global Certificate Infrastructure</span>
            </div>

            <h1 className="text-4xl sm:text-5xl lg:text-6xl font-sora font-extrabold tracking-tight text-white leading-[1.15]">
              Intelligent Global{' '}
              <span className="bg-gradient-to-r from-indigo-400 via-cyan-400 to-amber-300 bg-clip-text text-transparent">
                Certificate Platform
              </span>
            </h1>

            <p className="text-base sm:text-lg text-slate-300 max-w-2xl mx-auto lg:mx-0 leading-relaxed">
              Design, issue, and verify fraud-proof certificates at enterprise scale. Built with
              300 DPI print bleed, signed QR tokens, AI design studio, 100k sharded bulk issuance,
              and pluggable country compliance packs.
            </p>

            {/* CTAs */}
            <div className="flex flex-wrap items-center justify-center lg:justify-start gap-4 pt-2">
              <button
                onClick={() => setActiveTab('create_cert')}
                className="px-6 py-3.5 rounded-xl bg-gradient-to-r from-indigo-600 via-indigo-500 to-cyan-500 hover:from-indigo-500 hover:to-cyan-400 text-white font-bold text-sm shadow-xl shadow-indigo-600/30 flex items-center gap-2 transition active:scale-95"
              >
                <span>Create Certificate</span>
                <ArrowRight className="w-4 h-4" />
              </button>

              <button
                onClick={() => setActiveTab('editor')}
                className="px-6 py-3.5 rounded-xl bg-slate-900/90 hover:bg-slate-800 text-slate-200 text-sm font-semibold border border-slate-700/80 flex items-center gap-2 transition"
              >
                <span>Canvas Studio</span>
              </button>

              <button
                onClick={() => setActiveTab('gallery')}
                className="px-4 py-3.5 rounded-xl text-slate-400 hover:text-cyan-400 text-sm font-semibold flex items-center gap-1 transition"
              >
                <span>Browse 30+ Templates</span>
              </button>
            </div>

            {/* Quick Hero Verification Box */}
            <div className="pt-4 max-w-md mx-auto lg:mx-0">
              <form onSubmit={handleHeroVerify} className="relative flex items-center">
                <Search className="w-4 h-4 text-slate-400 absolute left-3.5 pointer-events-none" />
                <input
                  type="text"
                  placeholder="Verify token or ID (e.g. CV-AI-2026-884920)"
                  value={verifyInput}
                  onChange={(e) => setVerifyInput(e.target.value)}
                  className="w-full bg-slate-950/80 border border-slate-700 rounded-xl pl-10 pr-24 py-2.5 text-xs text-slate-100 placeholder:text-slate-500 focus:outline-none focus:border-cyan-400"
                />
                <button
                  type="submit"
                  className="absolute right-1 px-3 py-1.5 rounded-lg bg-cyan-600 hover:bg-cyan-500 text-white text-[11px] font-bold"
                >
                  Verify Now
                </button>
              </form>
            </div>

            {/* Regulatory trust badges */}
            <div className="flex flex-wrap items-center justify-center lg:justify-start gap-4 pt-4 text-[11px] text-slate-400">
              <div className="flex items-center gap-1.5">
                <CheckCircle2 className="w-3.5 h-3.5 text-cyan-400" />
                <span>300 DPI CMYK Print</span>
              </div>
              <div className="flex items-center gap-1.5">
                <CheckCircle2 className="w-3.5 h-3.5 text-cyan-400" />
                <span>Ed25519 & SHA-256 Ledger</span>
              </div>
              <div className="flex items-center gap-1.5">
                <CheckCircle2 className="w-3.5 h-3.5 text-cyan-400" />
                <span>India ABC / US CEU / EU ECTS</span>
              </div>
            </div>
          </div>

          {/* Right Column: Visual Interactive Certificate Showcase Card */}
          <div className="flex-1 w-full max-w-lg lg:max-w-none flex justify-center">
            <div className="relative group w-full max-w-lg rounded-2xl bg-gradient-to-br from-indigo-500/20 via-cyan-500/10 to-amber-500/10 p-1 shadow-2xl cyan-indigo-glow transition-transform duration-500 hover:scale-[1.01]">
              <div className="rounded-2xl bg-[#090D1A] border border-slate-700/80 p-6 space-y-5 overflow-hidden relative">
                {/* Certificate preview header */}
                <div className="flex items-center justify-between pb-3 border-b border-slate-800">
                  <div className="flex items-center gap-2">
                    <span className="w-2.5 h-2.5 rounded-full bg-emerald-400 animate-pulse" />
                    <span className="text-xs font-mono font-bold text-slate-300">
                      LIVE VERIFIED CREDENTIAL
                    </span>
                  </div>
                  <span className="text-[10px] font-mono text-cyan-400 bg-cyan-500/10 px-2 py-0.5 rounded border border-cyan-500/20">
                    CV-AI-2026-884920
                  </span>
                </div>

                {/* Decorative inner parchment */}
                <div className="p-6 rounded-xl bg-gradient-to-br from-[#0B0F1E] to-[#1E1B4B] border-2 border-cyan-500/40 relative text-center space-y-3">
                  <span className="text-[10px] font-bold uppercase tracking-widest text-cyan-400 block">
                    GLOBAL TECH & ARTIFICIAL INTELLIGENCE ACADEMY
                  </span>
                  <h3 className="font-playfair text-2xl font-bold text-white">
                    Certificate of Excellence
                  </h3>
                  <div className="text-[11px] text-slate-400">Awarded to</div>
                  <div className="font-cinzel text-xl font-bold text-amber-400">
                    Alexander Vance, M.Sc.
                  </div>
                  <p className="text-[11px] text-slate-300 max-w-xs mx-auto">
                    for demonstrated mastery in Large Language Models & Agentic Architecture
                  </p>

                  <div className="pt-2 flex items-center justify-between text-[10px] text-slate-400 border-t border-slate-800">
                    <span className="font-signature text-xl text-cyan-300">Evelyn Zhang</span>
                    <div className="w-10 h-10 rounded-full gold-foil-seal flex items-center justify-center text-slate-950 font-bold text-[8px] shadow">
                      SEAL
                    </div>
                    <span className="font-mono text-slate-400">Oct 9, 2026</span>
                  </div>
                </div>

                {/* Interactive buttons */}
                <div className="flex items-center justify-between pt-1 text-xs">
                  <span className="text-slate-400 font-mono text-[11px]">
                    SHA-256: e3b0c44...855
                  </span>
                  <button
                    onClick={() => {
                      setPublicVerifyToken('tok_live_7e8b91fa023a4b9c8d11');
                      setActiveTab('verify');
                    }}
                    className="text-cyan-400 hover:text-cyan-300 font-bold flex items-center gap-1"
                  >
                    <span>Inspect Proof</span>
                    <ChevronRight className="w-4 h-4" />
                  </button>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Feature Pillars Section */}
      <section className="py-20 px-4 sm:px-6 lg:px-8 max-w-7xl mx-auto space-y-12">
        <div className="text-center space-y-3 max-w-3xl mx-auto">
          <h2 className="text-3xl font-sora font-extrabold text-white">
            Built for Global Universities, Bootcamps & Enterprises
          </h2>
          <p className="text-slate-400 text-sm">
            Everything needed to manage institutional credentialing from zero-to-one, backed by
            cryptographic immutability.
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {/* Card 1 */}
          <div className="p-6 rounded-2xl bg-slate-900/70 border border-slate-800 hover:border-cyan-500/50 transition-all space-y-4">
            <div className="w-12 h-12 rounded-xl bg-indigo-500/10 border border-indigo-500/20 text-indigo-400 flex items-center justify-center">
              <Award className="w-6 h-6 text-cyan-400" />
            </div>
            <h3 className="font-sora font-bold text-lg text-white">
              Interactive Visual Studio
            </h3>
            <p className="text-xs text-slate-400 leading-relaxed">
              Drag-and-drop canvas with 3mm bleed margin guides, snap alignment, z-index layers,
              undo/redo history, dynamic tokens, gold foil seals, and cursive e-signatures.
            </p>
          </div>

          {/* Card 2 */}
          <div className="p-6 rounded-2xl bg-slate-900/70 border border-slate-800 hover:border-cyan-500/50 transition-all space-y-4">
            <div className="w-12 h-12 rounded-xl bg-cyan-500/10 border border-cyan-500/20 text-cyan-400 flex items-center justify-center">
              <ShieldCheck className="w-6 h-6 text-emerald-400" />
            </div>
            <h3 className="font-sora font-bold text-lg text-white">
              Zero-Trust Verification
            </h3>
            <p className="text-xs text-slate-400 leading-relaxed">
              Public /v/:token verification portal with Ed25519 signature checks, SHA-256 document
              matching, Polygon blockchain anchors, revocation checks, and 1-click &quot;Add to LinkedIn&quot;.
            </p>
          </div>

          {/* Card 3 */}
          <div className="p-6 rounded-2xl bg-slate-900/70 border border-slate-800 hover:border-cyan-500/50 transition-all space-y-4">
            <div className="w-12 h-12 rounded-xl bg-amber-500/10 border border-amber-500/20 text-amber-400 flex items-center justify-center">
              <Layers className="w-6 h-6 text-yellow-400" />
            </div>
            <h3 className="font-sora font-bold text-lg text-white">
              100k Bulk Sharded Issuance
            </h3>
            <p className="text-xs text-slate-400 leading-relaxed">
              Import CSV/XLSX spreadsheets, map dynamic variables, and process up to 100k
              certificates with parallel SSE telemetry, ZIP downloads, and AWS SES dispatch.
            </p>
          </div>

          {/* Card 4 */}
          <div className="p-6 rounded-2xl bg-slate-900/70 border border-slate-800 hover:border-cyan-500/50 transition-all space-y-4">
            <div className="w-12 h-12 rounded-xl bg-purple-500/10 border border-purple-500/20 text-purple-400 flex items-center justify-center">
              <Sparkles className="w-6 h-6 text-purple-400" />
            </div>
            <h3 className="font-sora font-bold text-lg text-white">
              AI Studio & Fraud Shield
            </h3>
            <p className="text-xs text-slate-400 leading-relaxed">
              Prompt-to-design generator, institutional brand-kit extractor, legal content
              validator, and multilingual translation supporting 20+ languages with full RTL.
            </p>
          </div>

          {/* Card 5 */}
          <div className="p-6 rounded-2xl bg-slate-900/70 border border-slate-800 hover:border-cyan-500/50 transition-all space-y-4">
            <div className="w-12 h-12 rounded-xl bg-emerald-500/10 border border-emerald-500/20 text-emerald-400 flex items-center justify-center">
              <Globe className="w-6 h-6 text-emerald-400" />
            </div>
            <h3 className="font-sora font-bold text-lg text-white">
              Pluggable Country Packs
            </h3>
            <p className="text-xs text-slate-400 leading-relaxed">
              Pre-configured schemas for India ABC & Skill India (APAAR), United States CEU (IACET),
              European Union Europass (ECTS), and UK CPD Standards.
            </p>
          </div>

          {/* Card 6 */}
          <div className="p-6 rounded-2xl bg-slate-900/70 border border-slate-800 hover:border-cyan-500/50 transition-all space-y-4">
            <div className="w-12 h-12 rounded-xl bg-rose-500/10 border border-rose-500/20 text-rose-400 flex items-center justify-center">
              <Lock className="w-6 h-6 text-rose-400" />
            </div>
            <h3 className="font-sora font-bold text-lg text-white">
              RBAC & Immutable WORM Audit
            </h3>
            <p className="text-xs text-slate-400 leading-relaxed">
              Granular roles (OWNER, ADMIN, DESIGNER, ISSUER, VIEWER), TOTP 2FA, procedural SVG
              workspace logos via hash(orgId)-&gt;hue, and write-once-read-many cryptographic logs.
            </p>
          </div>
        </div>
      </section>

      {/* Pricing & Subscription Section */}
      <section className="py-16 px-4 sm:px-6 lg:px-8 max-w-7xl mx-auto space-y-10 border-t border-slate-800/80">
        <div className="text-center space-y-3">
          <h2 className="text-3xl font-sora font-extrabold text-white">
            Transparent Global Pricing
          </h2>
          <p className="text-slate-400 text-sm">
            Dual Stripe & Razorpay support for international institutions and India university networks.
          </p>

          <div className="flex items-center justify-center gap-2 pt-2">
            <button
              onClick={() => setCurrency('USD')}
              className={`px-3 py-1 rounded-lg text-xs font-bold transition ${
                currency === 'USD'
                  ? 'bg-cyan-500 text-slate-950'
                  : 'bg-slate-800 text-slate-400'
              }`}
            >
              $ USD (Stripe)
            </button>
            <button
              onClick={() => setCurrency('INR')}
              className={`px-3 py-1 rounded-lg text-xs font-bold transition ${
                currency === 'INR'
                  ? 'bg-amber-500 text-slate-950'
                  : 'bg-slate-800 text-slate-400'
              }`}
            >
              ₹ INR (Razorpay)
            </button>
          </div>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          {/* Starter */}
          <div className="p-6 rounded-2xl bg-slate-900 border border-slate-800 space-y-5 flex flex-col justify-between">
            <div className="space-y-3">
              <h3 className="font-bold text-lg text-white">Starter Academy</h3>
              <div className="text-3xl font-sora font-extrabold text-white">
                {currency === 'USD' ? '$49' : '₹3,999'}
                <span className="text-xs text-slate-400 font-normal"> / month</span>
              </div>
              <p className="text-xs text-slate-400">
                Ideal for growing training centers, bootcamps, and certification programs.
              </p>
              <ul className="space-y-2 text-xs text-slate-300 pt-3 border-t border-slate-800">
                <li className="flex items-center gap-2">
                  <CheckCircle2 className="w-3.5 h-3.5 text-cyan-400" />
                  <span>Up to 1,000 Verified Certs/month</span>
                </li>
                <li className="flex items-center gap-2">
                  <CheckCircle2 className="w-3.5 h-3.5 text-cyan-400" />
                  <span>300 DPI High-Res PDF Export</span>
                </li>
                <li className="flex items-center gap-2">
                  <CheckCircle2 className="w-3.5 h-3.5 text-cyan-400" />
                  <span>Public QR Verification Portal</span>
                </li>
              </ul>
            </div>
            <button
              onClick={() => setActiveTab('editor')}
              className="w-full py-2.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs font-semibold"
            >
              Start Free Trial
            </button>
          </div>

          {/* Professional */}
          <div className="p-6 rounded-2xl bg-gradient-to-b from-indigo-950/60 to-slate-900 border-2 border-cyan-500/80 space-y-5 flex flex-col justify-between shadow-2xl relative">
            <div className="absolute -top-3 left-1/2 -translate-x-1/2 px-3 py-0.5 rounded-full bg-cyan-400 text-slate-950 font-bold text-[10px] uppercase tracking-wider">
              Most Popular
            </div>
            <div className="space-y-3">
              <h3 className="font-bold text-lg text-white">Professional Scale</h3>
              <div className="text-3xl font-sora font-extrabold text-white">
                {currency === 'USD' ? '$199' : '₹15,999'}
                <span className="text-xs text-slate-400 font-normal"> / month</span>
              </div>
              <p className="text-xs text-slate-400">
                For universities, medical accreditation boards, and enterprise corporate L&D.
              </p>
              <ul className="space-y-2 text-xs text-slate-300 pt-3 border-t border-slate-800">
                <li className="flex items-center gap-2">
                  <CheckCircle2 className="w-3.5 h-3.5 text-cyan-400" />
                  <span>Up to 25,000 Verified Certs/month</span>
                </li>
                <li className="flex items-center gap-2">
                  <CheckCircle2 className="w-3.5 h-3.5 text-cyan-400" />
                  <span>All Country Compliance Packs (India/US/EU)</span>
                </li>
                <li className="flex items-center gap-2">
                  <CheckCircle2 className="w-3.5 h-3.5 text-cyan-400" />
                  <span>AI Studio & Brand-Kit Generator</span>
                </li>
                <li className="flex items-center gap-2">
                  <CheckCircle2 className="w-3.5 h-3.5 text-cyan-400" />
                  <span>Polygon Blockchain Anchoring</span>
                </li>
              </ul>
            </div>
            <button
              onClick={() => setActiveTab('editor')}
              className="w-full py-2.5 rounded-xl bg-gradient-to-r from-indigo-600 to-cyan-600 text-white text-xs font-bold shadow-lg"
            >
              Get Started Now
            </button>
          </div>

          {/* Enterprise */}
          <div className="p-6 rounded-2xl bg-slate-900 border border-slate-800 space-y-5 flex flex-col justify-between">
            <div className="space-y-3">
              <h3 className="font-bold text-lg text-white">Enterprise White-Label</h3>
              <div className="text-3xl font-sora font-extrabold text-white">
                Custom
              </div>
              <p className="text-xs text-slate-400">
                Dedicated infrastructure, custom root SSL domains, and unlimited 100k bulk runs.
              </p>
              <ul className="space-y-2 text-xs text-slate-300 pt-3 border-t border-slate-800">
                <li className="flex items-center gap-2">
                  <CheckCircle2 className="w-3.5 h-3.5 text-cyan-400" />
                  <span>Unlimited Sharded Issuance</span>
                </li>
                <li className="flex items-center gap-2">
                  <CheckCircle2 className="w-3.5 h-3.5 text-cyan-400" />
                  <span>Full White-Label & Custom Domain</span>
                </li>
                <li className="flex items-center gap-2">
                  <CheckCircle2 className="w-3.5 h-3.5 text-cyan-400" />
                  <span>Immutable WORM Audit Chaining</span>
                </li>
                <li className="flex items-center gap-2">
                  <CheckCircle2 className="w-3.5 h-3.5 text-cyan-400" />
                  <span>99.99% SLA & Dedicated Account Lead</span>
                </li>
              </ul>
            </div>
            <button
              onClick={() => setActiveTab('editor')}
              className="w-full py-2.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs font-semibold"
            >
              Contact Sales
            </button>
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="mt-auto border-t border-slate-800/80 py-8 px-4 text-center text-xs text-slate-500">
        <div className="max-w-7xl mx-auto flex flex-col md:flex-row items-center justify-between gap-4">
          <BrandLogo size={28} showSubtitle={false} />
          <div>
            CertiVerse AI Platform • ISO 27001 • IACET Standard • DigiLocker & Europass Compatible
          </div>
          <div>© 2026 CertiVerse AI Inc. All rights reserved.</div>
        </div>
      </footer>
    </div>
  );
};
