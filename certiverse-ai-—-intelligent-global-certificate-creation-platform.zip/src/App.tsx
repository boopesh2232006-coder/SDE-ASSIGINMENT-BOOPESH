import React from 'react';
import { CertProvider, useCert } from './context/CertContext';
import { NavigationHeader } from './components/NavigationHeader';
import { LandingPage } from './components/landing/LandingPage';
import { VisualEditor } from './components/editor/VisualEditor';
import { TemplateGallery } from './components/gallery/TemplateGallery';
import { VerifyPortal } from './components/verify/VerifyPortal';
import { BulkIssuance } from './components/bulk/BulkIssuance';
import { AIStudio } from './components/ai/AIStudio';
import { CountryPacks } from './components/compliance/CountryPacks';
import { AuthAndOrgs } from './components/auth/AuthAndOrgs';
import { CreateCertificateSpace } from './components/create/CreateCertificateSpace';
import { ArchitectureViewer } from './components/docs/ArchitectureViewer';

const AppContent: React.FC = () => {
  const { activeTab } = useCert();

  return (
    <div className="min-h-screen bg-[#0B0F1E] text-slate-100 flex flex-col font-inter">
      <NavigationHeader />
      <main className="flex-1 flex flex-col">
        {activeTab === 'landing' && <LandingPage />}
        {activeTab === 'create_cert' && <CreateCertificateSpace />}
        {activeTab === 'editor' && <VisualEditor />}
        {activeTab === 'gallery' && <TemplateGallery />}
        {activeTab === 'verify' && <VerifyPortal />}
        {activeTab === 'bulk' && <BulkIssuance />}
        {activeTab === 'ai_studio' && <AIStudio />}
        {activeTab === 'compliance' && <CountryPacks />}
        {activeTab === 'orgs_auth' && <AuthAndOrgs />}
        {activeTab === 'monorepo_code' && <ArchitectureViewer />}
      </main>
    </div>
  );
};

export default function App() {
  return (
    <CertProvider>
      <AppContent />
    </CertProvider>
  );
}
