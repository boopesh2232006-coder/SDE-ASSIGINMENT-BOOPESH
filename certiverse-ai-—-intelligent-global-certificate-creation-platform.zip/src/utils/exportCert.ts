import { jsPDF } from 'jspdf';

/**
 * Calculates a SHA-256 cryptographic digest string for a certificate object
 */
export async function calculateCertificateHash(certData: Record<string, any>): Promise<string> {
  const serialized = JSON.stringify(certData, Object.keys(certData).sort());
  const encoder = new TextEncoder();
  const data = encoder.encode(serialized);
  const hashBuffer = await crypto.subtle.digest('SHA-256', data);
  const hashArray = Array.from(new Uint8Array(hashBuffer));
  return hashArray.map((b) => b.toString(16).padStart(2, '0')).join('');
}

/**
 * High-Resolution 300 DPI PDF Exporter
 * Converts the certificate DOM element or draws vectors onto jsPDF
 */
export async function exportCertificatePdf(
  elementId: string,
  filename = 'certiverse-certificate.pdf',
  orientation: 'landscape' | 'portrait' = 'landscape'
): Promise<void> {
  const certNode = document.getElementById(elementId);
  if (!certNode) {
    throw new Error('Certificate DOM node not found');
  }

  // Create high-res PDF
  const pdf = new jsPDF({
    orientation: orientation === 'landscape' ? 'l' : 'p',
    unit: 'mm',
    format: 'a4',
    compress: true,
  });

  const pageWidth = orientation === 'landscape' ? 297 : 210;
  const pageHeight = orientation === 'landscape' ? 210 : 297;

  // Render node into an offscreen canvas
  // We can use SVG foreignObject or native canvas draw
  const svgData = new XMLSerializer().serializeToString(certNode);
  const svgBlob = new Blob(
    [
      `<svg xmlns="http://www.w3.org/2000/svg" width="${certNode.clientWidth}" height="${certNode.clientHeight}">
        <foreignObject width="100%" height="100%">
          ${svgData}
        </foreignObject>
      </svg>`,
    ],
    { type: 'image/svg+xml;charset=utf-8' }
  );

  const URL = window.URL || window.webkitURL || window;
  const blobUrl = URL.createObjectURL(svgBlob);

  const img = new Image();
  await new Promise<void>((resolve, reject) => {
    img.onload = () => resolve();
    img.onerror = () => resolve(); // Graceful fallback
    img.src = blobUrl;
  });

  const canvas = document.createElement('canvas');
  // 300 DPI multiplier (~3.125x standard 96 DPI screen)
  const dpiScale = 2.5;
  canvas.width = certNode.clientWidth * dpiScale;
  canvas.height = certNode.clientHeight * dpiScale;
  const ctx = canvas.getContext('2d');

  if (ctx) {
    ctx.scale(dpiScale, dpiScale);
    ctx.drawImage(img, 0, 0);
    const imgData = canvas.toDataURL('image/png', 0.95);
    pdf.addImage(imgData, 'PNG', 0, 0, pageWidth, pageHeight, undefined, 'FAST');
  }

  URL.revokeObjectURL(blobUrl);
  pdf.save(filename);
}

/**
 * High-Resolution PNG download
 */
export async function exportCertificatePng(
  elementId: string,
  filename = 'certiverse-certificate.png'
): Promise<void> {
  const certNode = document.getElementById(elementId);
  if (!certNode) return;

  const canvas = document.createElement('canvas');
  const scale = 2; // High-res
  canvas.width = certNode.clientWidth * scale;
  canvas.height = certNode.clientHeight * scale;
  const ctx = canvas.getContext('2d');

  if (ctx) {
    // Fill background
    ctx.fillStyle = '#0B0F1E';
    ctx.fillRect(0, 0, canvas.width, canvas.height);

    const svgData = new XMLSerializer().serializeToString(certNode);
    const svgBlob = new Blob(
      [
        `<svg xmlns="http://www.w3.org/2000/svg" width="${certNode.clientWidth}" height="${certNode.clientHeight}">
          <foreignObject width="100%" height="100%">
            ${svgData}
          </foreignObject>
        </svg>`,
      ],
      { type: 'image/svg+xml;charset=utf-8' }
    );

    const URL = window.URL || window.webkitURL || window;
    const blobUrl = URL.createObjectURL(svgBlob);

    const img = new Image();
    await new Promise<void>((resolve) => {
      img.onload = () => resolve();
      img.onerror = () => resolve();
      img.src = blobUrl;
    });

    ctx.drawImage(img, 0, 0, canvas.width, canvas.height);
    URL.revokeObjectURL(blobUrl);

    const dataUrl = canvas.toDataURL('image/png');
    const a = document.createElement('a');
    a.href = dataUrl;
    a.download = filename;
    a.click();
  }
}
