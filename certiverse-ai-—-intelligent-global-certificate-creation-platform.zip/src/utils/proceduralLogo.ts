/**
 * Hash an organization ID to a deterministic hue (0 - 360) and generate
 * a rich procedural SVG workspace avatar/logo.
 */
export function getOrgHue(orgId: string): number {
  let hash = 0;
  for (let i = 0; i < orgId.length; i++) {
    hash = (hash << 5) - hash + orgId.charCodeAt(i);
    hash |= 0;
  }
  return Math.abs(hash) % 360;
}

export function generateProceduralSvg(orgName: string, hue: number, size = 48): string {
  const initials = orgName
    .split(' ')
    .filter(Boolean)
    .slice(0, 2)
    .map((w) => w[0].toUpperCase())
    .join('');

  const complementaryHue = (hue + 180) % 360;
  const triadicHue = (hue + 120) % 360;

  return `
    <svg width="${size}" height="${size}" viewBox="0 0 100 100" fill="none" xmlns="http://www.w3.org/2000/svg">
      <defs>
        <linearGradient id="org-grad-${hue}" x1="0%" y1="0%" x2="100%" y2="100%">
          <stop offset="0%" stop-color="hsl(${hue}, 85%, 55%)" />
          <stop offset="50%" stop-color="hsl(${triadicHue}, 80%, 45%)" />
          <stop offset="100%" stop-color="hsl(${complementaryHue}, 90%, 35%)" />
        </linearGradient>
        <radialGradient id="org-radial-${hue}" cx="50%" cy="30%" r="70%">
          <stop offset="0%" stop-color="rgba(255,255,255,0.4)" />
          <stop offset="100%" stop-color="rgba(0,0,0,0.3)" />
        </radialGradient>
      </defs>
      <rect x="4" y="4" width="92" height="92" rx="24" fill="url(#org-grad-${hue})" stroke="hsl(${hue}, 90%, 75%)" stroke-width="2"/>
      <rect x="4" y="4" width="92" height="92" rx="24" fill="url(#org-radial-${hue})" />
      <circle cx="28" cy="28" r="8" fill="rgba(255,255,255,0.35)" />
      <circle cx="72" cy="72" r="12" fill="rgba(255,255,255,0.2)" />
      <path d="M28 28 L72 72" stroke="rgba(255,255,255,0.25)" stroke-width="2" stroke-dasharray="3 3"/>
      <text x="50" y="58" font-family="Sora, sans-serif" font-weight="800" font-size="34" fill="#ffffff" text-anchor="middle" dominant-baseline="middle" letter-spacing="-1">
        ${initials || 'CV'}
      </text>
    </svg>
  `;
}
