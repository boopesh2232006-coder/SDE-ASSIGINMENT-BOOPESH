export type UserRole = 'OWNER' | 'ADMIN' | 'DESIGNER' | 'ISSUER' | 'VIEWER';

export interface User {
  id: string;
  name: string;
  email: string;
  role: UserRole;
  orgId: string;
  twoFactorEnabled: boolean;
  avatarUrl?: string;
}

export interface Organization {
  id: string;
  name: string;
  slug: string;
  hue: number; // Procedural hue 0-360 generated from hash(orgId)
  logoUrl?: string;
  plan: 'FREE' | 'STARTER' | 'PROFESSIONAL' | 'ENTERPRISE';
  customDomain?: string;
  whitelabel: boolean;
  countryPack: 'standard' | 'us_ceu' | 'eu_ects' | 'india_abc_nsdc' | 'uk_cpd';
  accentColor: string;
  storageUsedMb: number;
}

export type ElementType =
  | 'text'
  | 'token'
  | 'signature'
  | 'qr'
  | 'seal'
  | 'badge'
  | 'border'
  | 'guilloche'
  | 'line'
  | 'image';

export interface CanvasElement {
  id: string;
  type: ElementType;
  x: number; // percentage or px
  y: number;
  width: number;
  height: number;
  rotation?: number;
  opacity?: number;
  locked?: boolean;
  zIndex: number;
  // Typography
  content?: string;
  tokenName?: string;
  fontFamily?: 'Sora' | 'Inter' | 'Playfair Display' | 'Cinzel' | 'Alex Brush' | 'Fira Code';
  fontSize?: number;
  fontWeight?: number | string;
  fontStyle?: 'normal' | 'italic';
  color?: string;
  textAlign?: 'left' | 'center' | 'right';
  letterSpacing?: number;
  lineHeight?: number;
  // Decoration / Shapes
  fillColor?: string;
  borderColor?: string;
  borderWidth?: number;
  borderRadius?: number;
  borderStyle?: 'solid' | 'dashed' | 'double' | 'groove';
  shadow?: string;
  // Signatures
  signerName?: string;
  signerTitle?: string;
  signatureStyle?: 'classic' | 'modern' | 'formal';
  // Seals
  sealText?: string;
  sealSubtext?: string;
  sealVariant?: 'gold-foil' | 'cyan-crest' | 'indigo-shield' | 'royal-star';
}

export type CertificateCategory =
  | 'Education'
  | 'Software Engineering'
  | 'IT & Infrastructure'
  | 'Artificial Intelligence'
  | 'Cybersecurity'
  | 'Cloud & DevOps'
  | 'Data Science'
  | 'Healthcare & Medicine'
  | 'Business & Leadership'
  | 'Finance & Fintech'
  | 'Marketing'
  | 'Human Resources'
  | 'Science & Lab'
  | 'Engineering'
  | 'Sports & Fitness'
  | 'Arts & Design'
  | 'Music & Performing'
  | 'Languages & Linguistics'
  | 'Internship'
  | 'Hands-on Workshop'
  | 'Academic Conference'
  | 'Volunteering'
  | 'Competition Winner'
  | 'Europass / ECTS'
  | 'US CEU Accredited'
  | 'India Skill / ABC'
  | 'Web3 & Blockchain'
  | 'ISO & Quality Audit'
  | 'Project Management'
  | 'ESG & Sustainability';

export interface CertificateTemplate {
  id: string;
  title: string;
  description: string;
  category: CertificateCategory;
  industry: string;
  language: string;
  orientation: 'landscape' | 'portrait';
  paper: 'A4' | 'Letter';
  width: number; // Standard 1000px base
  height: number; // Standard 707px landscape / 1414px portrait
  bgTheme: 'classic-ivory' | 'dark-sapphire' | 'cyber-slate' | 'royal-gold' | 'emerald-crest' | 'minimal-frost';
  complianceTag?: string;
  elements: CanvasElement[];
  thumbnailGradient: string;
}

export interface CertificateRecord {
  id: string;
  certNo: string;
  token: string;
  templateId: string;
  recipientName: string;
  recipientEmail: string;
  course: string;
  issueDate: string;
  expiryDate?: string;
  grade?: string;
  skills: string[];
  issuerName: string;
  issuerTitle: string;
  issuerOrg: string;
  issuerOrgId: string;
  sha256Hash: string;
  status: 'active' | 'revoked' | 'expired';
  revokedAt?: string;
  revocationReason?: string;
  blockchainAnchor?: {
    network: string;
    txHash: string;
    blockNumber: number;
    timestamp: string;
  };
  countryPack?: 'standard' | 'us_ceu' | 'eu_ects' | 'india_abc_nsdc' | 'uk_cpd';
  metadata?: Record<string, any>;
}

export interface BulkImportRow {
  recipient_name: string;
  recipient_email: string;
  course: string;
  grade?: string;
  issue_date?: string;
  skills?: string;
  [key: string]: string | undefined;
}

export interface BulkBatch {
  id: string;
  name: string;
  totalRows: number;
  processedRows: number;
  successCount: number;
  failedCount: number;
  status: 'pending' | 'processing' | 'completed' | 'failed';
  templateId: string;
  createdAt: string;
  downloadZipReady: boolean;
}

export interface AuditLogEntry {
  id: string;
  timestamp: string;
  actorEmail: string;
  actorRole: UserRole;
  action: string;
  resourceType: 'CERTIFICATE' | 'TEMPLATE' | 'ORGANIZATION' | 'BULK_BATCH' | 'AUTH';
  resourceId: string;
  details: string;
  immutableHash: string; // Cryptographic chain hash
}
