export interface CountryPackField {
  id: string;
  label: string;
  tokenKey: string;
  type: 'text' | 'number' | 'date' | 'qr_code';
  required: boolean;
  defaultValue: string;
  description: string;
}

export interface CountryPack {
  id: string;
  name: string;
  region: string;
  flagEmoji: string;
  governingBody: string;
  standardsBody: string;
  description: string;
  fields: CountryPackField[];
  complianceBadge: {
    title: string;
    code: string;
    color: string;
  };
  sampleJsonSchema: Record<string, any>;
}

export const COUNTRY_PACKS: Record<string, CountryPack> = {
  india_abc_nsdc: {
    id: 'india_abc_nsdc',
    name: 'India ABC & NSDC Skill Pack',
    region: 'India',
    flagEmoji: '🇮🇳',
    governingBody: 'Ministry of Skill Development & Entrepreneurship / UGC',
    standardsBody: 'National Skill Qualification Framework (NSQF) & APAAR / ABC',
    description:
      'Implements official APAAR 12-digit Academic Bank of Credits ID, NSQF Competency Level, Sector Skill Council (SSC) code, and Digilocker verifiable schema format.',
    complianceBadge: {
      title: 'Skill India / ABC Verified',
      code: 'NSQF-L6-COMPLIANT',
      color: '#EA580C',
    },
    fields: [
      {
        id: 'apaar_id',
        label: 'APAAR / ABC ID (12-Digit)',
        tokenKey: '{{apaar_id}}',
        type: 'text',
        required: true,
        defaultValue: '8910-2345-6712',
        description: 'Automated Permanent Academic Account Registry Unique Identifier.',
      },
      {
        id: 'nsqf_level',
        label: 'NSQF Qualification Level',
        tokenKey: '{{nsqf_level}}',
        type: 'number',
        required: true,
        defaultValue: '6',
        description: 'National Skills Qualification Framework level (1 to 10).',
      },
      {
        id: 'ssc_council',
        label: 'Sector Skill Council',
        tokenKey: '{{ssc_council}}',
        type: 'text',
        required: true,
        defaultValue: 'IT-ITeS Sector Skill Council NASSCOM',
        description: 'Recognized industry body affiliated with NSDC.',
      },
      {
        id: 'academic_credits',
        label: 'ABC Credit Points',
        tokenKey: '{{academic_credits}}',
        type: 'number',
        required: true,
        defaultValue: '4',
        description: 'Transferable academic credits recorded in DigiLocker NAD.',
      },
    ],
    sampleJsonSchema: {
      $schema: 'https://certiverse.ai/schemas/in-abc-nsdc-v1.json',
      credentialType: 'NSQFCertificate',
      countryCode: 'IN',
      nsqfLevel: 6,
      apaarId: '891023456712',
      creditPoints: 4.0,
      nationalRegistry: 'https://nad.digilocker.gov.in',
    },
  },

  us_ceu: {
    id: 'us_ceu',
    name: 'US CEU Continuing Education Pack',
    region: 'United States',
    flagEmoji: '🇺🇸',
    governingBody: 'International Accreditors for Continuing Education & Training (IACET)',
    standardsBody: 'ANSI/IACET 1-2018 Standard for Continuing Education and Training',
    description:
      'Provides standardized calculation of Continuing Education Units (1 CEU = 10 contact hours of qualified instruction), provider accreditation ID, and licensing board disclosures.',
    complianceBadge: {
      title: 'IACET Standard CEU Accredited',
      code: 'ANSI/IACET 1-2018',
      color: '#D97706',
    },
    fields: [
      {
        id: 'ceu_credits',
        label: 'CEU Credits Awarded',
        tokenKey: '{{ceu_credits}}',
        type: 'number',
        required: true,
        defaultValue: '4.5 CEUs',
        description: 'Ten contact hours equal one Continuing Education Unit.',
      },
      {
        id: 'contact_hours',
        label: 'Verified Instructional Hours',
        tokenKey: '{{contact_hours}}',
        type: 'number',
        required: true,
        defaultValue: '45 Contact Hours',
        description: 'Actual classroom or virtual hands-on clock hours.',
      },
      {
        id: 'iacet_provider_id',
        label: 'IACET Authorized Provider ID',
        tokenKey: '{{iacet_provider_id}}',
        type: 'text',
        required: true,
        defaultValue: 'AP-#1008492-USA',
        description: 'Accreditation identification number.',
      },
      {
        id: 'licensing_board',
        label: 'Target Licensing Board',
        tokenKey: '{{licensing_board}}',
        type: 'text',
        required: false,
        defaultValue: 'National Board of Medical Examiners / State Bar Association',
        description: 'State regulatory agency accepting continuing education credits.',
      },
    ],
    sampleJsonSchema: {
      $schema: 'https://certiverse.ai/schemas/us-iacet-ceu-v2.json',
      credentialType: 'ContinuingEducationUnit',
      countryCode: 'US',
      ceuPoints: 4.5,
      instructionalMinutes: 2700,
      iacetProvider: 'AP-1008492-USA',
      standard: 'ANSI/IACET 1-2018',
    },
  },

  eu_ects: {
    id: 'eu_ects',
    name: 'EU ECTS & Europass Digital Credential Pack',
    region: 'European Union',
    flagEmoji: '🇪🇺',
    governingBody: 'European Commission Directorate-General for Education & Culture',
    standardsBody: 'Bologna Process & Europass Digital Credentials Infrastructure (EDCI)',
    description:
      'Format compliant with W3C Verifiable Credentials and Europass XML/JSON-LD data model, integrating European Credit Transfer and Accumulation System (ECTS) weighting.',
    complianceBadge: {
      title: 'Europass & ECTS Compliant',
      code: 'EDCI-BOLOGNA-2026',
      color: '#2563EB',
    },
    fields: [
      {
        id: 'ects_credits',
        label: 'ECTS Credits (Workload)',
        tokenKey: '{{ects_credits}}',
        type: 'number',
        required: true,
        defaultValue: '30 ECTS',
        description: '60 ECTS credits represent the workload of an entire academic year.',
      },
      {
        id: 'eqf_level',
        label: 'European Qualifications Framework Level',
        tokenKey: '{{eqf_level}}',
        type: 'number',
        required: true,
        defaultValue: 'EQF Level 7 (Master)',
        description: 'European Qualifications Framework benchmark (Level 1-8).',
      },
      {
        id: 'europass_credential_id',
        label: 'Europass Global ID (URN)',
        tokenKey: '{{europass_credential_id}}',
        type: 'text',
        required: true,
        defaultValue: 'urn:epass:cred:2026:eu-890432-fr',
        description: 'Uniform Resource Name registered with the Europass EDCI hub.',
      },
    ],
    sampleJsonSchema: {
      $schema: 'https://europa.eu/europass/digital-credentials/v2',
      '@context': ['https://www.w3.org/2018/credentials/v1'],
      type: ['VerifiableCredential', 'EuropeanDigitalCredentialForHigherEducation'],
      ectsAllocation: 30,
      eqfLevel: 7,
      accreditationStatus: 'BolognaAccredited',
    },
  },

  uk_cpd: {
    id: 'uk_cpd',
    name: 'UK CPD Standards Office Certification',
    region: 'United Kingdom',
    flagEmoji: '🇬🇧',
    governingBody: 'The CPD Certification Service & CPD Standards Office UK',
    standardsBody: 'Continuing Professional Development UK Code of Practice',
    description:
      'Recognized for British chartered bodies, solicitors, healthcare practitioners, and accountants.',
    complianceBadge: {
      title: 'CPD Certified UK',
      code: 'CPD-SO-REF-77491',
      color: '#7C3AED',
    },
    fields: [
      {
        id: 'cpd_hours',
        label: 'Structured CPD Hours',
        tokenKey: '{{cpd_hours}}',
        type: 'number',
        required: true,
        defaultValue: '36 Structured CPD Hours',
        description: 'Formal verifiable learning hours under UK CPD standards.',
      },
      {
        id: 'cpd_provider_ref',
        label: 'CPD Member Registration Ref',
        tokenKey: '{{cpd_provider_ref}}',
        type: 'text',
        required: true,
        defaultValue: 'CPD-UK-MEM-99214',
        description: 'Registered organization reference with CPD Certification Service.',
      },
    ],
    sampleJsonSchema: {
      $schema: 'https://cpduk.co.uk/standards/schema-v1.json',
      credentialType: 'CPDCertificate',
      countryCode: 'GB',
      structuredHours: 36,
      charteredRecognized: true,
    },
  },
};
